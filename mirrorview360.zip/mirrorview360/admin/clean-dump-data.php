<?php require_once 'header.php';



if (isset($_GET['sortby'])) {

  $sortby = $_GET['sortby'];

} else {

  $sortby = 'default';
}


$query = "SELECT * from candidates where candidate_clean='yes'";

if (isset($_GET['id']) and $_GET['id']) {
  
  $filterid = $_GET['id'];
  $query .= " AND (candidate_id='$filterid') ";

}

if (isset($_GET['name']) and $_GET['name']) {
  
  $filtername = $_GET['name'];
  $query .= " AND (candidate_adsoyad LIKE '$filtername%' or candidate_adsoyad LIKE '%$filtername%' or candidate_adsoyad LIKE '%$filtername') ";

}

if (isset($_GET['company']) and $_GET['company']) {
  
  $filtercompany = $_GET['company'];
  $query .= " AND (candidate_company LIKE '$filtercompany%' or candidate_company LIKE '%$filtercompany%' or candidate_company LIKE '%$filtercompany') ";

}


if (isset($_GET['designation']) and $_GET['designation']) {
  
  $filterdesignation = $_GET['designation'];
  $query .= " AND (candidate_designation LIKE '$filterdesignation%' or candidate_designation LIKE '%$filterdesignation%' or candidate_designation LIKE '%$filterdesignation') ";

}


if (isset($_GET['product']) and $_GET['product']!='notselected') {
  
  $filterproduct = $_GET['product'];
  $query .= " AND (candidate_product LIKE '$filterproduct%' or candidate_product LIKE '%$filterproduct%' or candidate_product LIKE '%$filterproduct') ";

}

if (isset($_GET['existstatus']) and $_GET['existstatus']!='notselected') {
  
  $filterexistatus = $_GET['existstatus'];
  $query .= " AND (candidate_listed='$filterexistatus') ";

}

if (isset($_GET['department']) and $_GET['department']!='notselected') {
  
  $filterdepartment = $_GET['department'];
  $query .= " AND (candidate_department LIKE '$filterdepartment%' or candidate_department LIKE '%$filterdepartment%' or candidate_department LIKE '%$filterdepartment') ";

}


if (isset($_GET['location']) and $_GET['location']) {
  
  $filterlocation = $_GET['location'];
  $query .= " AND (candidate_location LIKE '$filterlocation%' or candidate_location LIKE '%$filterlocation%' or candidate_location LIKE '%$filterlocation') ";

}


if (isset($_GET['phone']) and $_GET['phone']) {
  
  $filterphone = $_GET['phone'];
  $query .= " AND (candidate_telno LIKE '$filterphone%' or candidate_telno LIKE '%$filterphone%' or candidate_telno LIKE '%$filterphone') ";

}

if (isset($_GET['called']) and $_GET['called']!='status') {
  
  $filtercalled = $_GET['called'];
  $query .= " AND (candidate_called='$filtercalled') ";

}


if (isset($_GET['search']) and $_GET['search']) {
  
  $filtersearch = $_GET['search'];
  $query .= " AND (candidate_adsoyad LIKE '$filtersearch%' or candidate_adsoyad LIKE '%$filtersearch%' or candidate_adsoyad LIKE '%$filtersearch' or
   candidate_telno LIKE '$filtersearch%' or candidate_telno LIKE '%$filtersearch%' or candidate_telno LIKE '%$filtersearch' or 
   candidate_location LIKE '$filtersearch%' or candidate_location LIKE '%$filtersearch%' or candidate_location LIKE '%$filtersearch' or 
   candidate_company LIKE '$filtersearch%' or candidate_company LIKE '%$filtersearch%' or candidate_company LIKE '%$filtersearch' or 
   candidate_designation LIKE '$filtersearch%' or candidate_designation LIKE '%$filtersearch%' or candidate_designation LIKE '%$filtersearch' or
   candidate_mail LIKE '$filtersearch%' or candidate_mail LIKE '%$filtersearch%' or candidate_mail LIKE '%$filtersearch' or 
   candidate_product LIKE '$filtersearch%' or candidate_product LIKE '%$filtersearch%' or candidate_product LIKE '%$filtersearch' or
   candidate_department LIKE '$filtersearch%' or candidate_department LIKE '%$filtersearch%' or candidate_department LIKE '%$filtersearch' or
   candidate_pincode LIKE '$filtersearch%' or candidate_pincode LIKE '%$filtersearch%' or candidate_pincode LIKE '%$filtersearch' or
   candidate_birthdate LIKE '$filtersearch%' or candidate_birthdate LIKE '%$filtersearch%' or candidate_birthdate LIKE '%$filtersearch' or
   candidate_industry LIKE '$filtersearch%' or candidate_industry LIKE '%$filtersearch%' or candidate_industry LIKE '%$filtersearch' or
   candidate_currentjobexperience LIKE '$filtersearch%' or candidate_currentjobexperience LIKE '%$filtersearch%' or candidate_currentjobexperience LIKE '%$filtersearch' or
   candidate_currentfunctionalarea LIKE '$filtersearch%' or candidate_currentfunctionalarea LIKE '%$filtersearch%' or candidate_currentfunctionalarea LIKE '%$filtersearch' or
   candidate_bankingdepartment LIKE '$filtersearch%' or candidate_bankingdepartment LIKE '%$filtersearch%' or candidate_bankingdepartment LIKE '%$filtersearch' or
   candidate_bankingsubdepartment LIKE '$filtersearch%' or candidate_bankingsubdepartment LIKE '%$filtersearch%' or candidate_bankingsubdepartment LIKE '%$filtersearch' or
   candidate_multiplelocationnames LIKE '$filtersearch%' or candidate_multiplelocationnames LIKE '%$filtersearch%' or candidate_multiplelocationnames LIKE '%$filtersearch' or
   candidate_prefferedlocation LIKE '$filtersearch%' or candidate_prefferedlocation LIKE '%$filtersearch%' or candidate_prefferedlocation LIKE '%$filtersearch' or
   candidate_gender LIKE '$filtersearch%' or candidate_gender LIKE '%$filtersearch%' or candidate_gender LIKE '%$filtersearch' or
   candidate_totalworkexperience LIKE '$filtersearch%' or candidate_totalworkexperience LIKE '%$filtersearch%' or candidate_totalworkexperience LIKE '%$filtersearch' or
   candidate_annualsalary LIKE '$filtersearch%' or candidate_annualsalary LIKE '%$filtersearch%' or candidate_annualsalary LIKE '%$filtersearch' or
   candidate_deeshamail LIKE '$filtersearch%' or candidate_deeshamail LIKE '%$filtersearch%' or candidate_deeshamail LIKE '%$filtersearch' or
   candidate_telno2 LIKE '$filtersearch%' or candidate_telno2 LIKE '%$filtersearch%' or candidate_telno2 LIKE '%$filtersearch' or
   candidate_wpno LIKE '$filtersearch%' or candidate_wpno LIKE '%$filtersearch%' or candidate_wpno LIKE '%$filtersearch' or
   candidate_wpno2 LIKE '$filtersearch%' or candidate_wpno2 LIKE '%$filtersearch%' or candidate_wpno2 LIKE '%$filtersearch' or
   candidate_noticeperiod LIKE '$filtersearch%' or candidate_noticeperiod LIKE '%$filtersearch%' or candidate_noticeperiod LIKE '%$filtersearch' or
   candidate_highesteducationlevel LIKE '$filtersearch%' or candidate_highesteducationlevel LIKE '%$filtersearch%' or candidate_highesteducationlevel LIKE '%$filtersearch' or
   candidate_highesteducationstream LIKE '$filtersearch%' or candidate_highesteducationstream LIKE '%$filtersearch%' or candidate_highesteducationstream LIKE '%$filtersearch' or
   candidate_highesteducationinsitute LIKE '$filtersearch%' or candidate_highesteducationinsitute LIKE '%$filtersearch%' or candidate_highesteducationinsitute LIKE '%$filtersearch' or
   candidate_yearofpassing LIKE '$filtersearch%' or candidate_yearofpassing LIKE '%$filtersearch%' or candidate_yearofpassing LIKE '%$filtersearch' or
   candidate_highesteducationcoursetype LIKE '$filtersearch%' or candidate_highesteducationcoursetype LIKE '%$filtersearch%' or candidate_highesteducationcoursetype LIKE '%$filtersearch' or 
   candidate_createdate LIKE '$filtersearch%' or candidate_createdate LIKE '%$filtersearch%' or candidate_createdate LIKE '%$filtersearch' or
   candidate_lastmodifieddate LIKE '$filtersearch%' or candidate_lastmodifieddate LIKE '%$filtersearch%' or candidate_lastmodifieddate LIKE '%$filtersearch' or
   candidate_lastactivedate LIKE '$filtersearch%' or candidate_lastactivedate LIKE '%$filtersearch%' or candidate_lastactivedate LIKE '%$filtersearch' or 
   candidate_note LIKE '$filtersearch%' or candidate_note LIKE '%$filtersearch%' or candidate_note LIKE '%$filtersearch' or
   candidate_summarydescription LIKE '$filtersearch%' or candidate_summarydescription LIKE '%$filtersearch%' or candidate_summarydescription LIKE '%$filtersearch' or 
   candidate_experiencepershine LIKE '$filtersearch%' or candidate_experiencepershine LIKE '%$filtersearch%' or candidate_experiencepershine LIKE '%$filtersearch' or 
   candidate_lastjob LIKE '$filtersearch%' or candidate_lastjob LIKE '%$filtersearch%' or candidate_lastjob LIKE '%$filtersearch' or
   candidate_lasttolastjob LIKE '$filtersearch%' or candidate_lasttolastjob LIKE '%$filtersearch%' or candidate_lasttolastjob LIKE '%$filtersearch' or 
   candidate_graducationcourse LIKE '$filtersearch%' or candidate_graducationcourse LIKE '%$filtersearch%' or candidate_graducationcourse LIKE '%$filtersearch' or 
   candidate_graduationcollege LIKE '$filtersearch%' or candidate_graduationcollege LIKE '%$filtersearch%' or candidate_graduationcollege LIKE '%$filtersearch' or 
   candidate_skills LIKE '$filtersearch%' or candidate_skills LIKE '%$filtersearch%' or candidate_skills LIKE '%$filtersearch' or 
   candidate_mayalsoknow LIKE '$filtersearch%' or candidate_mayalsoknow LIKE '%$filtersearch%' or candidate_mayalsoknow LIKE '%$filtersearch' or 
   candidate_tiercity LIKE '$filtersearch%' or candidate_tiercity LIKE '%$filtersearch%' or candidate_tiercity LIKE '%$filtersearch' or 
   candidate_loanproduct LIKE '$filtersearch%' or candidate_loanproduct LIKE '%$filtersearch%' or candidate_loanproduct LIKE '%$filtersearch' or 
   candidate_loansubproduct LIKE '$filtersearch%' or candidate_loansubproduct LIKE '%$filtersearch%' or candidate_loansubproduct LIKE '%$filtersearch' or 
   candidate_internalsource LIKE '$filtersearch%' or candidate_internalsource LIKE '%$filtersearch%' or candidate_internalsource LIKE '%$filtersearch' or 
   candidate_sourcetype LIKE '$filtersearch%' or candidate_sourcetype LIKE '%$filtersearch%' or candidate_sourcetype LIKE '%$filtersearch' or 
   candidate_externalsource LIKE '$filtersearch%' or candidate_externalsource LIKE '%$filtersearch%' or candidate_externalsource LIKE '%$filtersearch' or 
   candidate_refferredname LIKE '$filtersearch%' or candidate_refferredname LIKE '%$filtersearch%' or candidate_refferredname LIKE '%$filtersearch' or 
   candidate_referredid LIKE '$filtersearch%' or candidate_referredid LIKE '%$filtersearch%' or candidate_referredid LIKE '%$filtersearch' or 
   candidate_dateofentry LIKE '$filtersearch%' or candidate_dateofentry LIKE '%$filtersearch%' or candidate_dateofentry LIKE '%$filtersearch' or 
   candidate_deeshaemployeenamerefer LIKE '$filtersearch%' or candidate_deeshaemployeenamerefer LIKE '%$filtersearch%' or candidate_deeshaemployeenamerefer LIKE '%$filtersearch' or 
   candidate_deeshaemployeenameenter LIKE '$filtersearch%' or candidate_deeshaemployeenameenter LIKE '%$filtersearch%' or candidate_deeshaemployeenameenter LIKE '%$filtersearch' or 
   candidate_marriageanniv LIKE '$filtersearch%' or candidate_marriageanniv LIKE '%$filtersearch%' or candidate_marriageanniv LIKE '%$filtersearch' or 
   candidate_lastaccessdate LIKE '$filtersearch%' or candidate_lastaccessdate LIKE '%$filtersearch%' or candidate_lastaccessdate LIKE '%$filtersearch' or 
   candidate_lastaccessperson LIKE '$filtersearch%' or candidate_lastaccessperson LIKE '%$filtersearch%' or candidate_lastaccessperson LIKE '%$filtersearch' or 
   candidate_deeshaemployeefeedback LIKE '$filtersearch%' or candidate_deeshaemployeefeedback LIKE '%$filtersearch%' or candidate_deeshaemployeefeedback LIKE '%$filtersearch' or
   candidate_deeshaemployeecomment LIKE '$filtersearch%' or candidate_deeshaemployeecomment LIKE '%$filtersearch%' or candidate_deeshaemployeecomment LIKE '%$filtersearch' or
   candidate_currentbossname LIKE '$filtersearch%' or candidate_currentbossname LIKE '%$filtersearch%' or candidate_currentbossname LIKE '%$filtersearch' or
   candidate_exbossname LIKE '$filtersearch%' or candidate_exbossname LIKE '%$filtersearch%' or candidate_exbossname LIKE '%$filtersearch' or
   candidate_interestingfact LIKE '$filtersearch%' or candidate_interestingfact LIKE '%$filtersearch%' or candidate_interestingfact LIKE '%$filtersearch' or
   candidate_languagesspeak LIKE '$filtersearch%' or candidate_languagesspeak LIKE '%$filtersearch%' or candidate_languagesspeak LIKE '%$filtersearch'  or
   candidate_languageprefer LIKE '$filtersearch%' or candidate_languageprefer LIKE '%$filtersearch%' or candidate_languageprefer LIKE '%$filtersearch' or
   candidate_mothertongue LIKE '$filtersearch%' or candidate_mothertongue LIKE '%$filtersearch%' or candidate_mothertongue LIKE '%$filtersearch' or
   candidate_banker LIKE '$filtersearch%' or candidate_banker LIKE '%$filtersearch%' or candidate_banker LIKE '%$filtersearch' or
   candidate_residenceaddress LIKE '$filtersearch%' or candidate_residenceaddress LIKE '%$filtersearch%' or candidate_residenceaddress LIKE '%$filtersearch' or
   candidate_companyaddress LIKE '$filtersearch%' or candidate_companyaddress LIKE '%$filtersearch%' or candidate_companyaddress LIKE '%$filtersearch' or
   candidate_country LIKE '$filtersearch%' or candidate_country LIKE '%$filtersearch%' or candidate_country LIKE '%$filtersearch' or
   candidate_reportingmanagerno LIKE '$filtersearch%' or candidate_reportingmanagerno LIKE '%$filtersearch%' or candidate_reportingmanagerno LIKE '%$filtersearch' or
   candidate_associatedeeesha LIKE '$filtersearch%' or candidate_associatedeeesha LIKE '%$filtersearch%' or candidate_associatedeeesha LIKE '%$filtersearch' or
   candidate_bankerdeeesha LIKE '$filtersearch%' or candidate_bankerdeeesha LIKE '%$filtersearch%' or candidate_bankerdeeesha LIKE '%$filtersearch' or
   candidate_customerdeeesha LIKE '$filtersearch%' or candidate_customerdeeesha LIKE '%$filtersearch%' or candidate_customerdeeesha LIKE '%$filtersearch' or
   candidate_candidatefinploy LIKE '$filtersearch%' or candidate_candidatefinploy LIKE '%$filtersearch%' or candidate_candidatefinploy LIKE '%$filtersearch' or
   candidate_companyfinploy LIKE '$filtersearch%' or candidate_companyfinploy LIKE '%$filtersearch%' or candidate_companyfinploy LIKE '%$filtersearch' or
   candidate_associatefinploy LIKE '$filtersearch%' or candidate_associatefinploy LIKE '%$filtersearch%' or candidate_associatefinploy LIKE '%$filtersearch' or
   candidate_companyfinterno LIKE '$filtersearch%' or candidate_companyfinterno LIKE '%$filtersearch%' or candidate_companyfinterno LIKE '%$filtersearch' or
   candidate_internfinterno LIKE '$filtersearch%' or candidate_internfinterno LIKE '%$filtersearch%' or candidate_internfinterno LIKE '%$filtersearch' or
   candidate_associatefinterno LIKE '$filtersearch%' or candidate_associatefinterno LIKE '%$filtersearch%' or candidate_associatefinterno LIKE '%$filtersearch' or
   candidate_companyfintubhai LIKE '$filtersearch%' or candidate_companyfintubhai LIKE '%$filtersearch%' or candidate_companyfintubhai LIKE '%$filtersearch' or
   candidate_customerfintubhai LIKE '$filtersearch%' or candidate_customerfintubhai LIKE '%$filtersearch%' or candidate_customerfintubhai LIKE '%$filtersearch' or
   candidate_associatefintubhai LIKE '$filtersearch%' or candidate_associatefintubhai LIKE '%$filtersearch%' or candidate_associatefintubhai LIKE '%$filtersearch' or
   candidate_idassociatedeeesha LIKE '$filtersearch%' or candidate_idassociatedeeesha LIKE '%$filtersearch%' or candidate_idassociatedeeesha LIKE '%$filtersearch' or
   candidate_idbankerdeeesha LIKE '$filtersearch%' or candidate_idbankerdeeesha LIKE '%$filtersearch%' or candidate_idbankerdeeesha LIKE '%$filtersearch' or
   candidate_idcustomerdeeesha LIKE '$filtersearch%' or candidate_idcustomerdeeesha LIKE '%$filtersearch%' or candidate_idcustomerdeeesha LIKE '%$filtersearch' or
   candidate_idcandidatefinploy LIKE '$filtersearch%' or candidate_idcandidatefinploy LIKE '%$filtersearch%' or candidate_idcandidatefinploy LIKE '%$filtersearch' or
   candidate_idassociatefinploy LIKE '$filtersearch%' or candidate_idassociatefinploy LIKE '%$filtersearch%' or candidate_idassociatefinploy LIKE '%$filtersearch' or
   candidate_idcompanyfinterno LIKE '$filtersearch%' or candidate_idcompanyfinterno LIKE '%$filtersearch%' or candidate_idcompanyfinterno LIKE '%$filtersearch' or
   candidate_idintern LIKE '$filtersearch%' or candidate_idintern LIKE '%$filtersearch%' or candidate_idintern LIKE '%$filtersearch' or
   candidate_idassociatefinterno LIKE '$filtersearch%' or candidate_idassociatefinterno LIKE '%$filtersearch%' or candidate_idassociatefinterno LIKE '%$filtersearch' or
   candidate_idcompanyfintubhai LIKE '$filtersearch%' or candidate_idcompanyfintubhai LIKE '%$filtersearch%' or candidate_idcompanyfintubhai LIKE '%$filtersearch' or
   candidate_idcustomerfintubhai LIKE '$filtersearch%' or candidate_idcustomerfintubhai LIKE '%$filtersearch%' or candidate_idcustomerfintubhai LIKE '%$filtersearch' or
   candidate_idassociatefintubhai LIKE '$filtersearch%' or candidate_idassociatefintubhai LIKE '%$filtersearch%' or candidate_idassociatefintubhai LIKE '%$filtersearch' or
   candidate_othercity LIKE '$filtersearch%' or candidate_othercity LIKE '%$filtersearch%' or candidate_othercity LIKE '%$filtersearch' or
   candidate_nameoncertificate LIKE '$filtersearch%' or candidate_nameoncertificate LIKE '%$filtersearch%' or candidate_nameoncertificate LIKE '%$filtersearch' or
   candidate_mothername LIKE '$filtersearch%' or candidate_mothername LIKE '%$filtersearch%' or candidate_mothername LIKE '%$filtersearch' or
   candidate_fathername LIKE '$filtersearch%' or candidate_fathername LIKE '%$filtersearch%' or candidate_fathername LIKE '%$filtersearch' or
   candidate_fathertelno LIKE '$filtersearch%' or candidate_fathertelno LIKE '%$filtersearch%' or candidate_fathertelno LIKE '%$filtersearch' or
   candidate_mothertelno LIKE '$filtersearch%' or candidate_mothertelno LIKE '%$filtersearch%' or candidate_mothertelno LIKE '%$filtersearch' or
   candidate_registrationsite LIKE '$filtersearch%' or candidate_registrationsite LIKE '%$filtersearch%' or candidate_registrationsite LIKE '%$filtersearch' or
   candidate_interestedinbankingetc LIKE '$filtersearch%' or candidate_interestedinbankingetc LIKE '%$filtersearch%' or candidate_interestedinbankingetc LIKE '%$filtersearch' or
   candidate_interests LIKE '$filtersearch%' or candidate_interests LIKE '%$filtersearch%' or candidate_interests LIKE '%$filtersearch' or
   candidate_pastinternships LIKE '$filtersearch%' or candidate_pastinternships LIKE '%$filtersearch%' or candidate_pastinternships LIKE '%$filtersearch' or
   candidate_durationofinternship LIKE '$filtersearch%' or candidate_durationofinternship LIKE '%$filtersearch%' or candidate_durationofinternship LIKE '%$filtersearch' or
   candidate_rolesinpreviousinternship LIKE '$filtersearch%' or candidate_rolesinpreviousinternship LIKE '%$filtersearch%' or candidate_rolesinpreviousinternship LIKE '%$filtersearch' or
   candidate_typeofinternship LIKE '$filtersearch%' or candidate_typeofinternship LIKE '%$filtersearch%' or candidate_typeofinternship LIKE '%$filtersearch' or
   candidate_joinasafulltimeemployee LIKE '$filtersearch%' or candidate_joinasafulltimeemployee LIKE '%$filtersearch%' or candidate_joinasafulltimeemployee LIKE '%$filtersearch' or
   candidate_internshipprefer LIKE '$filtersearch%' or candidate_internshipprefer LIKE '%$filtersearch%' or candidate_internshipprefer LIKE '%$filtersearch' or
   candidate_hoursdedicate LIKE '$filtersearch%' or candidate_hoursdedicate LIKE '%$filtersearch%' or candidate_hoursdedicate LIKE '%$filtersearch' or
   candidate_typeofinternship2 LIKE '$filtersearch%' or candidate_typeofinternship2 LIKE '%$filtersearch%' or candidate_typeofinternship2 LIKE '%$filtersearch' or
   candidate_howdaysworkaweek LIKE '$filtersearch%' or candidate_howdaysworkaweek LIKE '%$filtersearch%' or candidate_howdaysworkaweek LIKE '%$filtersearch' or
   candidate_desiredincome LIKE '$filtersearch%' or candidate_desiredincome LIKE '%$filtersearch%' or candidate_desiredincome LIKE '%$filtersearch' or
   candidate_havetechnicalknowledge LIKE '$filtersearch%' or candidate_havetechnicalknowledge LIKE '%$filtersearch%' or candidate_havetechnicalknowledge LIKE '%$filtersearch' or
   candidate_professortelno LIKE '$filtersearch%' or candidate_professortelno LIKE '%$filtersearch%' or candidate_professortelno LIKE '%$filtersearch' or
   linkedin_name LIKE '$filtersearch%' or linkedin_name LIKE '%$filtersearch%' or linkedin_name LIKE '%$filtersearch' or
   linkedin_namepos LIKE '$filtersearch%' or linkedin_namepos LIKE '%$filtersearch%' or linkedin_namepos LIKE '%$filtersearch' or
   linkedin_companyname LIKE '$filtersearch%' or linkedin_companyname LIKE '%$filtersearch%' or linkedin_companyname LIKE '%$filtersearch' or
   linkedin_cityname LIKE '$filtersearch%' or linkedin_cityname LIKE '%$filtersearch%' or linkedin_cityname LIKE '%$filtersearch' or
   linkedin_statename LIKE '$filtersearch%' or linkedin_statename LIKE '%$filtersearch%' or linkedin_statename LIKE '%$filtersearch' or
   linkedin_namecountry LIKE '$filtersearch%' or linkedin_namecountry LIKE '%$filtersearch%' or linkedin_namecountry LIKE '%$filtersearch' or
   linkedin_currentjob LIKE '$filtersearch%' or linkedin_currentjob LIKE '%$filtersearch%' or linkedin_currentjob LIKE '%$filtersearch' or
   linkedin_secondlastjob LIKE '$filtersearch%' or linkedin_secondlastjob LIKE '%$filtersearch%' or linkedin_secondlastjob LIKE '%$filtersearch' or
   linkedin_thirdlastjob LIKE '$filtersearch%' or linkedin_thirdlastjob LIKE '%$filtersearch%' or linkedin_thirdlastjob LIKE '%$filtersearch' or
   linkedin_highesteducation LIKE '$filtersearch%' or linkedin_highesteducation LIKE '%$filtersearch%' or linkedin_highesteducation LIKE '%$filtersearch' or
   linkedin_secondeducation LIKE '$filtersearch%' or linkedin_secondeducation LIKE '%$filtersearch%' or linkedin_secondeducation LIKE '%$filtersearch' or
   linkedin_skills LIKE '$filtersearch%' or linkedin_skills LIKE '%$filtersearch%' or linkedin_skills LIKE '%$filtersearch' or
   linkedin_interests LIKE '$filtersearch%' or linkedin_interests LIKE '%$filtersearch%' or linkedin_interests LIKE '%$filtersearch' or
   linkedin_accomplishment LIKE '$filtersearch%' or linkedin_accomplishment LIKE '%$filtersearch%' or linkedin_accomplishment LIKE '%$filtersearch' or
   linkedin_urlfromscrapper LIKE '$filtersearch%' or linkedin_urlfromscrapper LIKE '%$filtersearch%' or linkedin_urlfromscrapper LIKE '%$filtersearch' or
   candidate_firstname LIKE '$filtersearch%' or candidate_firstname LIKE '%$filtersearch%' or candidate_firstname LIKE '%$filtersearch' or
   candidate_middlename LIKE '$filtersearch%' or candidate_middlename LIKE '%$filtersearch%' or candidate_middlename LIKE '%$filtersearch' or
   candidate_lastname LIKE '$filtersearch%' or candidate_lastname LIKE '%$filtersearch%' or candidate_lastname LIKE '%$filtersearch' or
   candidate_emailidofficial LIKE '$filtersearch%' or candidate_emailidofficial LIKE '%$filtersearch%' or candidate_emailidofficial LIKE '%$filtersearch' or
   candidate_birthday LIKE '$filtersearch%' or candidate_birthday LIKE '%$filtersearch%' or candidate_birthday LIKE '%$filtersearch' or
   candidate_lastcallbydeeeshaemp LIKE '$filtersearch%' or candidate_lastcallbydeeeshaemp LIKE '%$filtersearch%' or candidate_lastcallbydeeeshaemp LIKE '%$filtersearch' or
   candidate_employeemail LIKE '$filtersearch%' or candidate_employeemail LIKE '%$filtersearch%' or candidate_employeemail LIKE '%$filtersearch' ) ";

}




//------------------------------------------------------------------------






$candidatetestsay = 100;

$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=20;
$sayfasayisi=ceil($candidatetestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($candidatetestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../admin/");
 }

 ?>

 <style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Clean Dump Data</h2>


                    

                     <div style="margin-top: 15px;" class="col-xs-12 col-sm-12 col-md-12 nav navbar-right panel_toolbox">
                       <div class="row">



                        <form action="clean-dump-data" method="GET">

                          <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['id']) and $_GET['id']!='') { ?>
                         value ='<?php echo $_GET['id']; ?>'
                        <?php } ?> type="text" placeholder="ID" maxlength="150" name="id" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['name']) and $_GET['name']!='') { ?>
                         value ='<?php echo $_GET['name']; ?>'
                        <?php } ?> type="text" placeholder="Name" maxlength="150" name="name" class="form-control"></div>
                         
                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['company']) and $_GET['company']!='') { ?>
                         value ='<?php echo $_GET['company']; ?>'
                        <?php } ?> type="text" placeholder="Company" maxlength="150" name="company" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['designation']) and $_GET['designation']!='') { ?>
                         value ='<?php echo $_GET['designation']; ?>'
                        <?php } ?> type="text" placeholder="Designation" maxlength="150" name="designation" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="product">

                            <option value="notselected">Product</option>
                            
                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Personal Loan') { ?>
                         selected=''
                        <?php } ?>>Personal Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Business Loan') { ?>
                         selected=''
                        <?php } ?>>Business Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Home Loan') { ?>
                         selected=''
                        <?php } ?>>Home Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Loan Against Property') { ?>
                         selected=''
                        <?php } ?>>Loan Against Property</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Commercial Vehicle Loan') { ?>
                         selected=''
                        <?php } ?>>Commercial Vehicle Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Gold Loan') { ?>
                         selected=''
                        <?php } ?>>Gold Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Branch Banking') { ?>
                         selected=''
                        <?php } ?>>Branch Banking</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Broking') { ?>
                         selected=''
                        <?php } ?>>Broking</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Insurance') { ?>
                         selected=''
                        <?php } ?>>Insurance</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Credit Card') { ?>
                         selected=''
                        <?php } ?>>Credit Card</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Others') { ?>
                         selected=''
                        <?php } ?>>Others</option>

                          </select>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="department">

                            <option value="notselected">Department</option>
                            
                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Sales') { ?>
                         selected=''
                        <?php } ?>>Sales</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Credit') { ?>
                         selected=''
                        <?php } ?>>Credit</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Operations') { ?>
                         selected=''
                        <?php } ?>>Operations</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='IT') { ?>
                         selected=''
                        <?php } ?>>IT</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Others') { ?>
                         selected=''
                        <?php } ?>>Others</option>

                            

                          </select>
                        </div>

                        

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['location']) and $_GET['location']!='') { ?>
                         value ='<?php echo $_GET['location']; ?>'
                        <?php } ?> type="text" placeholder="Location" maxlength="150" name="location" class="form-control"></div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['phone']) and $_GET['phone']!='') { ?>
                         value ='<?php echo $_GET['phone']; ?>'
                        <?php } ?> type="text" placeholder="Phone" maxlength="12" name="phone" class="form-control"></div>


                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          <input style="border: 1px solid #043d75;" class="form-control" <?php if (isset($_GET['search']) and $_GET['search']!='') { ?>
                         value ='<?php echo $_GET['search']; ?>'
                        <?php } ?> maxlength="200" placeholder='Global Search...' type="text" name="search">
                        </div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="called">
                            
                            <option value="status">Status</option>

                            <option <?php if (isset($_GET['called']) and $_GET['called']=='0') { ?>
                             selected=''
                            <?php } ?> value="0">Not called</option>

                            <option <?php if (isset($_GET['called']) and $_GET['called']=='1') { ?>
                             selected=''
                            <?php } ?> value="1">Called</option>

                          </select>
                        </div>


                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          


                          
                          <select class="form-control" name="existstatus">
                          
                          <option value="notselected">Exist / Not Exist</option>

                          <option <?php if ($_GET['existstatus']=='0') { ?>
                            selected=''
                          <?php } ?> value="0">Not Exist</option>

                          <option <?php if ($_GET['existstatus']=='1') { ?>
                            selected=''
                          <?php } ?> value="1">Exist</option>

                         
                            
                        </select>

                        

                        </div>

                        

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          
                          <select class="form-control" name="sortby">
                          
                          <option value="default">Sort By</option>

                          <option <?php if ($sortby=='1') { ?>
                            selected=''
                          <?php } ?> value="1">Date Created (New to Old)</option>

                          <option <?php if ($sortby=='2') { ?>
                            selected=''
                          <?php } ?> value="2">Date Created (Old to New)</option>

                         
                          <option <?php if ($sortby=='4') { ?>
                            selected=''
                          <?php } ?> value="4">Name (A-Z)</option>

                          <option <?php if ($sortby=='5') { ?>
                            selected=''
                          <?php } ?> value="5">Name (Z-A)</option>

                           

                          <option <?php if ($sortby=='6') { ?>
                            selected=''
                          <?php } ?> value="6">Company</option>

                          <option <?php if ($sortby=='7') { ?>
                            selected=''
                          <?php } ?> value="7">Designation</option>

                          <option <?php if ($sortby=='8') { ?>
                            selected=''
                          <?php } ?> value="8">Location</option>

                          <option <?php if ($sortby=='9') { ?>
                            selected=''
                          <?php } ?> value="9">Department</option>

                          <option <?php if ($sortby=='10') { ?>
                            selected=''
                          <?php } ?> value="10">Product</option>






 
                          

                          
                        </select>

                        </div>

                       

                        

                       


                        





                        <div align="center" style="margin-top: 15px;" class="col-md-12 col-sm-12 col-xs-12 margin"><button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Filter</button></div>


                        </form>

                       
                       

                       </div>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    


                    <div style="margin-bottom: 15px;" class="col-md-4 col-sm-4 col-xs-12"><a href="../islem.php?cleancandidatesexport=ok" class="btn btn-block btn-primary exportbtn"><i class="fa fa-download"></i> Download All (.xls)</a></div>

                    <div style="margin-bottom: 15px;" class="col-md-4 col-sm-4 col-xs-12 margin"></div>

                    <div style="margin-bottom: 15px;" class="col-md-4 col-sm-4 col-xs-12 margin"></div>

                 
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Date Created</th>
                          <th>Calling Person</th>
                          <th>Name</th>
                          <th>Company</th>
                          <th>Designation</th>
                          <th>Location</th>
                          <th>Department</th>

                          <th>Product</th>

                          <th>Phone Number</th>

                          <th>LinkedIn</th>
                          <th>Uploaded By</th>
                          <th>Called</th>
                          <th>Exist?</th>

                          

                         
                          

                         
                          
                          
                          <th></th>
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php



if (empty($sortby) or $sortby=='default' or $sortby=='1') {
  
 $query .= " order by candidate_tarihi DESC limit $baslangic,$kacar ";

} else if ($sortby=='2'){

 $query .= " order by candidate_tarihi ASC limit $baslangic,$kacar ";

}  else if ($sortby=='4'){

 $query .= " order by candidate_adsoyad ASC limit $baslangic,$kacar ";

} else if ($sortby=='5'){

 $query .= " order by candidate_adsoyad DESC limit $baslangic,$kacar ";

} else if ($sortby=='6'){

 $query .= " order by candidate_company ASC limit $baslangic,$kacar ";

} else if ($sortby=='7'){

 $query .= " order by candidate_designation ASC limit $baslangic,$kacar ";

} else if ($sortby=='8'){

 $query .= " order by candidate_location ASC limit $baslangic,$kacar ";

} else if ($sortby=='9'){

 $query .= " order by candidate_department ASC limit $baslangic,$kacar ";

} else if ($sortby=='10'){

 $query .= " order by candidate_product ASC limit $baslangic,$kacar ";

} 



                         $candidatesec=$db->prepare($query);
                         $candidatesec->execute();
                         $candidatesay=$candidatesec->rowCount();
                         
                         while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) {

                          $calling_personid = $candidatecek['kullanici_id'];

                          $callingsec = $db->prepare("SELECT * from kullanici where kullanici_id='$calling_personid'");
                          $callingsec->execute();

                          $callingcek = $callingsec->fetch(PDO::FETCH_ASSOC);

                          $callingperson = $callingcek['kullanici_ad']." ".$callingcek['kullanici_soyad'];

                          $candidate_tell = $candidatecek['candidate_telno'];

                         
                          ?>
                            

                            <tr id="candidatetr_<?php echo $candidatecek['candidate_id']; ?>">
                          <td><?php echo $candidatecek['candidate_id']; ?></td>
                          <td><?php echo substr($candidatecek['candidate_tarihi'], 0,10); ?></td>

                          <td><?php echo $callingperson; ?></td>
                          
                          <td><?php echo $candidatecek['candidate_ad']." ".$candidatecek['candidate_soyad']; ?></td>
                          <td><?php echo $candidatecek['candidate_company']; ?></td>
                          <td><?php echo $candidatecek['candidate_designation']; ?></td>
                          <td><?php echo $candidatecek['candidate_location']; ?></td>
                          

                          <td><?php echo $candidatecek['candidate_department']; ?></td>


                          <td><?php echo $candidatecek['candidate_product']; ?></td>
                          
                          <td><a href="tel:<?php echo $candidatecek['candidate_telno']; ?>"><?php echo $candidatecek['candidate_telno']; ?></a></td>

                          <td><?php if (!empty($candidatecek['candidate_linkedin'])) { ?>
                            
                            <a target="_blank" href="<?php echo $candidatecek['candidate_linkedin']; ?>">Go to LinkedIn</a>
                            
                          <?php } ?></td>

                          <td><?php echo $candidatecek['candidate_uploadedby']; ?></td>

                          <td>

                          <?php if ($candidatecek['candidate_called']=='1') { ?>
                            

                            <div style="background-color: green;" class="badge badge-success">Called</div>
                        

                          <?php } else if ($candidatecek['candidate_called']=='0'){ ?>

                            
                           <div style="background-color: orange;" class="badge badge-warning">Not Called</div>

                          <?php } ?>

                          </td>

                          <?php if ($candidatecek['candidate_listed']=='1') { ?>
                           
                           <td>Exist</td>

                          <?php } else { ?>

                          <td>Not Exist</td>

                          <?php } ?>

                         
                           
                          <td>
                            
                            <div class="row">
                              
                              <div align="center" class="col-md-12 col-sm-12 col-xs-12">

                                <?php if ($candidatecek['candidate_called']=='1') { ?>
                                  
                                  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#candidated_<?php echo $candidatecek['candidate_id']; ?>">
  Call Logs
</button>

<!-- Modal -->
<div class="modal fade" id="candidated_<?php echo $candidatecek['candidate_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Call Logs</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Order of Call</th>
                          <th>Time</th>
                          <th>Response</th>
                          <th>Remark</th>
                          <th>Called By</th>
                          
                      </thead>
                      <tbody>
 
                   <?php

                    $candidate_idy = $candidatecek['candidate_id'];
                    

                    $calllogssec=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_idy' order by call_time DESC");
                    $calllogssec->execute();
                    $calllogssay=$calllogssec->rowCount();
                    $i=$calllogssay+1;
                    while ($calllogscek=$calllogssec->fetch(PDO::FETCH_ASSOC)) { $i--; ?>
                      
                      <tr>

                          <td><?php echo $i; ?></td>
                          <td><?php echo $calllogscek['call_time']; ?></td>
                          <td><?php echo $calllogscek['call_response']; ?></td>
                          <td><?php if (strlen($calllogscek['call_remark'])==0) {

                            echo "N/A";

                          } else {

                            echo $calllogscek['call_remark'];

                          } ?></td>

                          <td><?php echo $calllogscek['caller']; ?></td>
                          
                        </tr>

                    <?php } ?>

                        
                        
                      </tbody>
                    </table>

                    <a style="color: #fff;" href="../islem.php?calllogsdownload=ok&candidate_id=<?php echo $candidate_idy; ?>" class="btn exportbtn"><i class="fa fa-download"></i> Download</a>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>                    
                               <?php } ?>

                                <?php if ($candidatecek['candidate_listed']=='1') { ?>
                                  
                                  <a target="_blank" style="color: #fff;" class="btn exportbtn btn-sm" href="candidate-profile?candidate_id=<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-user"></i> Profile</a>

                                <?php } else { ?>

                                   <a class="btn btn-warning btn-sm" href="edit-dumb-candidate?candidate_id=<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-edit"></i> Edit</a>


                                <?php } ?>


                                <a class="btn btn-warning btn-sm exportbtn" href="../islem.php?candidateexport=ok&candidate_id=<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-download"></i></a>

                   
                               

                                <a class="btn btn-success btn-sm" data-toggle="modal" data-target="#candidatedx_<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-plus"></i> Add to List</a></div>


                                <!-- Modal -->
<div class="modal fade" id="candidatedx_<?php echo $candidatecek['candidate_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Add Candidate to Calling List</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <form onsubmit="return false;" id="form_<?php echo $candidatecek['candidate_id']; ?>">

          <div class="row">
            

       <div class="col-md-12 col-xs-12">
         
        <input type="text" readonly="" class="form-control" value="<?php echo $candidatecek['candidate_adsoyad']; ?>">

       </div>

       

       <div style="margin-top: 20px;" class="col-md-12 col-xs-12">
         
        <select class="form-control" name="kullanici_id" id="employeeselect_<?php echo $candidatecek['candidate_id']; ?>">

          <option value="select">Select Employee</option>
          

<?php $employeesec=$db->prepare("SELECT * from kullanici where kullanici_yetki='1' order by kullanici_adsoyad ASC");
$employeesec->execute();
while ($employeecek=$employeesec->fetch(PDO::FETCH_ASSOC)) { ?>

  
  
<option value="<?php echo $employeecek['kullanici_id']; ?>"><?php echo $employeecek['kullanici_adsoyad']." (".$employeecek['kullanici_id'].")"; ?></option>

<?php } ?>
 

        </select>

        <input type="hidden" value="<?php echo $candidatecek['candidate_id']; ?>" name="candidate_id">

        <input type="hidden" name="candidateaddlist">

       </div>

       <br>

          </div>

                    <div style="margin-top: 20px;" align="center" class="col-md-12">
                      <a style="color: #fff;" href="javascript:void(0);" class="btn exportbtn btn-block applybuton" name="buton_<?php echo $candidatecek['candidate_id']; ?>">Add</a>
                    </div>

                    <br>

                    </form>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>     

                               

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($candidatetestsay>$kacar) { 

                       $key = 'p';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="clean-dump-data?p=<?php echo $sayfa-1; ?>"

     <?php } else { ?>


       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa-1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa-1; ?>"


      <?php } ?>
       

    <?php } ?> aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++;

  if ($p<=$sayfa+3 and $p>=$sayfa-3) {

   ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="clean-dump-data?p=<?php echo $p; ?>"
        
     <?php } else { ?>

       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $p; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $p; ?>"


      <?php } ?>

    <?php } ?>  ><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="clean-dump-data?p=<?php echo $sayfa+1; ?>"
        
     <?php } else { ?>

 <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa+1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa+1; ?>"


      <?php } ?>

     <?php } ?>  aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.deletecandidate').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var candidate_id=id1.substring(10);

swal({
  title: "Are you sure?",
  text: "This candidate will be deleted.",
  icon: "warning",
  buttons: ["Cancel", "Delete"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Deleting...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'deletecandidate':'ok','candidate_id':candidate_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



             if (sonuc=="ok") {


              $('#candidatetr_'+candidate_id).remove();
             

              

             }

               }

             });

   }

   })

         });

          $('.applybuton').click(function(){

 var buton = $(this);
 var id1=$(this).attr("name");
 var candidate_id=id1.substring(6);

 var employee = $('#employeeselect_'+candidate_id).val();

 buton.prop('disabled',true);

 if (employee=='select') {

alert('Please select an employee.');

 } else {


var data = $('#form_'+candidate_id).serialize();


 $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : data,
            success : function(sonuc){

              sonuc=$.trim(sonuc);



             if (sonuc=="ok") {


             
             buton.replaceWith('<span align="center" style="color:green;font-size:17px;"><i class="fa fa-check"></i> Added to List</span>');

              

             } else if (sonuc=='exist'){

        //If Exist

        swal({
  title: "Phone No. Exist in Calling Panel",
  text: "Do you want overrule dump infos to exist candidate? (Except calling employee)",
  icon: "info",
  buttons: ["Cancel", "Overrule"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Applying...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'addandoverruledata':'ok','candidate_id':candidate_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



            if (sonuc=="ok") {


              location.reload();
             

              

             }

               }

             });

   }

   })

        // If Exist

             }

               }

             });

 }






         });

       </script>

       