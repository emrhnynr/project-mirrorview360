<?php require_once 'header.php';

$candidate_id = $_GET['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

$candidate_title = $candidatecek['candidate_adsoyad']." (".$candidatecek['candidate_telno'].")";

$referredbysec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$referredbysec->execute();

$referredbysay = $referredbysec->rowCount();

if ($referredbysay!=0) {
  
$referredbycek=$referredbysec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $referredbycek['referrer_id'];

$referrercandidatesec=$db->prepare("SELECT * from candidates where candidate_id='$referrer_id'");
$referrercandidatesec->execute();
$referrercandidatecek=$referrercandidatesec->fetch(PDO::FETCH_ASSOC);

$referrer_telno = $referrercandidatecek['candidate_telno']; 

$titlereferedby = "<a target='_blank' href='candidate-profile?candidate_id=$referrer_id'><u>$referrer_telno</u></a>";


 } else {

$titlereferedby = 'N/A';

}




$query = "SELECT * from referchain where referrer_id='$candidate_id'";




//------------------------------------------------------------------------




$candidatetestsec=$db->prepare($query);
$candidatetestsec->execute();
$candidatetestsay = $candidatetestsec->rowCount();

$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=10;
$sayfasayisi=ceil($candidatetestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($candidatetestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../admin/");
 }

 ?>

 <style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><a target="_blank" href="candidate-profile?candidate_id=<?php echo $candidate_id; ?>"><u><?php echo $candidate_title; ?></u></a> Refers | Referred By : <?php echo $titlereferedby; ?></h2>


                    

                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <p style="text-align: center;font-size: 17px;"><?php echo $candidatetestsay; ?> data found.</p>

                   
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Date Created</th>
                          <th>Calling Person</th>
                          <th>Name</th>
                          <th>Company</th>
                          <th>Designation</th>
                          <th>Location</th>
                          <th>Department</th>

                          <th>Product</th>

                          <th>Phone Number</th>

                          <th>Referred By</th>

                          <th>Count of Refers</th>

                         

                        

                         
                          

                         
                          
                          
                          <th></th>
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php



if (empty($sortby) or $sortby=='default' or $sortby=='1') {
  
 $query .= " order by referred_id ASC limit $baslangic,$kacar ";

} 



                         $referchainsec=$db->prepare($query);
                         $referchainsec->execute();
                         
                         
                         while ($referchaincek=$referchainsec->fetch(PDO::FETCH_ASSOC)) {


                          $referred_idd = $referchaincek['referred_id'];

                          $candidatesec2=$db->prepare("SELECT * from candidates where candidate_id='$referred_idd'");
                          $candidatesec2->execute();
                          $candidatecek2=$candidatesec2->fetch(PDO::FETCH_ASSOC);

                          $candidate_listed=$candidatecek2['candidate_listed'];

                          $candidate_idd = $candidatecek2['candidate_id'];


                          $calling_personid = $candidatecek2['kullanici_id'];

                          $callingsec = $db->prepare("SELECT * from kullanici where kullanici_id='$calling_personid'");
                          $callingsec->execute();

                          $callingcek = $callingsec->fetch(PDO::FETCH_ASSOC);

                          $callingperson = $callingcek['kullanici_ad']." ".$callingcek['kullanici_soyad'];

                           
                          $countrefersec=$db->prepare("SELECT * from referchain where referrer_id='$candidate_idd'");
                          $countrefersec->execute();
                          $countrefersay=$countrefersec->rowCount();


                         

                          ?>
                            

                            <tr id="candidatetr_<?php echo $candidatecek2['candidate_id']; ?>">
                          <td><?php echo $candidatecek2['candidate_id']; ?></td>
                          <td><?php echo substr($candidatecek2['candidate_tarihi'], 0,10); ?></td>
                          <td><?php echo $callingperson; ?></td>
                          <td><?php echo $candidatecek2['candidate_ad']." ".$candidatecek2['candidate_soyad']; ?></td>
                          <td><?php echo $candidatecek2['candidate_company']; ?></td>
                          <td><?php echo $candidatecek2['candidate_designation']; ?></td>
                          <td><?php echo $candidatecek2['candidate_location']; ?></td>
                          

                          <td><?php echo $candidatecek2['candidate_department']; ?></td>


                          <td><?php echo $candidatecek2['candidate_product']; ?></td>
                          
                          <td><a href="tel:<?php echo $candidatecek2['candidate_telno']; ?>"><?php echo $candidatecek2['candidate_telno']; ?></a></td>

                          <td><a
                            
                           target='_blank' href='candidate-profile?candidate_id=<?php echo $candidate_id; ?>'

                         ><?php echo $candidatecek['candidate_telno']; ?></a></td>

                          <td><?php echo $countrefersay; ?></td>

                         
                           
                          <td>


                            
                            <div class="row">
                              
                              <div align="center" class="col-md-12 col-sm-12 col-xs-12">

                   
                                 
<?php if ($countrefersay!=0) { ?>
 
 <a class="btn btn-primary btn-sm" target="_blank" href="referrer-refers?candidate_id=<?php echo $candidatecek2['candidate_id']; ?>">
  All Refers
</a>

<?php } ?>


                            <?php if ($candidate_listed=='1') { ?>


                              <a target="_blank" class="btn btn-success btn-sm" href="candidate-profile?candidate_id=<?php echo $candidatecek2['candidate_id']; ?>"><i class="fa fa-user"></i> Profile</a></div>

                            <?php } else { ?>

                                   <a class="btn btn-warning btn-sm" href="edit-dumb-candidate?candidate_id=<?php echo $candidatecek2['candidate_id']; ?>"><i class="fa fa-edit"></i> Edit</a>


                                <?php } ?>

                               

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($candidatetestsay>$kacar) { 

                       $key = 'p';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" 


       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa-1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa-1; ?>"


      <?php } ?>
       

     aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++;

  if ($p<=$sayfa+3 and $p>=$sayfa-3) {

   ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" 

       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $p; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $p; ?>"


      <?php } ?>

     ><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" 

 <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa+1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa+1; ?>"


      <?php } ?>

       aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.deletecandidate').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var candidate_id=id1.substring(10);

swal({
  title: "Are you sure?",
  text: "This candidate will be deleted.",
  icon: "warning",
  buttons: ["Cancel", "Delete"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Deleting...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'deletecandidate':'ok','candidate_id':candidate_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



             if (sonuc=="ok") {


              $('#candidatetr_'+candidate_id).remove();
             

              

             }

               }

             });

   }

   })

         })

       </script>

       