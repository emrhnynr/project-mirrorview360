<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-user-plus"></i> Register New Employee</h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form id="registeremployeeform" class="form-horizontal form-label-left" onsubmit="return false;">

                     
                      <span class="section">Personal Info</span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_ad" class="form-control col-md-7 col-xs-12" maxlength="200" name="kullanici_ad"  type="text">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Surname <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_soyad" class="form-control col-md-7 col-xs-12" maxlength="200" type="text" name="kullanici_soyad">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="kullanici_telno" name="kullanici_telno" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="email" id="kullanici_mail" name="kullanici_mail" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label for="password" class="control-label col-md-3">Password <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_password" type="text" name="kullanici_password" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                     

                     

                      

                       <div class="item form-group">
                        <label for="password" class="control-label col-md-3">City Name</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_sehir" name="kullanici_sehir" type="text" maxlength="300" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      
                      

                     <input type="hidden" name="employeeregister">
                     
                  
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">

                          <div style="display: none;" class="alert alert-info uyari"></div>

                          <div style="display: none;" class="alert alert-success uyari2"><i class="fa fa-check"></i> Employee has registered successfully.</div>
                         
                          <button id="send" type="submit" class="btn btn-success registerbuton">Register</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
          
          $('#registeremployeeform').submit(function(){

var kullanici_ad = $.trim($('#kullanici_ad').val());
          var kullanici_soyad = $.trim($('#kullanici_soyad').val());
         var kullanici_mail = $.trim($('#kullanici_mail').val());
         var kullanici_telno = $.trim($('#kullanici_telno').val());
        var kullanici_password = $('#kullanici_password').val();
        var kullanici_password2 = $('#kullanici_password2').val();
      var form = $('#registeremployeeform')[0];
             var data = new FormData(form);

             if (kullanici_ad.length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Name field can't be empty.");

             } else if (kullanici_soyad.length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Surname field can't be empty.");

             } else if (kullanici_telno.length<10) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Phone number field can't be shorter than 10 characters.");

             } else if (kullanici_mail.length<6) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Mail field can't be shorter than 6 characters.");

             } else if (kullanici_password.length<6) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Password field can't be shorter than 6 characters.");

             } else {


               $('.uyari').hide();
               $('.uyari2').hide();
$('.registerbuton').prop('disabled',true);
$('.registerbuton').html('Please Wait...');


$.ajax({
            type : 'POST',
            url : '../islem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

                sonuc=$.trim(sonuc);

               

                
                if (sonuc=="ok") {

                 $('.uyari').hide();
                  $('.uyari2').show();
                  $('#registeremployeeform').trigger('reset');
                  $('.registerbuton').prop('disabled',false);
$('.registerbuton').html('Register');

                } else if (sonuc=='mevcutmail'){

 
               $('.uyari').show();
               $('.uyari').html("<i class='fa fa-info-circle'></i> This mail address is already exist.");
                  $('.uyari2').hide();
                  $('.registerbuton').prop('disabled',false);
$('.registerbuton').html('Register');
               

                } else if (sonuc=='hata'){


                  $('.uyari').show();
               $('.uyari').html("<i class='fa fa-info-circle'></i> Something wrong.");
                  $('.uyari2').hide();
                  $('.registerbuton').prop('disabled',false);
$('.registerbuton').html('Register');

                } 
                

                 }

               });

             }


          })

        </script>