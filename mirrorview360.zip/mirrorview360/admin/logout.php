<?php session_start();

if (isset($_SESSION['adminoturum'])) {
	
	unset($_SESSION['subadminoturumc']);
	unset($_SESSION['subadminoturump']);
unset($_SESSION['adminoturum']);
unset($_SESSION['kullanicioturum']);
Header("Location:../login");

} else if (isset($_SESSION['kullanicioturum'])){

unset($_SESSION['subadminoturumc']);
unset($_SESSION['subadminoturump']);
unset($_SESSION['adminoturum']);
unset($_SESSION['kullanicioturum']);
Header("Location:../login");

} else if (isset($_SESSION['subadminoturumc'])){

unset($_SESSION['subadminoturumc']);
unset($_SESSION['subadminoturump']);
unset($_SESSION['adminoturum']);
unset($_SESSION['kullanicioturum']);
Header("Location:../login");

} else if (isset($_SESSION['subadminoturump'])){

unset($_SESSION['subadminoturumc']);
unset($_SESSION['subadminoturump']);
unset($_SESSION['adminoturum']);
unset($_SESSION['kullanicioturum']);
Header("Location:../login");

} else {

	Header("Location:../login");
}


 ?>