<?php require_once 'header.php';


if (!empty($_GET['search'])) {

  $search = $_GET['search'];


 };

 if (isset($_GET['search']) and strlen(trim($_GET['search']))>0) {
                         
                         $query = "SELECT * from kullanici where kullanici_yetki='1' and (kullanici_id LIKE '$search%' or kullanici_id LIKE '%$search%' or kullanici_id LIKE '%$search' or kullanici_adsoyad LIKE '$search%' or kullanici_adsoyad LIKE '%$search%' or kullanici_adsoyad LIKE '%$search' or kullanici_telno LIKE '%$search' or kullanici_telno LIKE '$search%' or kullanici_telno LIKE '%$search%' or kullanici_sehir LIKE '$search%' or kullanici_sehir LIKE '%$search%' or kullanici_sehir LIKE '%$search')";

                        } else {

                          $query = "SELECT * from kullanici where kullanici_yetki='1'";

                        }


if (isset($_GET['sortby'])) {

  $sortby = $_GET['sortby'];

} else {

  $sortby = 'default';
}

if (empty($sortby) or $sortby=='default' or $sortby=='1') {
  
 $query .= ' order by kullanici_kayitzaman DESC ';

} else if ($sortby=='2'){

 $query .= ' order by kullanici_kayitzaman ASC ';

} else if ($sortby=='3'){

 $query .= ' order by kullanici_adsoyad ASC ';

} else if ($sortby=='4'){

 $query .= ' order by kullanici_adsoyad DESC ';

} else if ($sortby=='5'){

 $query .= ' order by kullanici_datamodified DESC ';

} else if ($sortby=='6'){

 $query .= ' order by kullanici_datamodified ASC ';

} 



  ?>

<style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Employees</h2>

                    <div  class="col-xs-12 col-sm-7 col-md-7 nav navbar-right panel_toolbox">


                       <div class="row">

                        <form action="employees" method="GET">
                         
                        <div class="col-md-5 col-sm-4 col-xs-12 margin"><input <?php if (isset($_GET['search']) and $_GET['search']!='') { ?>
                         value ='<?php echo $_GET['search']; ?>'
                        <?php } ?> type="text" placeholder="ID, Name, Phone, City" maxlength="150" name="search" class="form-control"></div>

                        <div class="col-md-4 col-sm-4 col-xs-12 margin"><select class="form-control" name="sortby">
                          
                          <option value="default">Sort By</option>

                          <option <?php if ($sortby=='1') { ?>
                            selected=''
                          <?php } ?> value="1">Date Created (New to Old)</option>

                          <option <?php if ($sortby=='2') { ?>
                            selected=''
                          <?php } ?> value="2">Date Created (Old to New)</option>

                          <option <?php if ($sortby=='3') { ?>
                            selected=''
                          <?php } ?> value="3">Name (A-Z)</option>

                          <option <?php if ($sortby=='4') { ?>
                            selected=''
                          <?php } ?> value="4">Name (Z-A)</option>
 
                          <option <?php if ($sortby=='5') { ?>
                            selected=''
                          <?php } ?> value="5">Last Modified (New to Old)</option>

                          <option <?php if ($sortby=='6') { ?>
                            selected=''
                          <?php } ?> value="6">Last Modified (Old to New)</option>

                          
                        </select></div>

                        <div class="col-md-3 col-sm-4 col-xs-12 margin"><button type="submit" class="btn btn-block btn-primary"><i class="fa fa-search"></i> Search</button></div>


                        </form>

                       </div>
                    
                       
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="row">

                      <div class="col-md-4 col-sm-4 col-xs-12 margin"><a href="../islem.php?employeesexport=ok" class="btn btn-block btn-primary exportbtn"><i class="fa fa-download"></i> Download All Employees (.xls)</a></div>

                        
                         <div class="col-md-4 col-sm-4 col-xs-12"></div>


                         <div class="col-md-4 col-sm-4 col-xs-12"></div>
                       

                        
  
                        

                       </div>

                       <br>
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Status</th>
                          <th>Date Created</th>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Surname</th>
                          <th>Phone Number</th>
                          <th>Mail</th>
                          <th>Password</th>
                          <th>City Name</th>
                          <th>Last Modified</th>
                          
                          
                          
                          <th></th>
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php 

                         $kullanicisec=$db->prepare($query);
                         $kullanicisec->execute();
                         while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {?>
                            

                            <tr id="employee_<?php echo $kullanicicek['kullanici_id']; ?>">
                              <td><?php   $sonzaman=strtotime($kullanicicek['kullanici_songiris']);
                          $suan=time();
                          $fark=$suan-$sonzaman;
                          if ($fark<300) { ?>
                            <i style="color: green;" class="fa fa-circle" aria-hidden="true"></i> Online
                          <?php } else { ?>
                           <i style="color: red;" class="fa fa-circle" aria-hidden="true"></i> Offline
                          <?php } ?></td>
                          <td><?php echo substr($kullanicicek['kullanici_kayitzaman'],0,10) ?></td>
                          <td><?php echo $kullanicicek['kullanici_id']; ?></td>
                          <td><?php echo $kullanicicek['kullanici_ad']; ?></td>
                          <td><?php echo $kullanicicek['kullanici_soyad']; ?></td>
                          <td><a href="tel:<?php echo $kullanicicek['kullanici_telno']; ?>"><?php echo $kullanicicek['kullanici_telno']; ?></a></td>
                          <td><a href="mailto:<?php  echo $kullanicicek['kullanici_mail'];  ?>"><?php echo $kullanicicek['kullanici_mail']; ?></td></a>
                          <td><?php echo $kullanicicek['kullanici_password']; ?></td>
                          <td><?php echo $kullanicicek['kullanici_sehir']; ?></td>
                          <td><?php echo substr($kullanicicek['kullanici_datamodified'],0,10); ?></td>
                          
                          
                          
                          <td>
                            
                            <div class="row">

                              <div class="col-md-4 col-sm-4 col-xs-12"><a class="btn btn-primary btn-block btn-sm" href="employee-reports?employee_id=<?php echo $kullanicicek['kullanici_id']; ?>"><i class="fa fa-signal"></i> Reports</a></div>
                              
                              <div class="col-md-4 col-sm-4 col-xs-12"><a class="btn btn-warning btn-block btn-sm" href="edit-employee?employee_id=<?php echo $kullanicicek['kullanici_id']; ?>"><i class="fa fa-edit"></i> Edit</a></div>

                               <div class="col-md-4 col-sm-4 col-xs-12">
                                 
                                 <?php if ($kullanicicek['kullanici_aktif']=='active') { ?>

                                   <a class="btn btn-danger btn-block btn-sm deactiveemployee" name="employee_<?php echo $kullanicicek['kullanici_id']; ?>" href="javascript:void(0);">Deactivate</a>

                                <?php } else { ?>

                                  <a class="btn btn-success btn-block btn-sm activeemployee" name="employee_<?php echo $kullanicicek['kullanici_id']; ?>" href="javascript:void(0);">Activate</a>


                                <?php } ?>

                               </div>

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                   

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.deactiveemployee').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var kullanici_id=id1.substring(9);

swal({
  title: "Are you sure?",
  text: "Do you want to deactivate this employee?",
  icon: "warning",
  buttons: ["Cancel", "Deactivate"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'deactiveemployee':'ok','kullanici_id':kullanici_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);



            if (sonuc=="ok") {

               buton.replaceWith('<a class="btn btn-danger btn-block btn-sm activeemployee" name="employee_'+kullanici_id+'" href="javascript:void(0);"><i class="fa fa-check"></i> Deactivated</a>');

              

             }

               }

             });

   }

   })

         });



         //-----------------------------


         $('.activeemployee').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var kullanici_id=id1.substring(9);

swal({
  title: "Are you sure?",
  text: "Do you want to activate this employee?",
  icon: "warning",
  buttons: ["Cancel", "Activate"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'activeemployee':'ok','kullanici_id':kullanici_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);



             if (sonuc=="ok") {


              buton.replaceWith('<a class="btn btn-success btn-block btn-sm deactiveemployee" name="employee_'+kullanici_id+'" href="javascript:void(0);"><i class="fa fa-check"></i> Activated</a>');

              

             }

               }

             });

   }

   })

         });

       </script>