<?php require_once 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-upload"></i> Upload Excel File</h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form id="uploadexcelform" class="form-horizontal form-label-left" onsubmit="return false;">

                     
                      

                     

                       

                      

                      


                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Excel File *
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          
                          <input type="file" id="file" class="form-control">

                        </div>
                      </div>

                     


                       
                      
                      
                     

                     
                     
                  
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">

                          <div style="display: none;" class="alert alert-info uyari"></div>

                          <div style="display: none;" class="alert alert-success uyari2"><i class="fa fa-check"></i> File has uploaded successfully.</div>
                         
                          <button id="send" type="submit" class="btn btn-success uploadbuton">Upload</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
          
          $('.uploadbuton').click(function(){

                var input = $('#file');
var dosya = $('#file').val();
var filevalue = $('#file').get(0).files[0];
var dosyauzanti = dosya.split('.').pop();

var data = new FormData();
data.append('uploadexcel',"ok");
data.append("file",filevalue);

 if ($('#file').val().length==0){

 $('.uyari').show();
 $('.uyari2').hide();
$('.uyari').html('<i class="fa fa-info-circle"></i> Please upload a file.');

  } else {

  $('.uploadbuton').prop('disabled',true);
  $('.uploadbuton').html('Uploading...');

  $.ajax({
            type : 'POST',
            url : '../islem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);

 
      
      if (sonuc=="ok") {

        $('.uyari').hide();
        $('.uyari2').show();
        $('.uploadbuton').html('Uploaded!');
        $('#file').val('');
        

      } else if (sonuc=="notsupportedfile") {

     $('.uyari').show();
 $('.uyari2').hide();
$('.uyari').html('<i class="fa fa-info-circle"></i> This file is not an excel file.');
$('.uploadbuton').prop('disabled',false);
  $('.uploadbuton').html('Upload');
        

      }

 }

 });


   }

              })

        </script>