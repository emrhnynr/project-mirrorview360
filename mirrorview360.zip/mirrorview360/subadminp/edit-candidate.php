<?php require_once 'header.php';


if ($kullanici_editallowed=='no') {
  
  Header("Location:index");
  exit;
}


$candidate_id = $_GET['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id' and candidate_listed='1'");
$candidatesec->execute();
$candidatesay=$candidatesec->rowCount();

if ($candidatesay==0) {
  
  header("Location:../subadminp/");
  exit;

}

$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-user"></i> Edit Candidate : <?php echo $candidatecek['candidate_id']; ?></h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form id="editcandidateform" class="form-horizontal form-label-left" onsubmit="return false;">

                     
                      <span class="section">Personal Info</span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Calling Person <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          
                          <select class="form-control" id="kullanici_id" name="kullanici_id">
                            
                            

                            <?php $peoplesec = $db->prepare("SELECT * from kullanici where kullanici_yetki='1' order by kullanici_ad ASC");
                            $peoplesec->execute();

                            while ($peoplecek=$peoplesec->fetch(PDO::FETCH_ASSOC)) { ?>
                              
                              <option <?php if ($peoplecek['kullanici_id']==$candidatecek['kullanici_id']) { ?>
                                selected=''
                              <?php } ?> value="<?php echo $peoplecek['kullanici_id']; ?>"><?php echo $peoplecek['kullanici_ad']." ".$peoplecek['kullanici_soyad']." (".$peoplecek['kullanici_id'].")"; ?></option>

                             <?php } ?>

                          </select>

                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="candidate_ad" class="form-control col-md-7 col-xs-12" value="<?php echo $candidatecek['candidate_ad']; ?>" maxlength="200" name="candidate_ad"  type="text">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Surname
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="candidate_soyad" class="form-control col-md-7 col-xs-12" maxlength="200" value="<?php echo $candidatecek['candidate_soyad']; ?>" type="text" name="candidate_soyad">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_telno" name="candidate_telno" value="<?php echo $candidatecek['candidate_telno']; ?>" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                    
                      


                     

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Linkedin URL
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_linkedin" name="candidate_linkedin" value="<?php echo $candidatecek['candidate_linkedin']; ?>" maxlength="500" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>



                    
                      
                      
                     

                     <input type="hidden" name="editcandidateadmin">
                     <input type="hidden" value="<?php echo $candidatecek['candidate_id'] ?>" name="candidate_id">
                     
                  
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">

                          <div style="display: none;" class="alert alert-info uyari"></div>

                          <div style="display: none;" class="alert alert-success uyari2"><i class="fa fa-check"></i> Candidate has edited successfully.</div>

                         
                         
                          <button id="send" type="submit" class="btn btn-success editbuton">Edit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
          
          $('#editcandidateform').submit(function(){

var kullanici_id = $('#kullanici_id').val();
var candidate_ad = $.trim($('#candidate_ad').val());
          var candidate_soyad = $.trim($('#candidate_soyad').val());
        var candidate_linkedin = $('#candidate_linkedin').val();
        var candidate_telno = $.trim($('#candidate_telno').val());
      var form = $('#editcandidateform')[0];
             var data = new FormData(form);

             if (candidate_ad.length==0) {

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Name field can't be empty.");

             } else if (candidate_telno.length<10) {

$('.uyari').show();
$('.uyari').html("<i class='fa fa-info-circle'></i> Phone number field can't be shorter than 10 characters.");

             } else {


               $('.uyari').hide();
$('.editbuton').prop('disabled',true);
$('.editbuton').html('Please Wait...');


$.ajax({
            type : 'POST',
            url : '../islem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

                sonuc=$.trim(sonuc);

               

                
                if (sonuc=="ok") {

                 $('.uyari').hide();
                 $('.uyari2').show();
                 $('.editbuton').prop('disabled',false);
                 $('.editbuton').html('Edit');

                }
                

                 }

               });

             }


          })

        </script>