<?php
ob_start();
session_start();
require_once '../db.php';
include '../fonksiyon.php';

date_default_timezone_set('Asia/Kolkata');


if (empty($_SESSION)) {
    
    Header("Location:../login");
    exit;

  } else if (isset($_SESSION['adminoturum'])){ 

    Header("Location:../admin/");
    exit;

  } else if (isset($_SESSION['kullanicioturum'])){ 

    Header("Location:../people/");
    exit;

  } else if (isset($_SESSION['subadminoturumc'])){ 

    Header("Location:../subadminc/");
    exit;

  } ;


$adminsessionsec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$adminsessionsec->execute(array(

"mail" => $_SESSION['subadminoturump']

));

$adminsessionsay = $adminsessionsec->rowCount();

if ($adminsessionsay==0) {

  Header("Location:logout");
  exit;
}

$adminsessioncek=$adminsessionsec->fetch(PDO::FETCH_ASSOC);


$songirisim=strtotime($adminsessioncek['kullanici_songiris']);
$suan=time(); 
$fark=$suan-$songirisim;
if ($fark>300 or empty($adminsessioncek['kullanici_songiris'])) {

  $hazirla=$db->prepare("UPDATE kullanici set 
    kullanici_songiris=:kullanici_songiris

    where kullanici_id={$adminsessioncek['kullanici_id']}
    ");
  $derle=$hazirla->execute(array(
    "kullanici_songiris" => date("Y-m-d H:i:s")
  ));

};

$kullanici_profileviewlimit = $adminsessioncek['kullanici_profileviewlimit'];
$kullanici_lastprofileview = $adminsessioncek['kullanici_lastprofileview'];
$kullanici_todayprofileview = $adminsessioncek['kullanici_todayprofileview'];
$kullanici_dailydownloadlimit = $adminsessioncek['kullanici_dailydownloadlimit'];
$kullanici_monthlydownloadlimit = $adminsessioncek['kullanici_monthlydownloadlimit'];
$kullanici_todaydownload = $adminsessioncek['kullanici_todaydownload'];
$kullanici_thismonthdownload = $adminsessioncek['kullanici_thismonthdownload'];
$kullanici_lastdownload = $adminsessioncek['kullanici_lastdownload'];
$kullanici_editallowed = $adminsessioncek['kullanici_editallowed'];

   ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Calling Candidate System</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">

<style type="text/css">
  
  .exportbtn {

background-color: #11733D;
border-color: #11733D;

  }

  .exportbtn:hover {

background-color: #0D4E2B;
border-color: #0D4E2B;

  }

</style>

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index" class="site_title"><i class="fa fa-laptop"></i> <span>Panel</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $adminsessioncek['kullanici_ad']." ".$adminsessioncek['kullanici_soyad']; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>MANAGE</h3>
               <ul class="nav side-menu">
                  
                  <li><a href="../subadminp/"><i class="fa fa-home"></i> Home</span></a>
                  <li><a href="employees"><i class="fa fa-users"></i> Employees</span></a></li>


                <li><a href="clean-dump-data"><i class="fa fa-arrow-right"></i> Clean Dump Data</a></li>

                <li><a href="refer-chain"><i class="fa fa-chain"></i> Refer Chain</a></li>

                  
                    <li><a href="candidates"><i class="fa fa-user"></i> Candidates</span></a>

                      <?php if ($kullanici_editallowed=='yes') { ?>
                        
                        <li><a href="add-candidate"><i class="fa fa-plus"></i> Add New Candidate</span></a>

                      <?php } ?>
                  
                  <li><a href="excel-files"><i class="fa fa-file"></i> Excel Files</span></a>

                <?php if ($kullanici_editallowed=='yes') { ?>

                  <li><a href="upload-excel"><i class="fa fa-upload"></i> Upload Excel File</span></a>


                    <li><a href="register-employee"><i class="fa fa-user-plus"></i> Register New Employee</span></a>


                    <?php } ?>
                    

                  <li><a><i class="fa fa-database"></i> Dump Data <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <?php if ($kullanici_editallowed=='yes') { ?>

                      <li><a href="upload-dump-excel">Upload Dump (.xlsx)</a></li>

                    <?php } ?>
                    
                      
                      <li><a href="raw-dump-data">Raw Dump Data</a></li>
                      

                      
                    </ul>
                  </li>

                 
                    
                 <li><a href="sub-admins"><i class="fa fa-key"></i> Child Sub-Admins</span></a>
                  <li><a href="add-new-child-sub-admin"><i class="fa fa-plus"></i> Add New Sub-Admin (Child)</a></li>

                  <li><a href="log-book"><i class="fa fa-sign-in"></i> Log Book</span></a></li>
                 
                </ul>
              </div>
              

            </div>
            <!-- /sidebar menu -->

           
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $adminsessioncek['kullanici_ad']." ".$adminsessioncek['kullanici_soyad']; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="change-password"> Change Password</a></li>
                  
                    
                    <li><a href="logout"><i class="fa fa-sign-out pull-right"></i> Logout</a></li>
                  </ul>
                </li>

                
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->