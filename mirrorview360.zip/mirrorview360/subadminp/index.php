<?php require_once 'header.php';

$kullanici_idd = $adminsessioncek['kullanici_id'];

 ?>

<style type="text/css">
   
@media only screen and (max-width: 768px) {

.baslik {

  margin-top: 28px;
}

#dateinput {

  margin-top: 22px;
}

.gobtn {

  margin-top: 10px;
}

}


}

 </style>


        <!-- page content -->
        <div class="right_col" role="main">

          <div class="container">
          
       <div align="center" class="col-md-12 col-sm-12 col-xs-12">

        <h3 align="left">Call Response Report <span style="font-size: 17px;">(All Employees)</span><p style="font-size: 16px;margin-top: 10px;">Remaining Profile View Today : <?php echo $adminsessioncek['kullanici_profileviewlimit']-$adminsessioncek['kullanici_todayprofileview']; ?></p>



                          <p style="font-size: 16px;">Remaining Download Today : <?php echo $adminsessioncek['kullanici_dailydownloadlimit']-$adminsessioncek['kullanici_todaydownload']; ?></p><hr></h3>

        <div  class="col-xs-12 col-sm-12 col-md-12 nav navbar-right panel_toolbox">
                       <div class="row">

                        <form onsubmit="return false;" action="candidates" method="GET">

                         
                         
                        <div class="col-md-3 col-sm-4 col-xs-12 margin"><a href="../islem.php?alldataexport=ok" class="btn btn-block btn-primary exportbtn"><i class="fa fa-download"></i> Download All Data</a></div>

                        <div class="col-md-4 col-sm-4 col-xs-12 margin"></div>

                        <div class="col-md-3 col-sm-4 col-xs-12 margin"><input type="date" id="dateinput" class="form-control"></div>

                        <div class="col-md-2 col-sm-4 col-xs-12 margin"><button type="submit" class="btn btn-block btn-primary gobtn"> Show</button></div>


                        </form>

                       </div>
                    </div>

                    <br><br>

       
         
         

                          <div class="row icerikk" style="margin-top: 20px;padding-bottom: 150px;">
                            

                            <?php $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT candidate_id from candidates where candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT candidate_id from candidates where candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             
                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>

                            
                          </div>



                        


                         
                         
                   
                    
                   
                  

       </div>

       

       </div>

     
          
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">


 


                 $('.gobtn').click(function(){

     var zaman = $('#dateinput').val();



$('.icerikk').html('<h4 style="font-family:Arial;" align="center">Loading...</h4>');

$('.gobtn').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : '../islem.php',
            data : {'zaman':zaman,'adminstatssec':'ok'},
            success : function(sonuc){

                sonuc=$.trim(sonuc);



                $('.gobtn').prop('disabled',false);
                $('.todayspan').hide();

                $('.icerikk').html(sonuc);

                $('.exportbtn').html('<i class="fa fa-download"></i> Download Data ('+zaman+')');
                $('.exportbtn').attr('href','../islem.php?specificdataexport=ok&date='+zaman);

              

                

                 }

                });

          });



              
          
         
        

        </script>