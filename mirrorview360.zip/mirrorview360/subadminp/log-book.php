<?php require_once 'header.php';



if (isset($_GET['sortby'])) {

  $sortby = $_GET['sortby'];

} else {

  $sortby = 'default';
}


$query = "SELECT * from logbook where kullanici_yetki<10 ";

if (isset($_GET['usertype']) and $_GET['usertype']!='notselected') {
  
  $filterusertype = $_GET['usertype'];
  $query .= " AND (kullanici_yetki='$filterusertype') ";

}


if (isset($_GET['logindate']) and $_GET['logindate']) {
  
  $filterlogindate = $_GET['logindate'];
  $query .= " AND (DATE(login_datetime)='$filterlogindate') ";

}



//------------------------------------------------------------------------




$logbooktestsec=$db->prepare($query);
$logbooktestsec->execute();
$logbooktestsay = $logbooktestsec->rowCount();

$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=30;
$sayfasayisi=ceil($logbooktestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($logbooktestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../subadminp/");
 }

 ?>

 <style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Log Book</h2>


                    

                     <div style="margin-top: 15px;" class="col-xs-12 col-sm-12 col-md-12 nav navbar-right panel_toolbox">
                       <div class="row">

                        <form action="log-book" method="GET">

                          <div class="col-md-3 col-sm-3 col-xs-12"></div>

                         

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['logindate']) and $_GET['logindate']!='') { ?>
                         value ='<?php echo $_GET['logindate']; ?>'
                        <?php } ?> type="date" name="logindate" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="usertype">

                            <option value="notselected">User Type</option>
                            
                            <option value="4" <?php if (isset($_GET['usertype']) and $_GET['usertype']=='4') { ?>
                         selected=''
                        <?php } ?>>Sub-Admin</option>

                            <option value="1" <?php if (isset($_GET['usertype']) and $_GET['usertype']=='1') { ?>
                         selected=''
                        <?php } ?>>Employee</option>

                           

                          </select>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          
                          <select class="form-control" name="sortby">
                          
                          <option value="default">Sort By</option>

                          <option <?php if ($sortby=='desc') { ?>
                            selected=''
                          <?php } ?> value="desc">Login Date (New to Old)</option>

                          <option <?php if ($sortby=='asc') { ?>
                            selected=''
                          <?php } ?> value="asc">Login Date (Old to New)</option>

                         
            
                          
                        </select>

                        </div>


                        



                        <div align="center" style="margin-top: 15px;" class="col-md-12 col-sm-12 col-xs-12 margin"><button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Filter</button></div>


                        </form>

                       </div>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>

                          <th>Login Time</th>
                          <th>User Type</th>
                          <th>Employee Mail</th>

                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php



if (empty($sortby) or $sortby=='default' or $sortby=='desc') {
  
 $query .= " order by login_datetime DESC limit $baslangic,$kacar ";

} else if ($sortby=='asc'){

 $query .= " order by login_datetime ASC limit $baslangic,$kacar ";

} 



                         $logbooksec=$db->prepare($query);
                         $logbooksec->execute();
                         $logbooksay=$logbooksec->rowCount();
                         
                         while ($logbookcek=$logbooksec->fetch(PDO::FETCH_ASSOC)) {

                          $kullanici_id = $logbookcek['kullanici_id'];

                          $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
                          $kullanicisec->execute();

                          $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

                          $usermail = $kullanicicek['kullanici_mail'];

                          if ($logbookcek['kullanici_yetki']==1) {

                            $yetki = 'Employee';
                            

                          } else {

                            $yetki = 'Sub-Admin';


                          }

                          ?>
                            

                            <tr>
                          <td><?php echo $logbookcek['login_datetime']; ?></td>
                          <td><?php echo $yetki ?></td>
                          <td><?php echo $usermail; ?></td>
                         
                          

                          
                         
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($logbooktestsay>$kacar) { 

                       $key = 'p';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['usertype'])) { ?>

        href="log-book?p=<?php echo $sayfa-1; ?>"

     <?php } else { ?>


       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa-1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa-1; ?>"


      <?php } ?>
       

    <?php } ?> aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++;

  if ($p<=$sayfa+3 and $p>=$sayfa-3) {

   ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" <?php if (!isset($_GET['usertype'])) { ?>

        href="log-book?p=<?php echo $p; ?>"
        
     <?php } else { ?>

       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $p; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $p; ?>"


      <?php } ?>

    <?php } ?>  ><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['usertype'])) { ?>

        href="log-book?p=<?php echo $sayfa+1; ?>"
        
     <?php } else { ?>

 <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa+1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa+1; ?>"


      <?php } ?>

     <?php } ?>  aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       

       