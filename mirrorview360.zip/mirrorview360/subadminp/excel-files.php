<?php require_once 'header.php';



         $excelfiletestsec=$db->prepare("SELECT * from excelfiles");
         $excelfiletestsec->execute();

         $excelfiletestsay = $excelfiletestsec->rowCount();


                  $sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=5;
$sayfasayisi=ceil($excelfiletestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($excelfiletestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../subadminp/");
 }


$excelfilesec=$db->prepare("SELECT * from excelfiles order by file_date DESC limit $baslangic,$kacar");
$excelfilesec->execute();

                          ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>All Excel Files Uploaded <span class="successuyari" style="color: green;font-size: 15px;"></span></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Upload Date</th>
                          <th>Uploaded By</th>
                          <th>Uploaded To</th>
                          <th>Number of Candidates</th>
                          <th>Already Exists</th>
                          <th>Download</th>
                          <th></th>
                         
                          
                          
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php 
                         while ($excelfilecek=$excelfilesec->fetch(PDO::FETCH_ASSOC)) {

 $candidate_sayisi = $excelfilecek['candidate_sayisi'];
 $file_date = $excelfilecek['file_date'];
 $uploadedby = $excelfilecek['excel_uploadedby'];

  $excel_to = $excelfilecek['excel_to'];

 if ($excel_to=='callingpanel') {
  
  $excel_to = 'Calling Panel';

 } else if ($excel_to=='dumpdata') {

  $excel_to = 'Dump Data';
   
 }

$existssec=$db->prepare("SELECT * from candidates where candidate_alreadyexist='1' and candidate_tarihi='$file_date'");
 $existssec->execute();
 $existsay=$existssec->rowCount();
                          ?>
                            

                            <tr id="excelfile_<?php echo $excelfilecek['file_id']; ?>">
                          <td><?php echo $file_date; ?></td>

                          <td><?php echo $uploadedby; ?></td>

                          <td><?php echo $excel_to; ?></td>
                          
                          <td><?php echo $candidate_sayisi; ?></td>

                          <?php if ($excel_to=='Dump Data') { ?>

                            <td></td>

                          <?php } else { ?>


                            <td><a target="_blank" href="already-exists?date=<?php echo $file_date; ?>"><b><?php echo $existsay."</b> (See Report)"; ?></a></td>

                          
                        <?php  } ?>

                          <?php if ($kullanici_monthlydownloadlimit<=$kullanici_thismonthdownload) { ?>


                            <td>You have reached monthly download limit.</td>
                            

                          <?php } else if ($kullanici_dailydownloadlimit<=$kullanici_todaydownload){ ?>


                            <td>You have reached daily download limit</td>


                          <?php } else { ?>

                            <td><a class="btn btn-block" href="../<?php echo $excelfilecek['file_path']; ?>" download="<?php echo basename($excelfilecek['file_path']); ?>"><i class="fa fa-download"></i> Download File</a></td>


                          <?php } ?>


                           <td>
                            
                            <div class="row">

                              <?php if ($adminsessioncek['kullanici_editallowed']=='yes') { ?>
                               
                               <div  align="center" class="col-md-12 col-sm-12 col-xs-12"><a class="btn btn-danger btn-sm deleteexcel" name="excel_<?php echo $excelfilecek['file_id']; ?>" href="javascript:void(0);">Delete All</a></div>
                               
                             <?php } ?>
                              
                              

                               

                            </div>

                          </td>
                         
                          
                          
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($excelfiletestsay>$kacar) { ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" href="excel-files?p=<?php echo $sayfa-1; ?>" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++; 

    if ($p<=$sayfa+3 and $p>=$sayfa-3) {

      ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" href="excel-files?p=<?php echo $p; ?>"><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" href="excel-files?p=<?php echo $sayfa+1; ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.deleteexcel').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var file_id=id1.substring(6);

swal({
  title: "Are you sure?",
  text: "All candidates will be deleted in this file.",
  icon: "warning",
  buttons: ["Cancel", "Delete"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Deleting...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'deleteexcel':'ok','file_id':file_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



             if (sonuc=="ok") {


              $('#excelfile_'+file_id).remove();
              $('.successuyari').html('<i class="fa fa-check"></i> File and candidates has deleted.')

              

             }

               }

             });

   }

   })

         })

       </script>