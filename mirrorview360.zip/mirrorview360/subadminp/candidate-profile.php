<?php require_once 'header.php';

$candidate_id = $_GET['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id' and candidate_listed='1'");
$candidatesec->execute();
$candidatesay=$candidatesec->rowCount();

if ($candidatesay==0) {
  
  header("Location:../admin/");
  exit;

}

$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

$kaydeden = $candidatecek['kullanici_id'];

$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_yetki='1' and kullanici_id='$kaydeden'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_adsoyad = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad']." (".$kullanicicek['kullanici_id'].")";

$candidate_response = $candidatecek['candidate_respond'];

$referkontrolsec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$referkontrolsec->execute();
$referkontrolsay=$referkontrolsec->rowCount();

if ($referkontrolsay!=0) {
 
 $referkontrolcek=$referkontrolsec->fetch(PDO::FETCH_ASSOC);

 $referrer_id = $referkontrolcek['referrer_id'];

 $referrercandidatesec=$db->prepare("SELECT * from candidates where candidate_id='$referrer_id'");
 $referrercandidatesec->execute();
 $referrercandidatecek=$referrercandidatesec->fetch(PDO::FETCH_ASSOC);

 $referrer_telno = $referrercandidatecek['candidate_telno'];

}

$subadmin_id = $adminsessioncek['kullanici_id'];



$dahaoncekayitsor = $db->prepare("SELECT * from profileviews where kullanici_id='$subadmin_id' and candidate_id='$candidate_id'");
$dahaoncekayitsor->execute();
$dahaoncekayitsay = $dahaoncekayitsor->rowCount();

if ($dahaoncekayitsay==0) {

$kullanici_lastprofileview = $adminsessioncek['kullanici_lastprofileview'];
$kullanici_profileviewlimit = $adminsessioncek['kullanici_profileviewlimit'];
$kullanici_todayprofileview = $adminsessioncek['kullanici_todayprofileview'];
$dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');
$tarihsaat = date('Y-m-d H:i:s');

if ($tarih==$dtt) {

  
if ($kullanici_profileviewlimit<=$kullanici_todayprofileview) {
  
  $status = 'dur';

} else {

$hazirlak=$db->prepare("UPDATE kullanici set

  kullanici_lastprofileview=:kullanici_lastprofileview,
  kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derlek=$hazirlak->execute(array(
"kullanici_lastprofileview" => $tarihsaat,
"kullanici_todayprofileview" => $kullanici_todayprofileview+1
));


$hazirlap = $db->prepare("INSERT into profileviews set

kullanici_id=:kullanici_id,
candidate_id=:candidate_id

  ");

$derlep = $hazirlap->execute(array(

"kullanici_id" => $subadmin_id,
"candidate_id" => $candidate_id

));


$status = 'devam';

}


} else {

 

$hazirlak=$db->prepare("UPDATE kullanici set

  kullanici_lastprofileview=:kullanici_lastprofileview,
  kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derlek=$hazirlak->execute(array(
"kullanici_lastprofileview" => $tarihsaat,
"kullanici_todayprofileview" => 1
));

$hazirlap = $db->prepare("INSERT into profileviews set

kullanici_id=:kullanici_id,
candidate_id=:candidate_id

  ");

$derlep = $hazirlap->execute(array(

"kullanici_id" => $subadmin_id,
"candidate_id" => $candidate_id

));

$status = 'devam';
  
}

 } else {

$status = 'devam';

 }

 ?>

 <style type="text/css">
   
@media only screen and (max-width: 768px) {

.baslik {

  margin-top: 28px;
}

}

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Candidate Profile</h2>
                    
                    <div class="clearfix"></div>
                  </div>

                  <?php if ($status=='dur') { ?>

                  <div class="x_content">
                    
                    <h2 align="center">Your daily profile view limit has reached.</h2>
                  </div>

                <?php } else { ?>


                  
                    


                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img width="100" height="100" src="images/user.png" alt="" class="img-circle img-responsive">
                        </div>
                      </div>
                      <h3><?php echo $candidatecek['candidate_adsoyad']; ?><hr></h3>

                      <ul class="list-unstyled user_data">

                         <li><a style="font-size: 16px;"># ID : <?php echo $candidatecek['candidate_id']; ?></a>
                        </li>

                        <li><a style="font-size: 16px;" href="tel:<?php echo $candidatecek['candidate_telno']; ?>"><i class="fa fa-phone user-profile-icon"></i> <?php echo $candidatecek['candidate_telno']; ?></a>
                        </li>
                     

                        <li><a target="_blank" href="<?php echo $candidatecek['candidate_linkedin']; ?>" style="font-size: 16px;"><i class="fa fa-external-link user-profile-icon"></i> Go to Linkedin</a>
                        </li>

                         <li><a target="_blank" href="candidate-documents?candidate_id=<?php echo $candidatecek['candidate_id']; ?>" style="font-size: 16px;"><i class="fa fa-folder-o"></i> Documents</a>
                        </li>

            <br>


            <li style="font-size: 16px;"><i style="color: #23527C;" class="fa fa-user user-profile-icon"></i> Calling Person : <?php echo $kullanici_adsoyad; ?></li>
                      </ul>

                     

                      <div class="col-md-12 col-sm-12 col-xs-12" style="border: 1px solid #e7e7e7;padding: 10px;border-radius: 8px;margin-bottom: 15px;">

                     <?php if ($candidatecek['candidate_called']=='1') { ?>
                        
                        <div class="badge badge-success" style="background-color: green;">Called</div>
                        

                      <?php } else if ($candidatecek['candidate_called']=='0') { ?>
                        
                        <div class="badge badge-success" style="background-color: orange;">Not called</div>

                      <?php } ?>


                      </div>

                     

                      

                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">

                      <div class="profile_title">
                        <div class="col-md-6">
                          
                          <h2>Candidate Details</h2>

                          
                        
                        </div>
                        <div class="col-md-6">
                         
                            
                            
                          </div>
                        </div>

                        <div style="padding-top: 20px;" class="x_content">

                          <form onsubmit="return false;" class="form-horizontal form-label-left" id="page2form">

                          <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Interested to <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">


                          <div style="margin-top: 7px;" class="form-check">
  <input class="form-check-input" type="radio" <?php if ($candidatecek['candidate_interestedto']=='becomeassociate') { ?>
                              checked=''
                            <?php } ?> value="becomeassociate" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault1">
    Become Associate
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" <?php if ($candidatecek['candidate_interestedto']=='becomefulltimeemployee') { ?>
                              checked=''
                            <?php } ?> value="becomefulltimeemployee" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    Become Full Time Employee
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="radio" <?php if ($candidatecek['candidate_interestedto']=='none') { ?>
                              checked=''
                            <?php } ?> value="none" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    None
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="radio" <?php if ($candidatecek['candidate_interestedto']=='company') { ?>
                              checked=''
                            <?php } ?> value="company" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    Company
  </label>
</div>
                        

                         
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Looking for a job change? 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_jobchange" name="candidate_jobchange">
                            
                             <?php if (empty($candidatecek['candidate_jobchange'])) { ?>
                              
                              <option value="select">Select</option>
                              
                            <?php } ?>

                            <option <?php if ($candidatecek['candidate_jobchange']=='yes') { ?>
                              selected=''
                            <?php } ?> value="yes">Yes</option>

                            <option <?php if ($candidatecek['candidate_jobchange']=='no') { ?>
                              selected=''
                            <?php } ?> value="no">No</option>

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Company Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_company" value="<?php echo $candidatecek['candidate_company']; ?>" name="candidate_company" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Designation
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_designation" value="<?php echo $candidatecek['candidate_designation']; ?>" name="candidate_designation" maxlength="300" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">E-mail
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_mail" value="<?php echo $candidatecek['candidate_mail']; ?>" name="candidate_mail" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_product" name="candidate_product">
                            
                             
                              
                            <option value="select">Select</option>
                              
                            

                            <option <?php if ($candidatecek['candidate_product']=='Personal Loan') { ?>
                             selected=''
                            <?php } ?> >Personal Loan</option>

                            <option <?php if ($candidatecek['candidate_product']=='Business Loan') { ?>
                             selected=''
                            <?php } ?> >Business Loan</option>

                            <option <?php if ($candidatecek['candidate_product']=='Home Loan') { ?>
                             selected=''
                            <?php } ?> >Home Loan</option>

                            <option <?php if ($candidatecek['candidate_product']=='Loan Against Property') { ?>
                             selected=''
                            <?php } ?> >Loan Against Property</option>

                            <option <?php if ($candidatecek['candidate_product']=='Commercial Vehicle Loan') { ?>
                             selected=''
                            <?php } ?> >Commercial Vehicle Loan</option>

                            <option <?php if ($candidatecek['candidate_product']=='Gold Loan') { ?>
                             selected=''
                            <?php } ?> >Gold Loan</option>

                            <option <?php if ($candidatecek['candidate_product']=='Branch Banking') { ?>
                             selected=''
                            <?php } ?> >Branch Banking</option>

                            <option <?php if ($candidatecek['candidate_product']=='Broking') { ?>
                             selected=''
                            <?php } ?> >Broking</option>

                            <option <?php if ($candidatecek['candidate_product']=='Insurance') { ?>
                             selected=''
                            <?php } ?> >Insurance</option>

                            <option <?php if ($candidatecek['candidate_product']=='Credit Card') { ?>
                             selected=''
                            <?php } ?> >Credit Card</option>

                            <option <?php if ($candidatecek['candidate_product']=='Others') { ?>
                             selected=''
                            <?php } ?> >Others</option>

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Department
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_department" name="candidate_department">
                            
                             
                              
                            <option value="select">Select</option>


                          
                              
                            

                            <option <?php if ($candidatecek['candidate_department']=='Sales') { ?>
                              selected=''
                           <?php } ?> >Sales</option>

                            <option <?php if ($candidatecek['candidate_department']=='Credit') { ?>
                              selected=''
                           <?php } ?> >Credit</option>

                            <option <?php if ($candidatecek['candidate_department']=='Operations') { ?>
                              selected=''
                           <?php } ?> >Operations</option>

                            <option <?php if ($candidatecek['candidate_department']=='IT') { ?>
                              selected=''
                           <?php } ?> >IT</option>

                            <option <?php if ($candidatecek['candidate_department']=='Others') { ?>
                              selected=''
                           <?php } ?> >Others</option>

                            

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Location Pincode
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_pincode" value="<?php echo $candidatecek['candidate_pincode']; ?>" name="candidate_pincode" placeholder="6 digit number" maxlength="6" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Location Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_location" value="<?php echo $candidatecek['candidate_location']; ?>" name="candidate_location" maxlength='200' class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      
                      <br>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Current Salary
                        </label>
                        <div style="padding-left: 25px;" class="col-md-6 col-sm-6 col-xs-12 row">

                          <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <select class="form-control" id="salary_monthlyannually" name="salary_monthlyannually">
                              
                    
                       <option <?php if ($candidatecek['salary_monthlyannually']=='monthly') { ?> selected='' <?php } ?> value="monthly">Monthly</option>
                   
                     <option <?php if ($candidatecek['salary_monthlyannually']=='annually') { ?> selected='' <?php } ?> value="annually">Annually</option>

                            </select>
                          </div>

                           <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <input class="form-control" placeholder="Amount" value="<?php echo $candidatecek['salary_amount']; ?>" type="number" name="salary_amount" id='salary_amount'>
                          </div>

                           <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <select class="form-control" id="salary_measure" name="salary_measure">
                          
                      <option <?php if ($candidatecek['salary_measure']=='thousands') { ?> selected='' <?php } ?> value="thousands">Thousands</option>  
                     <option <?php if ($candidatecek['salary_measure']=='lakhs') { ?> selected='' <?php } ?> value="lakhs">Lakhs</option>
                     

                            </select>
                          </div>
                          
                        </div>
                      </div>


                      <br>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Total Year Experience
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          
                          <input class="form-control" type="number" value="<?php echo $candidatecek['candidate_experience']; ?>" id="candidate_experience" max='100' name="candidate_experience">

                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Referred By (Phone No.)
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" <?php if ($referkontrolsay!=0) { ?>

                            value='<?php echo $referrer_telno; ?>'


                           <?php } ?> id="candidate_referredby" name="candidate_referredby" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <br><br>

                      <div class="accordion" id="accordionExample">
  
  <div class="card">
    <div align="center" style="border: 1px solid #043d75;" class="card-header" id="headingTwo">
      <h2 style="color: #043d75;" class="mb-0">
        <button style="color: #043d75;font-size: 17px;" class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
         Dump Data <i class="fa fa-chevron-down"></i> 
        </button>
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body" style="padding: 15px;border: 1px solid #e7e7e7;">

        <!-- 129 Data -->
        
        <div class="row">

          <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">First Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_firstname" value="<?php echo $candidatecek['candidate_firstname']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                     <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Middle Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_middlename" value="<?php echo $candidatecek['candidate_middlename']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                     <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastname" value="<?php echo $candidatecek['candidate_lastname']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                     <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Employee Mail
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_employeemail" value="<?php echo $candidatecek['candidate_employeemail']; ?>" maxlength="150" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

      <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Date of Birth
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_birthdate" value="<?php echo $candidatecek['candidate_birthdate']; ?>" maxlength="40" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Current Industry
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_industry" value="<?php echo $candidatecek['candidate_industry']; ?>" maxlength="150" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Years In Current Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_currentjobexperience" value="<?php echo $candidatecek['candidate_currentjobexperience']; ?>" maxlength="30" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Current Functional Area
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_currentfunctionalarea" value="<?php echo $candidatecek['candidate_currentfunctionalarea']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Banking Department
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_bankingdepartment" value="<?php echo $candidatecek['candidate_bankingdepartment']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Banking Sub Department
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_bankingsubdepartment" value="<?php echo $candidatecek['candidate_bankingsubdepartment']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Location - More Than One City?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_multiplelocation" value="<?php echo $candidatecek['candidate_multiplelocation']; ?>" maxlength="10" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Multiple City Names
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_multiplelocationnames" value="<?php echo $candidatecek['candidate_multiplelocationnames']; ?>" maxlength="400" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Preffered Location
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_prefferedlocation" value="<?php echo $candidatecek['candidate_prefferedlocation']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Gender
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_gender" value="<?php echo $candidatecek['candidate_gender']; ?>" maxlength="50"  class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Total Work Experience
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_totalworkexperience" value="<?php echo $candidatecek['candidate_totalworkexperience']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Current Annual Salary
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_annualsalary" value="<?php echo $candidatecek['candidate_annualsalary']; ?>" maxlength="60" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Email ID Official
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_emailidofficial" value="<?php echo $candidatecek['candidate_emailidofficial']; ?>" maxlength="150" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Deeesha's E-Mail
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_deeshamail" value="<?php echo $candidatecek['candidate_deeshamail']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Deeesha Group Website Source
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_websitesource" value="<?php echo $candidatecek['candidate_websitesource']; ?>" maxlength="500" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Contact Number 2
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_telno2" value="<?php echo $candidatecek['candidate_telno2']; ?>" maxlength="50" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Whatsapp Number 1
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_wpno" value="<?php echo $candidatecek['candidate_wpno']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Whatsapp Number 2
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_wpno2" value="<?php echo $candidatecek['candidate_wpno2']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Notice Period
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_noticeperiod" value="<?php echo $candidatecek['candidate_noticeperiod']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Highest Education Level
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_highesteducationlevel" value="<?php echo $candidatecek['candidate_highesteducationlevel']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Highest Education Stream
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_highesteducationstream" value="<?php echo $candidatecek['candidate_highesteducationstream']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Highest Education Insitute
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_highesteducationinsitute" value="<?php echo $candidatecek['candidate_highesteducationinsitute']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Year of Passing
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_yearofpassing" value="<?php echo $candidatecek['candidate_yearofpassing']; ?>" maxlength="40" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Highest Education Course Type
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_highesteducationcoursetype" value="<?php echo $candidatecek['candidate_highesteducationcoursetype']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Create Date
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_createdate" value="<?php echo $candidatecek['candidate_createdate']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Modified Date
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastmodifieddate" value="<?php echo $candidatecek['candidate_lastmodifieddate']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Active Date
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastactivedate" value="<?php echo $candidatecek['candidate_lastactivedate']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Note
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_note" value="<?php echo $candidatecek['candidate_note']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Person Description Summary
                        </label>
                        <div class=" col-xs-12">
                          <textarea name="candidate_summarydescription" rows="6" maxlength="10000" class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_summarydescription']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Total Work Experience as Per Shine
                        </label>
                        <div class=" col-xs-12">
                          <textarea name="candidate_experiencepershine" rows="6" maxlength="10000" class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_experiencepershine']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastjob" value="<?php echo $candidatecek['candidate_lastjob']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last to Last Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lasttolastjob" value="<?php echo $candidatecek['candidate_lasttolastjob']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Graduation Course
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_graducationcourse" value="<?php echo $candidatecek['candidate_graducationcourse']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Graduation College
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_graduationcollege" value="<?php echo $candidatecek['candidate_graduationcollege']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Skills
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_skills" value="<?php echo $candidatecek['candidate_skills']; ?>" maxlength="300" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">May Also Know
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_mayalsoknow" value="<?php echo $candidatecek['candidate_mayalsoknow']; ?>" maxlength="300" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Tier City
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_tiercity" value="<?php echo $candidatecek['candidate_tiercity']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Loan Product
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_loanproduct" value="<?php echo $candidatecek['candidate_loanproduct']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Loan Sub-Product
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_loansubproduct" value="<?php echo $candidatecek['candidate_loansubproduct']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Internal Source
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_internalsource" value="<?php echo $candidatecek['candidate_internalsource']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Source Type (Excel/SQL)
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_sourcetype" value="<?php echo $candidatecek['candidate_sourcetype']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">External Source
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_externalsource" value="<?php echo $candidatecek['candidate_externalsource']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Referred By (Name)
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_refferredname" value="<?php echo $candidatecek['candidate_refferredname']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Referred By (Bankname of the Person)
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_refferredbankname" value="<?php echo $candidatecek['candidate_refferredbankname']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Referred By (Person ID)
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_referredid" value="<?php echo $candidatecek['candidate_referredid']; ?>" maxlength="20" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Date of Entry
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_dateofentry" value="<?php echo $candidatecek['candidate_dateofentry']; ?>" maxlength="40" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Deeesha Employee Name Who Referred
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_deeshaemployeenamerefer" value="<?php echo $candidatecek['candidate_deeshaemployeenamerefer']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Deeesha Employee Name Who Entered Data
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_deeshaemployeenameenter" value="<?php echo $candidatecek['candidate_deeshaemployeenameenter']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Birthday
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_birthday" value="<?php echo $candidatecek['candidate_birthday']; ?>" maxlength="150" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Marriage Anniversary Day
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_marriageanniv" value="<?php echo $candidatecek['candidate_marriageanniv']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Access Date & Time
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastaccessdate" value="<?php echo $candidatecek['candidate_lastaccessdate']; ?>" maxlength="40" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Access Person
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastaccessperson" value="<?php echo $candidatecek['candidate_lastaccessperson']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Deeesha Employee Feedback on Person
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_deeshaemployeefeedback" value="<?php echo $candidatecek['candidate_deeshaemployeefeedback']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Remark / Comment By Deeesha Employee
                        </label>
                        <div class=" col-xs-12">
                          <textarea type="text" name="candidate_deeshaemployeecomment" rows="6" maxlength="10000" class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_deeshaemployeecomment']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Current Boss Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_currentbossname" value="<?php echo $candidatecek['candidate_currentbossname']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Ex-Boss Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_exbossname" value="<?php echo $candidatecek['candidate_exbossname']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                     <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Last Call by Deeesha Employee
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_lastcallbydeeeshaemp" value="<?php echo $candidatecek['candidate_lastcallbydeeeshaemp']; ?>" maxlength="300" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Interesting Facts About Person
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_interestingfact" value="<?php echo $candidatecek['candidate_interestingfact']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Languages Spoken
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_languagesspeak" value="<?php echo $candidatecek['candidate_languagesspeak']; ?>" maxlength="170" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Preffered Language
                        </label>
                        <div class=" col-xs-12"> 
                          <input type="text" name="candidate_languageprefer" value="<?php echo $candidatecek['candidate_languageprefer']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Mother Tongue
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_mothertongue" value="<?php echo $candidatecek['candidate_mothertongue']; ?>" maxlength="70" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Banker
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_banker" value="<?php echo $candidatecek['candidate_banker']; ?>" maxlength="120" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Residence Address
                        </label>
                        <div class=" col-xs-12">
                          <textarea name="candidate_residenceaddress" maxlength="10000" rows="6"  class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_residenceaddress']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Company's Address
                        </label>
                        <div class=" col-xs-12">
                          <textarea name="candidate_companyaddress" maxlength="10000" rows="6" class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_companyaddress']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Country
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_country" value="<?php echo $candidatecek['candidate_country']; ?>" maxlength="50" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Reporting Manager's No.
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_reportingmanagerno" value="<?php echo $candidatecek['candidate_reportingmanagerno']; ?>" maxlength="100" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Saturdays Working?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_saturdayworking" value="<?php echo $candidatecek['candidate_saturdayworking']; ?>" maxlength="50" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Associate - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_associatedeeesha" value="<?php echo $candidatecek['candidate_associatedeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Banker - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_bankerdeeesha" value="<?php echo $candidatecek['candidate_bankerdeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Customer - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_customerdeeesha" value="<?php echo $candidatecek['candidate_customerdeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Candidate - Finploy
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_candidatefinploy" value="<?php echo $candidatecek['candidate_candidatefinploy']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Company - Finploy
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_companyfinploy" value="<?php echo $candidatecek['candidate_companyfinploy']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Associate - Finploy
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_associatefinploy" value="<?php echo $candidatecek['candidate_associatefinploy']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Company - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_companyfinterno" value="<?php echo $candidatecek['candidate_companyfinterno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Intern - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_internfinterno" value="<?php echo $candidatecek['candidate_internfinterno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Associate - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_associatefinterno" value="<?php echo $candidatecek['candidate_associatefinterno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Company - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_companyfintubhai" value="<?php echo $candidatecek['candidate_companyfintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Customer - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_customerfintubhai" value="<?php echo $candidatecek['candidate_customerfintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Associate - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_associatefintubhai" value="<?php echo $candidatecek['candidate_associatefintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Associate - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idassociatedeeesha" value="<?php echo $candidatecek['candidate_idassociatedeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Banker - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idbankerdeeesha" value="<?php echo $candidatecek['candidate_idbankerdeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Customer - Deeesha
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idcustomerdeeesha" value="<?php echo $candidatecek['candidate_idcustomerdeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Candidate - Finploy
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idcandidatefinploy" value="<?php echo $candidatecek['candidate_idcandidatefinploy']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                  


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Associate - Finploy
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idassociatefinploy" value="<?php echo $candidatecek['candidate_idassociatefinploy']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Company - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idcompanyfinterno" value="<?php echo $candidatecek['candidate_idcompanyfinterno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Intern - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idintern" value="<?php echo $candidatecek['candidate_idintern']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Associate - Finterno
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idassociatefinterno" value="<?php echo $candidatecek['candidate_idassociatefinterno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Company - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idcompanyfintubhai" value="<?php echo $candidatecek['candidate_idcompanyfintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Customer - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idcustomerfintubhai" value="<?php echo $candidatecek['candidate_idcustomerfintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">ID Associate - Fintubhai
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_idassociatefintubhai" value="<?php echo $candidatecek['candidate_idassociatefintubhai']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Other City
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_othercity" value="<?php echo $candidatecek['candidate_othercity']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Name as You Want on Certificate
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_nameoncertificate" value="<?php echo $candidatecek['candidate_nameoncertificate']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Mother's Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_mothername" value="<?php echo $candidatecek['candidate_mothername']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Father's Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_fathername" value="<?php echo $candidatecek['candidate_fathername']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Father's Contact No
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_fathertelno" value="<?php echo $candidatecek['candidate_fathertelno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Mother's Contact No
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_mothertelno" value="<?php echo $candidatecek['candidate_mothertelno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Registration on Site
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_registrationsite" value="<?php echo $candidatecek['candidate_registrationsite']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Are you interested in Banking/Finance/Industry?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_interestedinbankingetc" value="<?php echo $candidatecek['candidate_interestedinbankingetc']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Interests
                        </label>
                        <div class=" col-xs-12">
                          <textarea name="candidate_interests" maxlength="10000" rows="6" class="form-control col-md-12 col-xs-12"><?php echo $candidatecek['candidate_interests']; ?></textarea>
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">No. of Past Internships
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_noofpastinternships" value="<?php echo $candidatecek['candidate_noofpastinternships']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Past Internships
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_pastinternships" value="<?php echo $candidatecek['candidate_pastinternships']; ?>" maxlength="400" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Duration of Internship
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_durationofinternship" value="<?php echo $candidatecek['candidate_durationofinternship']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Have you done an internship with Deeesha?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_haveyoudonewithdeeesha" value="<?php echo $candidatecek['candidate_haveyoudonewithdeeesha']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Are you looking for an educational loan?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_areyoulookeducationloan" value="<?php echo $candidatecek['candidate_areyoulookeducationloan']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Roles In Previous Internship
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_rolesinpreviousinternship" value="<?php echo $candidatecek['candidate_rolesinpreviousinternship']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">What type of internship are you looking for?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_typeofinternship" value="<?php echo $candidatecek['candidate_typeofinternship']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Would you like to join as a full time employee?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_joinasafulltimeemployee" value="<?php echo $candidatecek['candidate_joinasafulltimeemployee']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">What type of internship do you prefer? Part Time / Full Time
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_internshipprefer" value="<?php echo $candidatecek['candidate_internshipprefer']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">How many hours can you dedicate?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_hoursdedicate" value="<?php echo $candidatecek['candidate_hoursdedicate']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Do you have personalized laptop at home?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_personalizedlaptop" value="<?php echo $candidatecek['candidate_personalizedlaptop']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Do you have stable internet connection?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_stableconnection" value="<?php echo $candidatecek['candidate_stableconnection']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">What type of internship do you prefer? In Office / Work From Home
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_typeofinternship2" value="<?php echo $candidatecek['candidate_typeofinternship2']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">How many days you prefer a week?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_howdaysworkaweek" value="<?php echo $candidatecek['candidate_howdaysworkaweek']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">What is your desired income?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_desiredincome" value="<?php echo $candidatecek['candidate_desiredincome']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Do you have technical knowledge?
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_havetechnicalknowledge" value="<?php echo $candidatecek['candidate_havetechnicalknowledge']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Professor Contact No.
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="candidate_professortelno" value="<?php echo $candidatecek['candidate_professortelno']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_name" maxlength="200" value="<?php echo $candidatecek['linkedin_name']; ?>" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Pos Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_namepos" maxlength="200" value="<?php echo $candidatecek['linkedin_namepos']; ?>" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Company Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_companyname" value="<?php echo $candidatecek['linkedin_companyname']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin City Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_cityname" value="<?php echo $candidatecek['linkedin_cityname']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin State Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_statename" value="<?php echo $candidatecek['linkedin_statename']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Country Name
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_namecountry" value="<?php echo $candidatecek['linkedin_namecountry']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Current Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_currentjob" value="<?php echo $candidatecek['linkedin_currentjob']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Second Last Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_secondlastjob" value="<?php echo $candidatecek['linkedin_secondlastjob']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Third Job
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_thirdlastjob" value="<?php echo $candidatecek['linkedin_thirdlastjob']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Highest Education
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_highesteducation" value="<?php echo $candidatecek['linkedin_highesteducation']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Second Education
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_secondeducation" value="<?php echo $candidatecek['linkedin_secondeducation']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Skills
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_skills" value="<?php echo $candidatecek['linkedin_skills']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Interests
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_interests" value="<?php echo $candidatecek['linkedin_interests']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    

                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin Accomplishment
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_accomplishment" value="<?php echo $candidatecek['linkedin_accomplishment']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>


                    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="item form-group">
                        <label class="  col-xs-12" for="email">Linkedin URL from Scraper
                        </label>
                        <div class=" col-xs-12">
                          <input type="text" name="linkedin_urlfromscrapper" value="<?php echo $candidatecek['linkedin_urlfromscrapper']; ?>" maxlength="200" class="form-control col-md-12 col-xs-12">
                        </div>
                      </div>

                    </div>

      

    </div>

      </div>
    </div>
  </div>
  
</div>

                    

                    <br><hr><br>

                          <div class="row">
                            
                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='FULLY Interested') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='FULLY Interested') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">FULLY Interested</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Send me details I will see') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Send me details I will see') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Send me details I will see</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Busy right now, call later') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Busy right now, call later') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Busy right now, call later</span>

                                </div></a>


                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Wrong Number') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Wrong Number') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Wrong Number</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='FULLY Not Interested') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='FULLY Not Interested') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">FULLY Not Interested</span>

                                </div></a>

                               
                               

                              
                            </div>


                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF NOT CONNECTED</h4>

                              </div>

                              <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Mobile Switch Off') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Mobile Switch Off') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Mobile Switch Off</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Call Not Answered') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Call Not Answered') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Call Not Answered</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Out of Network Area') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Out of Network Area') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Out of Network Area</span>

                                </div></a>


                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='Call Rejected') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='Call Rejected') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Call Rejected</span>

                                </div></a>

                               

                            </div>

                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF INTERESTED THEN</h4>

                              </div>

                              <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='1st round Whatsapp group made / message sent') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='1st round Whatsapp group made / message sent') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">1st round Whatsapp group made / message sent</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="<?php if ($candidate_response=='2nd round called again check if interested') { ?>

                                  border:2px solid green;

                                <?php } else { ?>

                                  border:1px solid #e7e7e7;


                                <?php } ?> height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios <?php if ($candidate_response=='2nd round called again check if interested') { ?>

                                  selected

                                  <?php } ?>">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">2nd round called again check if interested</span>

                                </div></a>

                               

                            </div>



                          </div>


                          <hr>

                          <textarea class="form-control" id="remark" name="candidate_remark" placeholder="ANY REMARKS" maxlength="3000" rows="5"><?php echo $candidatecek['candidate_remark']; ?></textarea>


                          <?php if ($kullanici_editallowed=='yes') { ?>
                           
                           

                          

                          <div class="col-dm-12 col-xs-12 col-sm-12" align="right">

                            <input id="candidate_id" type="hidden" value="<?php echo $candidatecek['candidate_id']; ?>" name="candidate_id">
                            <input type="hidden" name="markcandidate">
                            <input type="hidden" value="<?php if($candidatecek['candidate_called']=='1'){ ?>

                            yes

                            <?php } else { ?>

                           no

                           <?php } ?>" id="calledmi">

                           <br>


                           <div align="left" style="display: none;" class="alert alert-info uyari"></div>
                            <div align="left" style="display: none;" class="alert alert-success successalert"><i class="fa fa-check"></i> Candidate data has saved successfully.</div>

                          
                            <button id="submitbuton" class="btn btn-primary">Submit</button>


                            </div>

                          <?php } ?>

                            </form>
                         
                   
                    
                   
                  </div>

                      </div>
                      

                      

                    
                    
                  </div>



                <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
       $('.radios').click(function(){

        

var buton = $(this);

$('.radios').css('border','1px solid #e7e7e7');
$('div').removeClass('selected');

buton.css('border','2px solid green');
buton.addClass('selected');


$('#submitbuton').click(function(){

  var response = $.trim($('.selected').find('span').html());

var submitbuton = $('#submitbuton');



var remark = $.trim($('#remark').val());
var candidate_id = $('#candidate_id').val();

var checkedradio = $('input:radio:checked').length;
var candidate_company = $.trim($('#candidate_company').val());
         var candidate_designation = $.trim($('#candidate_designation').val());
         var candidate_mail = $.trim($('#candidate_mail').val());
         var candidate_product = $.trim($('#candidate_product').val());
         var candidate_department = $.trim($('#candidate_department').val());
        var candidate_pincode = $('#candidate_pincode').val();
        var candidate_location = $('#candidate_location').val();
        var candidate_interestedto = $('input[name="candidate_interestedto"]:checked').val();
          var candidate_jobchange = $('#candidate_jobchange').val();
          var candidate_experience = $('#candidate_experience').val();
          var salary_monthlyannually = $('#salary_monthlyannually').val();
          var salary_amount = $('#salary_amount').val();
          var salary_measure = $('#salary_measure').val();


          var data = $("#page2form").serializeArray();
data.push({name: "candidate_response",value: response});



if (checkedradio==0) {

  $('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Please check an interested to option.");


 } else {



              $('#submitbuton').prop('disabled',true);
              $('#submitbuton').html('Saving...');
              $('.uyari').hide();




 $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : $.param(data),
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              
           

             if (sonuc=="ok") {


             $('.successalert').show();
             $('.uyari').hide();

              submitbuton.html('Saved Successfully.');

             } else if (sonuc=="refernotexistphone"){


$('#submitbuton').prop('disabled',false);
$('#submitbuton').html('Submit');
alert('Referred By : There is no such a candidate number.');


             }

               }

             }); 


  


  }




});


       });



       var calledmi = $.trim($('#calledmi').val());

       

       if (calledmi=='yes') {

$('#submitbuton').click(function(){

  var response = $.trim($('.selected').find('span').html());

var submitbuton = $('#submitbuton');


var remark = $.trim($('#remark').val());
var candidate_id = $('#candidate_id').val();

var candidate_company = $.trim($('#candidate_company').val());
         var candidate_designation = $.trim($('#candidate_designation').val());
          var candidate_mail = $.trim($('#candidate_mail').val());
         var candidate_product = $.trim($('#candidate_product').val());
         var candidate_department = $.trim($('#candidate_department').val());
        var candidate_pincode = $('#candidate_pincode').val();
        var candidate_location = $('#candidate_location').val();
        var candidate_interestedto = $('input[name="candidate_interestedto"]:checked').val();
          var candidate_jobchange = $('#candidate_jobchange').val();
          var candidate_experience = $('#candidate_experience').val();
          var salary_monthlyannually = $('#salary_monthlyannually').val();
          var salary_amount = $('#salary_amount').val();
          var salary_measure = $('#salary_measure').val();


          var data = $("#page2form").serializeArray();
data.push({name: "candidate_response",value: response});


$.ajax({

   type : 'POST',
            url : '../islem.php',
             data : $.param(data),
            success : function(sonuc){

              sonuc=$.trim(sonuc);

              $('#submitbuton').prop('disabled',true);
$('#submitbuton').html('Saving...');
$('.uyari').hide();


             if (sonuc=="ok") {


             $('.successalert').show();
             $('.uyari').hide();

              submitbuton.html('Saved Successfully.');

             } else if (sonuc=="refernotexistphone"){


$('#submitbuton').prop('disabled',false);
$('#submitbuton').html('Submit');
alert('Referred By : There is no such a candidate number.');


             }

               }

             });

 




})


       }





       </script>