<?php require_once 'header.php';

$datee = $_GET['date'];

if (isset($_GET['sortby'])) {

  $sortby = $_GET['sortby'];

} else {

  $sortby = 'default';
}


$query = "SELECT * from candidates where candidate_tarihi='$datee'";

if (isset($_GET['id']) and $_GET['id']) {
  
  $filterid = $_GET['id'];
  $query .= " AND (candidate_id='$filterid') ";

}

if (isset($_GET['name']) and $_GET['name']) {
  
  $filtername = $_GET['name'];
  $query .= " AND (candidate_adsoyad LIKE '$filtername%' or candidate_adsoyad LIKE '%$filtername%' or candidate_adsoyad LIKE '%$filtername') ";

}

if (isset($_GET['company']) and $_GET['company']) {
  
  $filtercompany = $_GET['company'];
  $query .= " AND (candidate_company LIKE '$filtercompany%' or candidate_company LIKE '%$filtercompany%' or candidate_company LIKE '%$filtercompany') ";

}


if (isset($_GET['designation']) and $_GET['designation']) {
  
  $filterdesignation = $_GET['designation'];
  $query .= " AND (candidate_designation LIKE '$filterdesignation%' or candidate_designation LIKE '%$filterdesignation%' or candidate_designation LIKE '%$filterdesignation') ";

}


if (isset($_GET['product']) and $_GET['product']!='notselected') {
  
  $filterproduct = $_GET['product'];
  $query .= " AND (candidate_product LIKE '$filterproduct%' or candidate_product LIKE '%$filterproduct%' or candidate_product LIKE '%$filterproduct') ";

}

if (isset($_GET['department']) and $_GET['department']!='notselected') {
  
  $filterdepartment = $_GET['department'];
  $query .= " AND (candidate_department LIKE '$filterdepartment%' or candidate_department LIKE '%$filterdepartment%' or candidate_department LIKE '%$filterdepartment') ";

}


if (isset($_GET['location']) and $_GET['location']) {
  
  $filterlocation = $_GET['location'];
  $query .= " AND (candidate_location LIKE '$filterlocation%' or candidate_location LIKE '%$filterlocation%' or candidate_location LIKE '%$filterlocation') ";

}


if (isset($_GET['phone']) and $_GET['phone']) {
  
  $filterphone = $_GET['phone'];
  $query .= " AND (candidate_telno LIKE '$filterphone%' or candidate_telno LIKE '%$filterphone%' or candidate_telno LIKE '%$filterphone') ";

}



if (isset($_GET['existstatus']) and $_GET['existstatus']!='status') {
  
  $filterexiststatus = $_GET['existstatus'];
  $query .= " AND (candidate_alreadyexist='$filterexiststatus') ";

}

//------------------------------------------------------------------------




$candidatetestsec=$db->prepare($query);
$candidatetestsec->execute();
$candidatetestsay = $candidatetestsec->rowCount();

$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=20;
$sayfasayisi=ceil($candidatetestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($candidatetestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../subadminc/");
 }

 ?>

 <style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Upload Report / Upload Time -> <?php echo $datee; ?></h2>


                    

                     <div style="margin-top: 15px;" class="col-xs-12 col-sm-12 col-md-12 nav navbar-right panel_toolbox">
                       <div class="row">

                        <form action="already-exists" method="GET">

                          <input type="hidden" value="<?php echo $_GET['date']; ?>" name="date">

                          <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['id']) and $_GET['id']!='') { ?>
                         value ='<?php echo $_GET['id']; ?>'
                        <?php } ?> type="text" placeholder="ID" maxlength="150" name="id" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['name']) and $_GET['name']!='') { ?>
                         value ='<?php echo $_GET['name']; ?>'
                        <?php } ?> type="text" placeholder="Name" maxlength="150" name="name" class="form-control"></div>
                         
                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['company']) and $_GET['company']!='') { ?>
                         value ='<?php echo $_GET['company']; ?>'
                        <?php } ?> type="text" placeholder="Company" maxlength="150" name="company" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['designation']) and $_GET['designation']!='') { ?>
                         value ='<?php echo $_GET['designation']; ?>'
                        <?php } ?> type="text" placeholder="Designation" maxlength="150" name="designation" class="form-control"></div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="product">

                            <option value="notselected">Product</option>
                            
                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Personal Loan') { ?>
                         selected=''
                        <?php } ?>>Personal Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Business Loan') { ?>
                         selected=''
                        <?php } ?>>Business Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Home Loan') { ?>
                         selected=''
                        <?php } ?>>Home Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Loan Against Property') { ?>
                         selected=''
                        <?php } ?>>Loan Against Property</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Commercial Vehicle Loan') { ?>
                         selected=''
                        <?php } ?>>Commercial Vehicle Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Gold Loan') { ?>
                         selected=''
                        <?php } ?>>Gold Loan</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Branch Banking') { ?>
                         selected=''
                        <?php } ?>>Branch Banking</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Broking') { ?>
                         selected=''
                        <?php } ?>>Broking</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Insurance') { ?>
                         selected=''
                        <?php } ?>>Insurance</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Credit Card') { ?>
                         selected=''
                        <?php } ?>>Credit Card</option>

                            <option <?php if (isset($_GET['product']) and $_GET['product']=='Others') { ?>
                         selected=''
                        <?php } ?>>Others</option>

                          </select>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="department">

                            <option value="notselected">Department</option>
                            
                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Sales') { ?>
                         selected=''
                        <?php } ?>>Sales</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Credit') { ?>
                         selected=''
                        <?php } ?>>Credit</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Operations') { ?>
                         selected=''
                        <?php } ?>>Operations</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='IT') { ?>
                         selected=''
                        <?php } ?>>IT</option>

                            <option <?php if (isset($_GET['department']) and $_GET['department']=='Others') { ?>
                         selected=''
                        <?php } ?>>Others</option>

                            

                          </select>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-12 margin"></div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['location']) and $_GET['location']!='') { ?>
                         value ='<?php echo $_GET['location']; ?>'
                        <?php } ?> type="text" placeholder="Location" maxlength="150" name="location" class="form-control"></div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin"><input <?php if (isset($_GET['phone']) and $_GET['phone']!='') { ?>
                         value ='<?php echo $_GET['phone']; ?>'
                        <?php } ?> type="text" placeholder="Phone" maxlength="12" name="phone" class="form-control"></div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          <select class="form-control" name="existstatus">
                            
                            <option value="status">Already Exist / New</option>

                            <option <?php if (isset($_GET['existstatus']) and $_GET['existstatus']=='1') { ?>
                             selected=''
                            <?php } ?> value="1">Already Exist</option>

                            <option <?php if (isset($_GET['existstatus']) and $_GET['existstatus']=='0') { ?>
                             selected=''
                            <?php } ?> value="0">New</option>

                            

                          </select>
                        </div>

                        <div style="margin-top: 15px;" class="col-md-2 col-sm-2 col-xs-12 margin">
                          
                          <select class="form-control" name="sortby">
                          
                          <option value="default">Sort By</option>

                          <option <?php if ($sortby=='1') { ?>
                            selected=''
                          <?php } ?> value="1">Date Created (New to Old)</option>

                          <option <?php if ($sortby=='2') { ?>
                            selected=''
                          <?php } ?> value="2">Date Created (Old to New)</option>

                         
                          <option <?php if ($sortby=='4') { ?>
                            selected=''
                          <?php } ?> value="4">Name (A-Z)</option>

                          <option <?php if ($sortby=='5') { ?>
                            selected=''
                          <?php } ?> value="5">Name (Z-A)</option>

                        

                          <option <?php if ($sortby=='6') { ?>
                            selected=''
                          <?php } ?> value="6">Company</option>

                          <option <?php if ($sortby=='7') { ?>
                            selected=''
                          <?php } ?> value="7">Designation</option>

                          <option <?php if ($sortby=='8') { ?>
                            selected=''
                          <?php } ?> value="8">Location</option>

                          <option <?php if ($sortby=='9') { ?>
                            selected=''
                          <?php } ?> value="9">Department</option>

                          <option <?php if ($sortby=='10') { ?>
                            selected=''
                          <?php } ?> value="10">Product</option>






 
                          

                          
                        </select>

                        </div>



                        <div align="center" style="margin-top: 15px;" class="col-md-12 col-sm-12 col-xs-12 margin"><button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Filter</button></div>


                        </form>

                       </div>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                   

                    
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Date Created</th>
                          <th>Calling Person</th>
                          <th>Name</th>
                          <th>Company</th>
                          <th>Designation</th>
                          <th>Location</th>
                          <th>Department</th>

                          <th>Product</th>

                          <th>Phone Number</th>

                          <th>LinkedIn</th>

                          <th>Exist / New</th>

                         

                         
                          

                         
                          
                          
                          <th></th>
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php



if (empty($sortby) or $sortby=='default' or $sortby=='1') {
  
 $query .= " order by candidate_tarihi DESC limit $baslangic,$kacar ";

} else if ($sortby=='2'){

 $query .= " order by candidate_tarihi ASC limit $baslangic,$kacar ";

} else if ($sortby=='3'){

 $query .= " order by kullanici_id DESC limit $baslangic,$kacar ";

} else if ($sortby=='4'){

 $query .= " order by candidate_adsoyad ASC limit $baslangic,$kacar ";

} else if ($sortby=='5'){

 $query .= " order by candidate_adsoyad DESC limit $baslangic,$kacar ";

} else if ($sortby=='6'){

 $query .= " order by candidate_company ASC limit $baslangic,$kacar ";

} else if ($sortby=='7'){

 $query .= " order by candidate_designation ASC limit $baslangic,$kacar ";

} else if ($sortby=='8'){

 $query .= " order by candidate_location ASC limit $baslangic,$kacar ";

} else if ($sortby=='9'){

 $query .= " order by candidate_department ASC limit $baslangic,$kacar ";

} else if ($sortby=='10'){

 $query .= " order by candidate_product ASC limit $baslangic,$kacar ";

} 



                         $candidatesec=$db->prepare($query);
                         $candidatesec->execute();
                         $candidatesay=$candidatesec->rowCount();
                         
                         while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) {

                          $calling_personid = $candidatecek['kullanici_id'];

                          $callingsec = $db->prepare("SELECT * from kullanici where kullanici_id='$calling_personid'");
                          $callingsec->execute();

                          $callingcek = $callingsec->fetch(PDO::FETCH_ASSOC);

                          $callingperson = $callingcek['kullanici_ad']." ".$callingcek['kullanici_soyad'];

                          ?>
                            

                            <tr id="candidatetr_<?php echo $candidatecek['candidate_id']; ?>">
                          <td><?php echo $candidatecek['candidate_id']; ?></td>
                          <td><?php echo substr($candidatecek['candidate_tarihi'], 0,10); ?></td>
                          <td><?php echo $callingperson; ?></td>
                          <td><?php echo $candidatecek['candidate_ad']." ".$candidatecek['candidate_soyad']; ?></td>
                          <td><?php echo $candidatecek['candidate_company']; ?></td>
                          <td><?php echo $candidatecek['candidate_designation']; ?></td>
                          <td><?php echo $candidatecek['candidate_location']; ?></td>
                          

                          <td><?php echo $candidatecek['candidate_department']; ?></td>


                          <td><?php echo $candidatecek['candidate_product']; ?></td>
                          
                          <td><a href="tel:<?php echo $candidatecek['candidate_telno']; ?>"><?php echo $candidatecek['candidate_telno']; ?></a></td>

                          <td><?php if (!empty($candidatecek['candidate_linkedin'])) { ?>
                            
                            <a target="_blank" href="<?php echo $candidatecek['candidate_linkedin']; ?>">Go to LinkedIn</a>
                            
                          <?php } ?></td>


                          <?php if ($candidatecek['candidate_alreadyexist']=='1') { ?>
                            
                            <td>Already Exist</td>

                          <?php } else { ?>

                            <td>New</td>


                         <?php } ?>

                          
                           
                          <td>
                            
                            <div class="row">
                              
                              <div align="center" class="col-md-12 col-sm-12 col-xs-12">

                    
                                <a class="btn btn-warning btn-sm" href="view-dumb-candidate?candidate_id=<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-eye"></i> View</a></div>

                               

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($candidatetestsay>$kacar) { 

                       $key = 'p';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" 


       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa-1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa-1; ?>"


      <?php } ?>
       

    aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++;

  if ($p<=$sayfa+3 and $p>=$sayfa-3) {

   ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" 

       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $p; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $p; ?>"


      <?php } ?>

     ><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" 

 <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa+1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa+1; ?>"


      <?php } ?>

       aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.overrulecandidate').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var candidate_id=id1.substring(10);

swal({
  title: "Are you sure?",
  text: "This data will be overruled exist data in calling panel.",
  icon: "info",
  buttons: ["Cancel", "Overrule"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Applying...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'overruleexistcandidate':'ok','candidate_id':candidate_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



             if (sonuc=="ok") {


              buton.html('Overruled!');
              buton.prop('disabled',true);
             

              

             } 

               }

             });

   }

   })

         })

       </script>

       