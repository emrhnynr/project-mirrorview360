<?php require_once 'header.php';

$kullanici_id = $_GET['employee_id'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='1' and kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicisay=$kullanicisec->rowCount();

if ($kullanicisay==0) {
  
  header("Location:index");
  exit;

}

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

 ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-user"></i> Employee : <?php echo $kullanicicek['kullanici_id']; ?></h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form id="editemployeeform" class="form-horizontal form-label-left" onsubmit="return false;">

                     
                      <span class="section">Personal Info</span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_ad" class="form-control col-md-7 col-xs-12" value="<?php echo $kullanicicek['kullanici_ad']; ?>" maxlength="200" name="kullanici_ad" readonly="" type="text">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Surname <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_soyad" class="form-control col-md-7 col-xs-12" value="<?php echo $kullanicicek['kullanici_soyad']; ?>" maxlength="200" type="text" readonly="" name="kullanici_soyad">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="kullanici_telno" readonly="" value="<?php echo $kullanicicek['kullanici_telno']; ?>" name="kullanici_telno" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="email" id="kullanici_mail" readonly="" name="kullanici_mail" value="<?php echo $kullanicicek['kullanici_mail']; ?>" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label for="password" class="control-label col-md-3">Password <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="kullanici_password" type="text" readonly="" name="kullanici_password" value="<?php echo $kullanicicek['kullanici_password']; ?>" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>



                      
                      
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">City Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="kullanici_sehir" readonly="" name="kullanici_sehir" value="<?php echo $kullanicicek['kullanici_sehir']; ?>" maxlength="300" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                     
                     <input type="hidden" name="kullanici_id" value="<?php echo $kullanicicek['kullanici_id']; ?>">
                     <input type="hidden" name="employeeedit">
                     
                  
                      <div class="ln_solid"></div>
                      
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">
          
          $('#editemployeeform').submit(function(){

var kullanici_ad = $.trim($('#kullanici_ad').val());
          var kullanici_soyad = $.trim($('#kullanici_soyad').val());
         var kullanici_mail = $.trim($('#kullanici_mail').val());
         var kullanici_telno = $.trim($('#kullanici_telno').val());
        var kullanici_password = $('#kullanici_password').val();
        var kullanici_password2 = $('#kullanici_password2').val();
      var form = $('#editemployeeform')[0];
             var data = new FormData(form);

             if (kullanici_ad.length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Name field can't be empty.");

             } else if (kullanici_soyad.length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Surname field can't be empty.");

             } else if (kullanici_telno.length<10) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Phone number field can't be shorter than 10 characters.");

             } else if (kullanici_mail.length<6) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Mail field can't be shorter than 6 characters.");

             }  else if (kullanici_password.length<6) {


$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Password field can't be shorter than 6 characters.");
             

             } else {


               $('.uyari').hide();
               $('.uyari2').hide();
$('.editbuton').prop('disabled',true);
$('.editbuton').html('Please Wait...');


$.ajax({
            type : 'POST',
            url : '../islem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

                sonuc=$.trim(sonuc);

                

           
                if (sonuc=="ok") {

                 $('.uyari').hide();
                  $('.uyari2').show();
                  
                  $('.editbuton').prop('disabled',false);
$('.editbuton').html('Edit');

                } else if (sonuc=='mevcutmail'){

 
               $('.uyari').show();
               $('.uyari').html("<i class='fa fa-info-circle'></i> This mail address is already exist.");
                  $('.uyari2').hide();
                  $('.editbuton').prop('disabled',false);
$('.editbuton').html('Edit');
               

                } else if (sonuc=='hata'){


                  $('.uyari').show();
               $('.uyari').html("<i class='fa fa-info-circle'></i> Something wrong.");
                  $('.uyari2').hide();
                  $('.editbuton').prop('disabled',false);
$('.editbuton').html('Edit');

                }
                

                 }

               });

             }


          })

        </script>