<?php 

ob_start();
session_start();	

if (isset($_SESSION['kullanicioturum'])) {

Header("Location:people/");
exit;


} else if (isset($_SESSION['adminoturum'])){


Header("Location:admin/");
exit;

} else if (isset($_SESSION['subadminoturumc'])){

Header("Location:subadminc/");
exit;

} else if (isset($_SESSION['subadminoturump'])){

Header("Location:subadminp/");
exit;

} else if (empty($_SESSION)) {

Header("Location:login");
exit;

}

 ?>