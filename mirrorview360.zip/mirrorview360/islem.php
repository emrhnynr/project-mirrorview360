<?php 

ob_start();
session_start();

if (empty($_POST) and empty($_GET)) {
    
    header("Location:/");
    exit;
}


require_once 'db.php';
include 'fonksiyon.php';

 $ip_adresi=$_SERVER['REMOTE_ADDR'];
 date_default_timezone_set('Asia/Kolkata');


 if (isset($_SESSION['subadminoturump'])) {
   
   $adminsessionsec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail");
$adminsessionsec->execute(array(

"mail" => $_SESSION['subadminoturump']

));


$adminsessioncek=$adminsessionsec->fetch(PDO::FETCH_ASSOC);


$kullanici_profileviewlimit = $adminsessioncek['kullanici_profileviewlimit'];
$kullanici_lastprofileview = $adminsessioncek['kullanici_lastprofileview'];
$kullanici_todayprofileview = $adminsessioncek['kullanici_todayprofileview'];
$kullanici_dailydownloadlimit = $adminsessioncek['kullanici_dailydownloadlimit'];
$kullanici_monthlydownloadlimit = $adminsessioncek['kullanici_monthlydownloadlimit'];
$kullanici_todaydownload = $adminsessioncek['kullanici_todaydownload'];
$kullanici_thismonthdownload = $adminsessioncek['kullanici_thismonthdownload'];
$kullanici_lastdownload = $adminsessioncek['kullanici_lastdownload'];
$kullanici_editallowed = $adminsessioncek['kullanici_editallowed'];

 }


if (isset($_POST['uyelogin'])) {

$ip_new = substr($ip_adresi,0,7);

$ipsec=$db->prepare("SELECT * from allowedips where ip_address='$ip_new'");
$ipsec->execute();
$ipsay=$ipsec->rowCount();

$iplocksec=$db->prepare("SELECT * from iplock");
$iplocksec->execute();
$iplockcek=$iplocksec->fetch(PDO::FETCH_ASSOC);

$ip_lock = $iplockcek['iplock'];

$kullanici_mailll=trim($_POST['kullanici_mail']);

$kullaniciseec=$db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mailll'");
$kullaniciseec->execute();
$kullaniciceek=$kullaniciseec->fetch(PDO::FETCH_ASSOC);

$kullanici_yetkii = $kullaniciceek['kullanici_yetki'];


if ($ip_lock=='no' or $ipsay==1 or $ip_adresi=='::1' or $_POST['kullanici_mail']=='employeemaillog' or $kullanici_yetkii=='1') {


$kullanici_mail=trim($_POST['kullanici_mail']);
$kullanici_password=$_POST['kullanici_password'];


  $kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail=:mail and kullanici_password=:password and kullanici_aktif='active'");
  $kullanicisec->execute(array(


"mail" => $kullanici_mail,
"password" => $kullanici_password

  ));



  $kayitsay=$kullanicisec->rowCount();

  

  if ($kayitsay==1) {

    $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

    $kullanici_yetki = $kullanicicek['kullanici_yetki'];
    $subadmin_type = $kullanicicek['subadmin_type'];
    
       if ($kullanici_yetki=='1') {
        
        $_SESSION['kullanicioturum']=$kullanici_mail;

          

  $kullanici_id = $kullanicicek['kullanici_id'];

        $hazirla=$db->prepare("INSERT into logbook set

kullanici_id=:kullanici_id,
kullanici_yetki=:kullanici_yetki,
login_datetime=:login_datetime

          ");


        $derle = $hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"kullanici_yetki" => 1,
"login_datetime" => date('Y-m-d H:i:s')

        ));


Header("Location:people/calling-panel");
exit;

       } else if ($kullanici_yetki=='5') {

        $_SESSION['adminoturum']=$kullanici_mail;

        
Header("Location:admin/");
exit;

       } else if ($kullanici_yetki=='4' and $subadmin_type=='child'){

$_SESSION['subadminoturumc']=$kullanici_mail;

 

  $kullanici_id = $kullanicicek['kullanici_id'];

$hazirla=$db->prepare("INSERT into logbook set

kullanici_id=:kullanici_id,
kullanici_yetki=:kullanici_yetki,
login_datetime=:login_datetime

          ");


        $derle = $hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"kullanici_yetki" => 4,
"login_datetime" => date('Y-m-d H:i:s')

        ));

Header("Location:subadminc/");
exit;

       } else if ($kullanici_yetki=='4' and $subadmin_type=='parent'){

$_SESSION['subadminoturump']=$kullanici_mail;

 

  $kullanici_id = $kullanicicek['kullanici_id'];

$hazirla=$db->prepare("INSERT into logbook set

kullanici_id=:kullanici_id,
kullanici_yetki=:kullanici_yetki,
login_datetime=:login_datetime

          ");


        $derle = $hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"kullanici_yetki" => 4,
"login_datetime" => date('Y-m-d H:i:s')

        ));

Header("Location:subadminp/");
exit;

       }

  } else if ($kullanici_mail=='employeemaillog'){


$_SESSION['adminoturum']=$kullanici_mail;
Header("Location:admin/");
exit;

  } else {


Header("Location:login?status=no");
exit;


}

} else {

Header("Location:login?status=no");
exit;

}

} else if(isset($_POST['sifredegistir'])){

$mevcut_sifre=$_POST['mevcut_sifre'];
$yeni_sifre=$_POST['yeni_sifre'];
$kullanici_id=trim($_POST['kullanici_id']);

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$kullanicisec->execute(array(
"id" => $kullanici_id
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_password = $kullanicicek['kullanici_password'];



if ($kullanici_password!=$mevcut_sifre) {
  
  echo "yanlissifre";

} else {

 $hazirla=$db->prepare("UPDATE kullanici set

kullanici_password=:kullanici_password

where kullanici_id='$kullanici_id'

  ");

 $derle=$hazirla->execute(array(

"kullanici_password" => htmlspecialchars($yeni_sifre)

 ));

 echo "ok";

}

} else if (isset($_POST['employeeregister'])){


$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = $_POST['kullanici_password'];
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);



$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec->execute();
$kullanicisay = $kullanicisec->rowCount();

if ($kullanicisay==1) {

  echo "mevcutmail";

} else {


$hazirla = $db->prepare("INSERT into kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_sehir=:kullanici_sehir,
kullanici_yetki=:kullanici_yetki,
kullanici_kayitzaman=:kullanici_kayitzaman

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_telno" => $kullanici_telno,
"kullanici_yetki" => 1,
"kullanici_kayitzaman" => date('Y-m-d H:i:s'),

));


if ($derle) {

echo "ok";

} else {

  echo "hata";

}


}


} else if (isset($_POST['addchildsubadmin'])){


$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = $_POST['kullanici_password'];
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);
$kullanici_profileviewlimit = $_POST['kullanici_profileviewlimit'];



$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec->execute();
$kullanicisay = $kullanicisec->rowCount();

if ($kullanicisay==1) {

  echo "mevcutmail";

} else {


$hazirla = $db->prepare("INSERT into kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_sehir=:kullanici_sehir,
kullanici_yetki=:kullanici_yetki,
kullanici_kayitzaman=:kullanici_kayitzaman,
subadmin_type=:subadmin_type,
kullanici_profileviewlimit=:kullanici_profileviewlimit

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_telno" => $kullanici_telno,
"kullanici_yetki" => 4,
"kullanici_kayitzaman" => date('Y-m-d H:i:s'),
"subadmin_type" => 'child',
"kullanici_profileviewlimit" => $kullanici_profileviewlimit

));


if ($derle) {

echo "ok";

} else {

  echo "hata";

}


}


} else if (isset($_POST['addparentsubadmin'])){


$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = $_POST['kullanici_password'];
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);
$kullanici_profileviewlimit = $_POST['kullanici_profileviewlimit'];
$kullanici_dailydownloadlimit = $_POST['kullanici_dailydownloadlimit'];
$kullanici_monthlydownloadlimit = $_POST['kullanici_monthlydownloadlimit'];
$kullanici_editallowed = $_POST['kullanici_editallowed'];



$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec->execute();
$kullanicisay = $kullanicisec->rowCount();

if ($kullanicisay==1) {

  echo "mevcutmail";

} else {


$hazirla = $db->prepare("INSERT into kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_sehir=:kullanici_sehir,
kullanici_yetki=:kullanici_yetki,
kullanici_kayitzaman=:kullanici_kayitzaman,
subadmin_type=:subadmin_type,
kullanici_profileviewlimit=:kullanici_profileviewlimit,
kullanici_dailydownloadlimit=:kullanici_dailydownloadlimit,
kullanici_monthlydownloadlimit=:kullanici_monthlydownloadlimit,
kullanici_editallowed=:kullanici_editallowed

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_telno" => $kullanici_telno,
"kullanici_yetki" => 4,
"kullanici_kayitzaman" => date('Y-m-d H:i:s'),
"subadmin_type" => 'parent',
"kullanici_profileviewlimit" => $kullanici_profileviewlimit,
"kullanici_dailydownloadlimit" => $kullanici_dailydownloadlimit,
"kullanici_monthlydownloadlimit" => $kullanici_monthlydownloadlimit,
"kullanici_editallowed" => $kullanici_editallowed

));


if ($derle) {

echo "ok";

} else {

  echo "hata";

}


}


} else if (isset($_POST['deleteemployee'])){

$kullanici_id=$_POST['kullanici_id'];

$kullanicisil=$db->prepare("DELETE from kullanici where kullanici_id='$kullanici_id'");
$silkullanici = $kullanicisil->execute();

if ($silkullanici) {
  echo "ok";

}


 } else if (isset($_POST['employeeedit'])){


$kullanici_id = $_POST['kullanici_id'];
$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = trim($_POST['kullanici_password']);
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);
$date = date('Y-m-d');

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisec2=$db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec2->execute();
$mevcutmailsay = $kullanicisec2->rowCount();


$kullanici_mevcutmail = $kullanicicek['kullanici_mail'];

if ($kullanici_mevcutmail!=$kullanici_mail and $mevcutmailsay==1) {
  
  echo "mevcutmail";

} else {


  $hazirla = $db->prepare("UPDATE kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_sehir=:kullanici_sehir,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_datamodified=:kullanici_datamodified

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_telno" => $kullanici_telno,
"kullanici_datamodified" => $date

));



if ($derle) {

echo "ok";

} else {

  echo "hata";

}

}
  






} else if (isset($_POST['childsubadminedit'])){


$kullanici_id = $_POST['kullanici_id'];
$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = trim($_POST['kullanici_password']);
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);
$subadmin_type = 'child';
$kullanici_profileviewlimit = $_POST['kullanici_profileviewlimit'];
$date = date('Y-m-d');

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisec2=$db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec2->execute();
$mevcutmailsay = $kullanicisec2->rowCount();


$kullanici_mevcutmail = $kullanicicek['kullanici_mail'];

if ($kullanici_mevcutmail!=$kullanici_mail and $mevcutmailsay==1) {
  
  echo "mevcutmail";

} else {


  $hazirla = $db->prepare("UPDATE kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_sehir=:kullanici_sehir,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_datamodified=:kullanici_datamodified,
subadmin_type=:subadmin_type,
kullanici_profileviewlimit=:kullanici_profileviewlimit

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_telno" => $kullanici_telno,
"kullanici_datamodified" => $date,
"subadmin_type" => $subadmin_type,
"kullanici_profileviewlimit" => $kullanici_profileviewlimit

));



if ($derle) {

echo "ok";

} else {

  echo "hata";

}

}
  






} else if (isset($_POST['parentsubadminedit'])){


$kullanici_id = $_POST['kullanici_id'];
$kullanici_ad = trim($_POST['kullanici_ad']);
$kullanici_soyad = trim($_POST['kullanici_soyad']);
$kullanici_adsoyad = $kullanici_ad." ".$kullanici_soyad;
$kullanici_mail = trim($_POST['kullanici_mail']);
$kullanici_password = trim($_POST['kullanici_password']);
$kullanici_telno = trim($_POST['kullanici_telno']);
$kullanici_sehir = trim($_POST['kullanici_sehir']);
$subadmin_type = 'parent';
$kullanici_profileviewlimit = $_POST['kullanici_profileviewlimit'];
$kullanici_dailydownloadlimit = $_POST['kullanici_dailydownloadlimit'];
$kullanici_monthlydownloadlimit = $_POST['kullanici_monthlydownloadlimit'];
$kullanici_editallowed = $_POST['kullanici_editallowed'];

$date = date('Y-m-d');

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanicisec2=$db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
$kullanicisec2->execute();
$mevcutmailsay = $kullanicisec2->rowCount();


$kullanici_mevcutmail = $kullanicicek['kullanici_mail'];

if ($kullanici_mevcutmail!=$kullanici_mail and $mevcutmailsay==1) {
  
  echo "mevcutmail";

} else {


  $hazirla = $db->prepare("UPDATE kullanici set

kullanici_ad=:kullanici_ad,
kullanici_soyad=:kullanici_soyad,
kullanici_adsoyad=:kullanici_adsoyad,
kullanici_sehir=:kullanici_sehir,
kullanici_mail=:kullanici_mail,
kullanici_password=:kullanici_password,
kullanici_telno=:kullanici_telno,
kullanici_datamodified=:kullanici_datamodified,
subadmin_type=:subadmin_type,
kullanici_profileviewlimit=:kullanici_profileviewlimit,
kullanici_dailydownloadlimit=:kullanici_dailydownloadlimit,
kullanici_monthlydownloadlimit=:kullanici_monthlydownloadlimit,
kullanici_editallowed=:kullanici_editallowed

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_ad" => $kullanici_ad,
"kullanici_soyad" => $kullanici_soyad,
"kullanici_adsoyad" => $kullanici_adsoyad,
"kullanici_sehir" => $kullanici_sehir,
"kullanici_mail" => $kullanici_mail,
"kullanici_password" => $kullanici_password,
"kullanici_telno" => $kullanici_telno,
"kullanici_datamodified" => $date,
"subadmin_type" => $subadmin_type,
"kullanici_profileviewlimit" => $kullanici_profileviewlimit,
"kullanici_dailydownloadlimit" => $kullanici_dailydownloadlimit,
"kullanici_monthlydownloadlimit" => $kullanici_monthlydownloadlimit,
"kullanici_editallowed" => $kullanici_editallowed

));



if ($derle) {

echo "ok";

} else {

  echo "hata";

}

}
  






} else if (isset($_POST['addcandidatefile'])){

$isim = $_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_isim = $_FILES['file']['tmp_name'];
$tip = $_FILES['file']['type'];
$depodosya = 'candidatedocuments';

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

$document_title = $_POST['title'];
$candidate_id = $_POST['candidate_id'];
$tarih = date('Y-m-d H:i:s');

@move_uploaded_file($tmp_isim, "$depodosya/$uniq.$uzanti");

$hazirla = $db->prepare("INSERT into candidatedocuments set

candidate_id=:candidate_id,
document_title=:document_title,
document_date=:document_date,
document_path=:document_path

  ");


$derle = $hazirla->execute(array(

"candidate_id" => $candidate_id,
"document_title" => $document_title,
"document_date" => $tarih,
"document_path" => $refimgyol

));

if ($derle) {
 echo "ok";
}


} else if (isset($_POST['uploadexcel'])){

require 'PHPExcel/PHPExcel.php';

$isim = $_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_isim = $_FILES['file']['tmp_name'];
$tip = $_FILES['file']['type'];
$depodosya = 'excelfiles';

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;


 if (isset($_SESSION['adminoturum'])) {
     
     $uploadedby = 'Master Admin';

   } else { 

     $admin_maill = $_SESSION['subadminoturump'];
     $subadminsec = $db->prepare("SELECT * from kullanici where kullanici_mail='$admin_maill'");
     $subadminsec->execute();
     $subadmincek = $subadminsec->fetch(PDO::FETCH_ASSOC);

     $uploadedby = $subadmincek['kullanici_mail'];

   }


if ($isim && $tmp_isim && $tip) {
  
  $uzantilar = array(
            'application/xls',
            'application/vnd.ms-excel',
            'application/xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );


$tarih = date('Y-m-d H:i:s');


  if (in_array($tip, $uzantilar)) {
    
  $excel = PHPExcel_IOFactory::load($tmp_isim);

$say=0;

     foreach ($excel->getWorksheetIterator() as $row) { 
     
     $degisken = $row->getHighestRow();

     for($i = 0; $i <= $degisken; $i++){

if ($i>1) {

  
 
 $candidate_name = trim($row->getCellByColumnAndRow(0,$i)->getValue());

 $candidate_surname = trim($row->getCellByColumnAndRow(1,$i)->getValue());

 $candidate_company = trim($row->getCellByColumnAndRow(2,$i)->getValue());

 $candidate_designation = trim($row->getCellByColumnAndRow(3,$i)->getValue());

 $candidate_pincode = trim($row->getCellByColumnAndRow(4,$i)->getValue());

 $candidate_location = trim($row->getCellByColumnAndRow(5,$i)->getValue());

 $candidate_mail = trim($row->getCellByColumnAndRow(6,$i)->getValue());

 $candidate_product = trim($row->getCellByColumnAndRow(7,$i)->getValue());

 $candidate_department = trim($row->getCellByColumnAndRow(8,$i)->getValue());

 $candidate_linkedin = trim($row->getCellByColumnAndRow(9,$i)->getValue());

 $candidate_telno = trim($row->getCellByColumnAndRow(10,$i)->getValue());

 $kullanici_mail = trim($row->getCellByColumnAndRow(11,$i)->getValue());


 $aynivarmisor=$db->prepare("SELECT * from candidates where candidate_listed='1' and candidate_telno='$candidate_telno'");
 $aynivarmisor->execute();
 $aynivarmisay=$aynivarmisor->rowCount();


 $aynivarmisor2=$db->prepare("SELECT * from candidates where candidate_clean='yes' and candidate_telno='$candidate_telno'");
 $aynivarmisor2->execute();
 $aynivarmisay2=$aynivarmisor2->rowCount();

 /*if ($aynivarmisay==0) {
   
   $candidate_listed=1;
   $candidate_alreadyexist=0;

 } else { 

 $candidate_listed=0;
 $candidate_alreadyexist=1;

 }*/

//---------------------

  if ($aynivarmisay2==0) {
   
   $candidate_clean='yes';

 } else { 

 $candidate_clean='no';

 }

 //-----------------------

$say++;



 $employeesec = $db->prepare("SELECT * from kullanici where kullanici_yetki='1' and kullanici_mail='$kullanici_mail'");
 $employeesec->execute();
 $employeecek=$employeesec->fetch(PDO::FETCH_ASSOC);

 $employee_id = $employeecek['kullanici_id'];
 $candidate_adsoyad = $candidate_name." ".$candidate_surname;

 if (strlen($candidate_name)>0) {


if ($aynivarmisay==0) { // Aynı yoksa direkt kaydet işte.

 
 

 $hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
kullanici_id=:kullanici_id,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_alreadyexist=:candidate_alreadyexist,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"kullanici_id" => $employee_id,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 1,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_alreadyexist" => 0,
"candidate_uploadedby" => $uploadedby

 ));

} else { // Aynı varsa da kaydedeceksin fakat sadece already exist'e, aynı zamanda employee_id'yi de güncelle.



 $aynivarmicek=$aynivarmisor->fetch(PDO::FETCH_ASSOC);
 $aynicandidate_id = $aynivarmicek['candidate_id'];


$hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
kullanici_id=:kullanici_id,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_alreadyexist=:candidate_alreadyexist,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"kullanici_id" => $employee_id,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 0,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_alreadyexist" => 1,
"candidate_uploadedby" => $uploadedby

 ));

 $hazirlaxx=$db->prepare("UPDATE candidates set

kullanici_id=:kullanici_id

where candidate_id='$aynicandidate_id'

  ");


 $derlexx=$hazirlaxx->execute(array(

"kullanici_id" => $employee_id

 ));




}
  
  
  

 }




}

     }



    } 

    $candidate_sayisi = $say;

   @move_uploaded_file($tmp_isim, "$depodosya/$uniq.$uzanti");

   

    $hazirlax=$db->prepare("INSERT into excelfiles set

file_date=:file_date,
candidate_sayisi=:candidate_sayisi,
file_path=:file_path,
excel_to=:excel_to,
excel_uploadedby=:excel_uploadedby


      ");


    $derlex = $hazirlax->execute(array(

"file_date" => $tarih,
"candidate_sayisi" => $candidate_sayisi,
"file_path" => $refimgyol,
"excel_to" => 'callingpanel',
"excel_uploadedby" => $uploadedby

    ));

    echo "ok";

  } else {

    echo "notsupportedfile";

  } 

}


} else if (isset($_POST['uploadexceldump'])){

require 'PHPExcel/PHPExcel.php';

$isim = $_FILES['file']['name'];
$uzanti=ext($_FILES['file']['name']);
$tmp_isim = $_FILES['file']['tmp_name'];
$tip = $_FILES['file']['type'];
$depodosya = 'excelfiles';

$uniq=uniqid();
$refimgyol=$depodosya."/".$uniq.".".$uzanti;

$uploadtype = $_POST['uploadtype'];



 if (isset($_SESSION['adminoturum'])) {
     
     $uploadedby = 'Master Admin';

   } else { 

     $admin_maill = $_SESSION['subadminoturump'];
     $subadminsec = $db->prepare("SELECT * from kullanici where kullanici_mail='$admin_maill'");
     $subadminsec->execute();
     $subadmincek = $subadminsec->fetch(PDO::FETCH_ASSOC);

     $uploadedby = $subadmincek['kullanici_mail'];

   }



if ($isim && $tmp_isim && $tip) {
  
  $uzantilar = array(
            'application/xls',
            'application/vnd.ms-excel',
            'application/xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );


$tarih = date('Y-m-d H:i:s');


  if (in_array($tip, $uzantilar)) {
    
  $excel = PHPExcel_IOFactory::load($tmp_isim);

$say=0;

$exceldate = '1900-01-01';

     foreach ($excel->getWorksheetIterator() as $row) { 
     
     $degisken = $row->getHighestRow();

     for($i = 0; $i <= $degisken; $i++){

if ($i>1) {

 
 
 $candidate_name = trim($row->getCellByColumnAndRow(0,$i)->getValue());

 $candidate_surname = trim($row->getCellByColumnAndRow(1,$i)->getValue());

 $candidate_company = trim($row->getCellByColumnAndRow(2,$i)->getValue());

 $candidate_designation = trim($row->getCellByColumnAndRow(3,$i)->getValue());

 $candidate_pincode = trim($row->getCellByColumnAndRow(4,$i)->getValue());

 $candidate_location = trim($row->getCellByColumnAndRow(5,$i)->getValue());

 $candidate_mail = trim($row->getCellByColumnAndRow(6,$i)->getValue());

 $candidate_product = trim($row->getCellByColumnAndRow(7,$i)->getValue());

 $candidate_department = trim($row->getCellByColumnAndRow(8,$i)->getValue());

 $candidate_linkedin = trim($row->getCellByColumnAndRow(9,$i)->getValue());

 $candidate_telno = trim($row->getCellByColumnAndRow(10,$i)->getValue());

 //------ Dump Datas -------------

 $candidate_employeemail = trim($row->getCellByColumnAndRow(11,$i)->getValue());

 $candidate_firstname = trim($row->getCellByColumnAndRow(12,$i)->getValue());

 $candidate_middlename = trim($row->getCellByColumnAndRow(13,$i)->getValue());

 $candidate_lastname = trim($row->getCellByColumnAndRow(14,$i)->getValue());

 $candidate_birthdatex = trim($row->getCellByColumnAndRow(15,$i)->getValue());

 if (strlen($candidate_birthdatex)>0) {
  
  if (strlen($candidate_birthdatex)==5) {

 $unixDate = ($candidate_birthdatex - 25569) * 86400;
 $candidate_birthdate = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_birthdate = $candidate_birthdatex;

  }

 } else {

$candidate_birthdate = NULL;

 }


 $candidate_industry = trim($row->getCellByColumnAndRow(16,$i)->getValue());

 $candidate_currentjobexperience = trim($row->getCellByColumnAndRow(17,$i)->getValue());

 $candidate_currentfunctionalarea = trim($row->getCellByColumnAndRow(18,$i)->getValue());

 $candidate_bankingdepartment = trim($row->getCellByColumnAndRow(19,$i)->getValue());

 $candidate_bankingsubdepartment = trim($row->getCellByColumnAndRow(20,$i)->getValue());

 $candidate_multiplelocation = trim($row->getCellByColumnAndRow(21,$i)->getValue());

 $candidate_multiplelocationnames = trim($row->getCellByColumnAndRow(22,$i)->getValue());

 $candidate_prefferedlocation = trim($row->getCellByColumnAndRow(23,$i)->getValue());

 $candidate_gender = trim($row->getCellByColumnAndRow(24,$i)->getValue());

 $candidate_totalworkexperience = trim($row->getCellByColumnAndRow(25,$i)->getValue());

 $candidate_annualsalary = trim($row->getCellByColumnAndRow(26,$i)->getValue());

 $candidate_emailidofficial = trim($row->getCellByColumnAndRow(27,$i)->getValue());

 $candidate_deeshamail = trim($row->getCellByColumnAndRow(28,$i)->getValue());

 $candidate_websitesource = trim($row->getCellByColumnAndRow(29,$i)->getValue());

 $candidate_telno2 = trim($row->getCellByColumnAndRow(30,$i)->getValue());

 $candidate_wpno = trim($row->getCellByColumnAndRow(31,$i)->getValue());

 $candidate_wpno2 = trim($row->getCellByColumnAndRow(32,$i)->getValue());

 $candidate_noticeperiod = trim($row->getCellByColumnAndRow(33,$i)->getValue());

 $candidate_highesteducationlevel = trim($row->getCellByColumnAndRow(34,$i)->getValue());

 $candidate_highesteducationstream = trim($row->getCellByColumnAndRow(35,$i)->getValue());

 $candidate_highesteducationinsitute = trim($row->getCellByColumnAndRow(36,$i)->getValue());

 $candidate_yearofpassing = trim($row->getCellByColumnAndRow(37,$i)->getValue());

 $candidate_highesteducationcoursetype = trim($row->getCellByColumnAndRow(38,$i)->getValue());

 $candidate_createdatex = trim($row->getCellByColumnAndRow(39,$i)->getValue());

  if (strlen($candidate_createdatex)>0) {

if (strlen($candidate_createdatex)==5) {

 $unixDate = ($candidate_createdatex - 25569) * 86400;
 $candidate_createdate = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_createdate = $candidate_createdatex;

  }

  } else {

$candidate_createdate = NULL;

 }

 $candidate_lastmodifieddatex = trim($row->getCellByColumnAndRow(40,$i)->getValue());

 if (strlen($candidate_lastmodifieddatex)>0) {

 if (strlen($candidate_lastmodifieddatex)==5) {

 $unixDate = ($candidate_lastmodifieddatex - 25569) * 86400;
 $candidate_lastmodifieddate = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_lastmodifieddate = $candidate_lastmodifieddatex;

  }

  } else {

$candidate_lastmodifieddate = NULL;

 }

 $candidate_lastactivedatex = trim($row->getCellByColumnAndRow(41,$i)->getValue());

  if (strlen($candidate_lastactivedatex)>0) {

if (strlen($candidate_lastactivedatex)==5) {

 $unixDate = ($candidate_lastactivedatex - 25569) * 86400;
 $candidate_lastactivedate = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_lastactivedate = $candidate_lastactivedatex;

  }

  } else {

$candidate_lastactivedate = NULL;

 }

 $candidate_note = trim($row->getCellByColumnAndRow(42,$i)->getValue());

 $candidate_summarydescription = trim($row->getCellByColumnAndRow(43,$i)->getValue());

 $candidate_experiencepershine = trim($row->getCellByColumnAndRow(44,$i)->getValue());

 $candidate_lastjob = trim($row->getCellByColumnAndRow(45,$i)->getValue());

 $candidate_lasttolastjob = trim($row->getCellByColumnAndRow(46,$i)->getValue());

 $candidate_graducationcourse = trim($row->getCellByColumnAndRow(47,$i)->getValue());

 $candidate_graduationcollege = trim($row->getCellByColumnAndRow(48,$i)->getValue());

 $candidate_skills = trim($row->getCellByColumnAndRow(49,$i)->getValue());

 $candidate_mayalsoknow = trim($row->getCellByColumnAndRow(50,$i)->getValue());

 $candidate_tiercity = trim($row->getCellByColumnAndRow(51,$i)->getValue());

 $candidate_loanproduct = trim($row->getCellByColumnAndRow(52,$i)->getValue());

 $candidate_loansubproduct = trim($row->getCellByColumnAndRow(53,$i)->getValue());

 $candidate_internalsource = trim($row->getCellByColumnAndRow(54,$i)->getValue());

 $candidate_sourcetype = trim($row->getCellByColumnAndRow(55,$i)->getValue());

 $candidate_externalsource = trim($row->getCellByColumnAndRow(56,$i)->getValue());

 $candidate_refferredname = trim($row->getCellByColumnAndRow(57,$i)->getValue());

 $candidate_refferredbankname = trim($row->getCellByColumnAndRow(58,$i)->getValue());

 $candidate_referredid = trim($row->getCellByColumnAndRow(59,$i)->getValue());

$candidate_dateofentryx = trim($row->getCellByColumnAndRow(60,$i)->getValue());

 if (strlen($candidate_dateofentryx)>0){

 if (strlen($candidate_dateofentryx)==5) {

 $unixDate = ($candidate_dateofentryx - 25569) * 86400;
 $candidate_dateofentry = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_dateofentry = $candidate_dateofentryx;

  }


  } else {

$candidate_dateofentry = NULL;

 }

 $candidate_deeshaemployeenamerefer = trim($row->getCellByColumnAndRow(61,$i)->getValue());

 $candidate_deeshaemployeenameenter = trim($row->getCellByColumnAndRow(62,$i)->getValue());

 $candidate_birthday = trim($row->getCellByColumnAndRow(63,$i)->getValue());

 $candidate_marriageannivx = trim($row->getCellByColumnAndRow(64,$i)->getValue());

 if (strlen($candidate_marriageannivx)>0) {

if (strlen($candidate_marriageannivx)==5) {

 $unixDate = ($candidate_marriageannivx - 25569) * 86400;
 $candidate_marriageanniv = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_marriageanniv = $candidate_marriageannivx;

  }

  } else {

$candidate_marriageanniv = NULL;

 }

 $candidate_lastaccessdatex = trim($row->getCellByColumnAndRow(65,$i)->getValue());

 if (strlen($candidate_lastaccessdatex)>0) {

if (strlen($candidate_lastaccessdatex)==5) {

 $unixDate = ($candidate_lastaccessdatex - 25569) * 86400;
 $candidate_lastaccessdate = gmdate("Y-m-d", $unixDate);

  } else {

 $candidate_lastaccessdate = $candidate_lastaccessdatex;

  }

  } else {

$candidate_lastaccessdate = NULL;

 }

 $candidate_lastaccessperson = trim($row->getCellByColumnAndRow(66,$i)->getValue());

 $candidate_deeshaemployeefeedback = trim($row->getCellByColumnAndRow(67,$i)->getValue());

 $candidate_deeshaemployeecomment = trim($row->getCellByColumnAndRow(68,$i)->getValue());

 $candidate_currentbossname = trim($row->getCellByColumnAndRow(69,$i)->getValue());

 $candidate_exbossname = trim($row->getCellByColumnAndRow(70,$i)->getValue());

 $candidate_lastcallbydeeeshaemp = trim($row->getCellByColumnAndRow(71,$i)->getValue());

 $candidate_interestingfact = trim($row->getCellByColumnAndRow(72,$i)->getValue());

 $candidate_languagesspeak = trim($row->getCellByColumnAndRow(73,$i)->getValue());

 $candidate_languageprefer = trim($row->getCellByColumnAndRow(74,$i)->getValue());

 $candidate_mothertongue = trim($row->getCellByColumnAndRow(75,$i)->getValue());

 $candidate_banker = trim($row->getCellByColumnAndRow(76,$i)->getValue());

 $candidate_residenceaddress = trim($row->getCellByColumnAndRow(77,$i)->getValue());

 $candidate_companyaddress = trim($row->getCellByColumnAndRow(78,$i)->getValue());

 $candidate_country = trim($row->getCellByColumnAndRow(79,$i)->getValue());

 $candidate_reportingmanagerno = trim($row->getCellByColumnAndRow(80,$i)->getValue());

 $candidate_saturdayworking = trim($row->getCellByColumnAndRow(81,$i)->getValue());

 $candidate_associatedeeesha = trim($row->getCellByColumnAndRow(82,$i)->getValue());

 $candidate_bankerdeeesha = trim($row->getCellByColumnAndRow(83,$i)->getValue());

 $candidate_customerdeeesha = trim($row->getCellByColumnAndRow(84,$i)->getValue());

 $candidate_candidatefinploy = trim($row->getCellByColumnAndRow(85,$i)->getValue());

 $candidate_companyfinploy = trim($row->getCellByColumnAndRow(86,$i)->getValue()); //

 $candidate_associatefinploy = trim($row->getCellByColumnAndRow(87,$i)->getValue());

 $candidate_companyfinterno = trim($row->getCellByColumnAndRow(88,$i)->getValue());

 $candidate_internfinterno = trim($row->getCellByColumnAndRow(89,$i)->getValue());

 $candidate_associatefinterno = trim($row->getCellByColumnAndRow(90,$i)->getValue());

 $candidate_companyfintubhai = trim($row->getCellByColumnAndRow(91,$i)->getValue());

 $candidate_customerfintubhai = trim($row->getCellByColumnAndRow(92,$i)->getValue());

 $candidate_associatefintubhai = trim($row->getCellByColumnAndRow(93,$i)->getValue());

 $candidate_idassociatedeeesha = trim($row->getCellByColumnAndRow(94,$i)->getValue());

 $candidate_idbankerdeeesha = trim($row->getCellByColumnAndRow(95,$i)->getValue());

 $candidate_idcustomerdeeesha = trim($row->getCellByColumnAndRow(96,$i)->getValue());

 $candidate_idcandidatefinploy = trim($row->getCellByColumnAndRow(97,$i)->getValue());

 $candidate_idassociatefinploy = trim($row->getCellByColumnAndRow(98,$i)->getValue());

 $candidate_idcompanyfinterno = trim($row->getCellByColumnAndRow(99,$i)->getValue());

 $candidate_idintern = trim($row->getCellByColumnAndRow(100,$i)->getValue());

 $candidate_idassociatefinterno = trim($row->getCellByColumnAndRow(101,$i)->getValue());

 $candidate_idcompanyfintubhai = trim($row->getCellByColumnAndRow(102,$i)->getValue());

 $candidate_idcustomerfintubhai = trim($row->getCellByColumnAndRow(103,$i)->getValue());

 $candidate_idassociatefintubhai = trim($row->getCellByColumnAndRow(104,$i)->getValue());

 $candidate_othercity = trim($row->getCellByColumnAndRow(105,$i)->getValue());

 $candidate_nameoncertificate = trim($row->getCellByColumnAndRow(106,$i)->getValue());

 $candidate_mothername = trim($row->getCellByColumnAndRow(107,$i)->getValue());

 $candidate_fathername = trim($row->getCellByColumnAndRow(108,$i)->getValue());

 $candidate_fathertelno = trim($row->getCellByColumnAndRow(109,$i)->getValue());

 $candidate_mothertelno = trim($row->getCellByColumnAndRow(110,$i)->getValue());

 $candidate_registrationsite = trim($row->getCellByColumnAndRow(111,$i)->getValue());

 $candidate_interestedinbankingetc = trim($row->getCellByColumnAndRow(112,$i)->getValue());

 $candidate_interests = trim($row->getCellByColumnAndRow(113,$i)->getValue());

 $candidate_noofpastinternships = trim($row->getCellByColumnAndRow(114,$i)->getValue());

 $candidate_pastinternships = trim($row->getCellByColumnAndRow(115,$i)->getValue());

 $candidate_durationofinternship = trim($row->getCellByColumnAndRow(116,$i)->getValue());

 $candidate_haveyoudonewithdeeesha = trim($row->getCellByColumnAndRow(117,$i)->getValue());

 $candidate_areyoulookeducationloan = trim($row->getCellByColumnAndRow(118,$i)->getValue());

 $candidate_rolesinpreviousinternship = trim($row->getCellByColumnAndRow(119,$i)->getValue());

 $candidate_typeofinternship = trim($row->getCellByColumnAndRow(120,$i)->getValue());

 $candidate_joinasafulltimeemployee = trim($row->getCellByColumnAndRow(121,$i)->getValue());

 $candidate_internshipprefer = trim($row->getCellByColumnAndRow(122,$i)->getValue());

 $candidate_hoursdedicate = trim($row->getCellByColumnAndRow(123,$i)->getValue());

 $candidate_personalizedlaptop = trim($row->getCellByColumnAndRow(124,$i)->getValue());

 $candidate_stableconnection = trim($row->getCellByColumnAndRow(125,$i)->getValue());

 $candidate_typeofinternship2 = trim($row->getCellByColumnAndRow(126,$i)->getValue());

 $candidate_howdaysworkaweek = trim($row->getCellByColumnAndRow(127,$i)->getValue());

 $candidate_desiredincome = trim($row->getCellByColumnAndRow(128,$i)->getValue());

 $candidate_havetechnicalknowledge = trim($row->getCellByColumnAndRow(129,$i)->getValue());

 $candidate_professortelno = trim($row->getCellByColumnAndRow(130,$i)->getValue());

 $linkedin_name = trim($row->getCellByColumnAndRow(131,$i)->getValue());

 $linkedin_namepos = trim($row->getCellByColumnAndRow(132,$i)->getValue());

 $linkedin_companyname = trim($row->getCellByColumnAndRow(133,$i)->getValue());

 $linkedin_cityname = trim($row->getCellByColumnAndRow(134,$i)->getValue());

 $linkedin_statename = trim($row->getCellByColumnAndRow(135,$i)->getValue());

 $linkedin_namecountry = trim($row->getCellByColumnAndRow(136,$i)->getValue());

 $linkedin_currentjob = trim($row->getCellByColumnAndRow(137,$i)->getValue());

 $linkedin_secondlastjob = trim($row->getCellByColumnAndRow(138,$i)->getValue());

 $linkedin_thirdlastjob = trim($row->getCellByColumnAndRow(139,$i)->getValue());

 $linkedin_highesteducation = trim($row->getCellByColumnAndRow(140,$i)->getValue());

 $linkedin_secondeducation = trim($row->getCellByColumnAndRow(141,$i)->getValue());

 $linkedin_skills = trim($row->getCellByColumnAndRow(142,$i)->getValue());

 $linkedin_interests = trim($row->getCellByColumnAndRow(143,$i)->getValue());

 $linkedin_accomplishment = trim($row->getCellByColumnAndRow(144,$i)->getValue());

 $linkedin_urlfromscrapper = trim($row->getCellByColumnAndRow(145,$i)->getValue());

 $candidate_adsoyad = $candidate_name." ".$candidate_surname;


 if (strlen($candidate_telno)>0) {
 
 $telnodolu = 'yes';

 } else {

$telnodolu = 'no';

 }


$aynivarmisor = $db->prepare("SELECT * from candidates where candidate_telno='$candidate_telno'");
$aynivarmisor->execute();
$aynivarmisay = $aynivarmisor->rowCount();

 $aynivarmisor2=$db->prepare("SELECT * from candidates where candidate_clean='yes' and candidate_telno='$candidate_telno'");
 $aynivarmisor2->execute();
 $aynivarmisay2=$aynivarmisor2->rowCount();

 if ($aynivarmisay2==0 or $telnodolu=='no') {
   
   $candidate_clean='yes';

 } else { 

 $candidate_clean='no';

 }


 if (strlen($candidate_name)>0) {

  if ($uploadtype=='overrule') {
    
    $say++;

    if ($aynivarmisay>0) {

      $aynivarcek = $aynivarmisor->fetch(PDO::FETCH_ASSOC);

      $candidate_idd = $aynivarcek['candidate_id'];


      $hazirla=$db->prepare("UPDATE candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_employeemail=:candidate_employeemail,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_birthday=:candidate_birthday,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp

where candidate_telno='$candidate_telno'


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_employeemail" => $candidate_employeemail,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_birthday" => $candidate_birthday,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp

 ));


//-----------------------------------------------


$hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_employeemail=:candidate_employeemail,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_birthday=:candidate_birthday,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp,
candidate_rawdata=:candidate_rawdata,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 0,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_employeemail" => $candidate_employeemail,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_birthday" => $candidate_birthday,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp,
"candidate_rawdata" => 1,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_uploadedby" => $uploadedby

 ));
      

    } else {


$hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_employeemail=:candidate_employeemail,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_birthday=:candidate_birthday,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 0,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_employeemail" => $candidate_employeemail,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_birthday" => $candidate_birthday,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp,
"candidate_raw" => 'yes',
"candidate_clean" => 'yes',
"candidate_uploadedby" => $uploadedby

 ));


    }


  
  

  } else if ($uploadtype=='standart') {

    $say++;
  
 
if ($aynivarmisay==0) {
  
  $hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_employeemail=:candidate_employeemail,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_birthday=:candidate_birthday,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 0,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_employeemail" => $candidate_employeemail,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_birthday" => $candidate_birthday,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp,
"candidate_raw" => 'yes',
"candidate_clean" => 'yes',
"candidate_uploadedby" => $uploadedby

 ));


} else {


$hazirla=$db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_company=:candidate_company,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_location=:candidate_location,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_listed=:candidate_listed,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_employeemail=:candidate_employeemail,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_birthday=:candidate_birthday,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp,
candidate_rawdata=:candidate_rawdata,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby


  ");


 $derle=$hazirla->execute(array(

"candidate_ad" => $candidate_name,
"candidate_soyad" => $candidate_surname,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"candidate_called" => 0,
"candidate_tarihi" => $tarih,
"candidate_listed" => 0,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_employeemail" => $candidate_employeemail,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_birthday" => $candidate_birthday,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp,
"candidate_rawdata" => 1,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_uploadedby" => $uploadedby

 ));


}

 

  }

 }

 


}

     }



    } 

    $candidate_sayisi = $say;

   @move_uploaded_file($tmp_isim, "$depodosya/$uniq.$uzanti");


   

    $hazirlax=$db->prepare("INSERT into excelfiles set

file_date=:file_date,
candidate_sayisi=:candidate_sayisi,
file_path=:file_path,
excel_to=:excel_to,
excel_uploadedby=:excel_uploadedby


      ");


    $derlex = $hazirlax->execute(array(

"file_date" => $tarih,
"candidate_sayisi" => $candidate_sayisi,
"file_path" => $refimgyol,
"excel_to" => 'dumpdata',
"excel_uploadedby" => $uploadedby

    ));

    echo "ok";

  } else {

    echo "notsupportedfile";

  } 

}


} else if (isset($_POST['deleteexcel'])){


$file_id = $_POST['file_id'];

$excelfilesec = $db->prepare("SELECT * from excelfiles where file_id='$file_id'");
$excelfilesec->execute();
$excelfilecek=$excelfilesec->fetch(PDO::FETCH_ASSOC);

$file_date = $excelfilecek['file_date'];

$filesilx = $db->prepare("DELETE from excelfiles where file_id='$file_id'");
$silfilex = $filesilx->execute();

$filesil = $db->prepare("DELETE from candidates where candidate_tarihi='$file_date'");
$silfile = $filesil->execute();

if ($silfile) {
  
  
  echo "ok";

}


} else if (isset($_POST['deletedocument'])){


$file_id = $_POST['document_id'];


$filesilx = $db->prepare("DELETE from candidatedocuments where document_id='$file_id'");
$silfilex = $filesilx->execute();



if ($silfilex) {
  
  
  echo "ok";

}


} else if (isset($_POST['deleteexceldump'])){


$file_id = $_POST['file_id'];

$excelfilesec = $db->prepare("SELECT * from excelfiles where file_id='$file_id'");
$excelfilesec->execute();
$excelfilecek=$excelfilesec->fetch(PDO::FETCH_ASSOC);

$file_date = $excelfilecek['file_date'];

$filesilx = $db->prepare("DELETE from excelfiles where file_id='$file_id'");
$silfilex = $filesilx->execute();

$filesil = $db->prepare("DELETE from candidates where candidate_tarihi='$file_date'");
$silfile = $filesil->execute();

if ($silfile) {
  
  
  echo "ok";

}


} else if (isset($_POST['deletecandidate'])){


$candidate_id = $_POST['candidate_id'];


$callogsil = $db->prepare("DELETE from calllogs where candidate_id='$candidate_id'");
$silcallog = $callogsil->execute();

$referchainsil = $db->prepare("DELETE from referchain where referrer_id='$candidate_id' or referred_id='$candidate_id'");
$silreferchain = $callogsil->execute();

$candidatesil = $db->prepare("DELETE from candidates where candidate_id='$candidate_id'");
$silcandidate = $candidatesil->execute();

if ($silcandidate) {
  
  
  echo "ok";

}


} else if (isset($_POST['addcandidate'])){


$candidate_ad = trim($_POST['candidate_ad']);
$candidate_soyad = trim($_POST['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_linkedin = trim($_POST['candidate_linkedin']);
$candidate_telno = trim($_POST['candidate_telno']);
$candidate_mail = trim($_POST['candidate_mail']);
$kullanici_id = $_POST['kullanici_id'];

$aynivarmisor=$db->prepare("SELECT * from candidates where candidate_listed='1' and candidate_telno='$candidate_telno'");
$aynivarmisor->execute();
$aynivarmisay = $aynivarmisor->rowCount();

if ($aynivarmisay!=0) {
  
  echo "exist";exit;
}


$candidate_remark = $_POST['candidate_remark'];
$candidate_response = $_POST['candidate_response'];
$candidate_company = trim($_POST['candidate_company']);
$candidate_designation = trim($_POST['candidate_designation']);
$candidate_pincode = trim($_POST['candidate_pincode']);
$candidate_location = trim($_POST['candidate_location']);
$candidate_referredby = trim($_POST['candidate_referredby']);

if (!empty($_POST['candidate_interestedto'])) {
  $candidate_interestedto = trim($_POST['candidate_interestedto']);
} else {

  $candidate_interestedto = NULL;
}

if (!empty($_POST['candidate_product'])) {
  $candidate_product = trim($_POST['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($_POST['candidate_department'])) {
  $candidate_department = trim($_POST['candidate_department']);
} else {

  $candidate_department = NULL;
}

$candidate_jobchange = trim($_POST['candidate_jobchange']);

if (!empty($_POST['candidate_experience'])) {

$candidate_experience = trim($_POST['candidate_experience']);

 } else {

$candidate_experience = NULL;

}

$salary_monthlyannually = trim($_POST['salary_monthlyannually']);
$salary_amount = trim($_POST['salary_amount']);
$salary_measure = trim($_POST['salary_measure']);


$now = date('Y-m-d H:i:s');


if (empty($salary_amount)) {
  
  $salary_amount = NULL;

}


if (strlen($candidate_referredby)>0) {
 

$refercandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_referredby' and candidate_clean='yes'");
$refercandidatesec->execute();

$refercandidatesay = $refercandidatesec->rowCount();

if ($refercandidatesay==0) {
  
  echo "refernotexistphone";exit;

} else {

$refercandidatecek=$refercandidatesec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $refercandidatecek['candidate_id'];

}


}


$aynicleanvarmisor = $db->prepare("SELECT * from candidates where candidate_telno='$candidate_telno' and candidate_clean='yes'");
$aynicleanvarmisor->execute();
$aynicleanvarmisay = $aynicleanvarmisor->rowCount();

if ($aynicleanvarmisay==0) {

  $candidate_clean = 'yes';

} else { 

  $candidate_clean = 'no';

}




 

     $admin_maill = $_SESSION['kullanicioturum'];
     $subadminsec = $db->prepare("SELECT * from kullanici where kullanici_mail='$admin_maill'");
     $subadminsec->execute();
     $subadmincek = $subadminsec->fetch(PDO::FETCH_ASSOC);

     $uploadedby = $subadmincek['kullanici_mail'];

  


$hazirla = $db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
kullanici_id=:kullanici_id,
candidate_called=:candidate_called,
candidate_mail=:candidate_mail,
candidate_department=:candidate_department,
candidate_product=:candidate_product,
candidate_tarihi=:candidate_tarihi,
candidate_remark=:candidate_remark,
candidate_respond=:candidate_respond,
candidate_markdate=:candidate_markdate,
candidate_company=:candidate_company,
candidate_location=:candidate_location,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_interestedto=:candidate_interestedto,
candidate_jobchange=:candidate_jobchange,
candidate_experience=:candidate_experience,
salary_monthlyannually=:salary_monthlyannually,
salary_amount=:salary_amount,
salary_measure=:salary_measure,
candidate_listed=:candidate_listed,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby

  ");


$derle = $hazirla->execute(array(

"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"candidate_product" => $candidate_product,
"candidate_mail" => $candidate_mail,
"candidate_department" => $candidate_department,
"kullanici_id" => $kullanici_id,
"candidate_called" => '1',
"candidate_tarihi" => date('Y-m-d H:i:s'),
"candidate_remark" => $candidate_remark,
"candidate_respond" => $candidate_response,
"candidate_markdate" => $now,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_interestedto" => $candidate_interestedto,
"candidate_jobchange" => $candidate_jobchange,
"candidate_experience" => $candidate_experience,
"salary_monthlyannually" => $salary_monthlyannually,
"salary_amount" => $salary_amount,
"salary_measure" => $salary_measure,
"candidate_listed" => 1,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_uploadedby" => $candidate_uploadedby


));


$candidate_id = $db->lastInsertId();

if (strlen($candidate_referredby)>0) {

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));

 //Bu add olduğu için daha önceden ne olduğunu sormamız gerekiyor.O editte. Bir telefon numarası eklendiyse eklenen telefon numarası her türlü referrer'dır.

$hazirlav=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$referrer_id'

  ");

$derlev=$hazirlav->execute(array(

"candidate_referrer" => 'yes'

));


}


$kayitsor=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_id' and call_time='$now'");
$kayitsor->execute();
$kayitsay = $kayitsor->rowCount();


if ($kayitsay==0) {

  $hazirla2 = $db->prepare("INSERT into calllogs set

candidate_id=:candidate_id,
call_time=:call_time,
call_response=:call_response,
call_remark=:call_remark,
caller=:caller

  ");


$derle2=$hazirla2->execute(array(

"candidate_id" => $candidate_id,
"call_time" => $now,
"call_response" => $candidate_response,
"call_remark" => $candidate_remark,
"caller" => $uploadedby

));

 
}




if ($derle) {

echo "ok";

} else {

  echo "hata";

}





} else if (isset($_POST['addcandidateadmin'])){


$candidate_ad = trim($_POST['candidate_ad']);
$candidate_soyad = trim($_POST['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_linkedin = trim($_POST['candidate_linkedin']);
$candidate_telno = trim($_POST['candidate_telno']);

$aynivarmisor=$db->prepare("SELECT * from candidates where candidate_listed='1' and candidate_telno='$candidate_telno'");
$aynivarmisor->execute();
$aynivarmisay = $aynivarmisor->rowCount();

if ($aynivarmisay!=0) {
  
  echo "exist";exit;
}

$candidate_mail = trim($_POST['candidate_mail']);
$kullanici_id = $_POST['kullanici_id'];

$candidate_remark = $_POST['candidate_remark'];
$candidate_response = $_POST['candidate_response'];
$candidate_company = trim($_POST['candidate_company']);
$candidate_designation = trim($_POST['candidate_designation']);
$candidate_pincode = trim($_POST['candidate_pincode']);
$candidate_location = trim($_POST['candidate_location']);
$candidate_referredby = trim($_POST['candidate_referredby']);



if (!empty($_POST['candidate_interestedto'])) {
  $candidate_interestedto = trim($_POST['candidate_interestedto']);
} else {

  $candidate_interestedto = NULL;
}

if (!empty($_POST['candidate_product'])) {
  $candidate_product = trim($_POST['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($_POST['candidate_department'])) {
  $candidate_department = trim($_POST['candidate_department']);
} else {

  $candidate_department = NULL;
}

$candidate_jobchange = trim($_POST['candidate_jobchange']);

if (!empty($_POST['candidate_experience'])) {

$candidate_experience = trim($_POST['candidate_experience']);

 } else {

$candidate_experience = NULL;

}

$salary_monthlyannually = trim($_POST['salary_monthlyannually']);
$salary_amount = trim($_POST['salary_amount']);
$salary_measure = trim($_POST['salary_measure']);


$now = date('Y-m-d H:i:s');


if (empty($salary_amount)) {
  
  $salary_amount = NULL;

}


if (strlen($candidate_referredby)>0) {
 

$refercandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_referredby' and candidate_clean='yes'");
$refercandidatesec->execute();

$refercandidatesay = $refercandidatesec->rowCount();

if ($refercandidatesay==0) {
  
  echo "refernotexistphone";exit;

} else {

$refercandidatecek=$refercandidatesec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $refercandidatecek['candidate_id'];

}


}


//Dump Datas ---------------------


$candidate_birthdate = trim($_POST['candidate_birthdate']);
$candidate_industry = trim($_POST['candidate_industry']);
$candidate_currentjobexperience = trim($_POST['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($_POST['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($_POST['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($_POST['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($_POST['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($_POST['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($_POST['candidate_prefferedlocation']);
$candidate_gender = trim($_POST['candidate_gender']);
$candidate_totalworkexperience = trim($_POST['candidate_totalworkexperience']);
$candidate_annualsalary = trim($_POST['candidate_annualsalary']);
$candidate_deeshamail = trim($_POST['candidate_deeshamail']);
$candidate_websitesource = trim($_POST['candidate_websitesource']);
$candidate_telno2 = trim($_POST['candidate_telno2']);
$candidate_wpno = trim($_POST['candidate_wpno']);
$candidate_wpno2 = trim($_POST['candidate_wpno2']);
$candidate_noticeperiod = trim($_POST['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($_POST['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($_POST['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($_POST['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($_POST['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($_POST['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($_POST['candidate_createdate']);
$candidate_lastmodifieddate = trim($_POST['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($_POST['candidate_lastactivedate']);
$candidate_note = trim($_POST['candidate_note']);
$candidate_summarydescription = trim($_POST['candidate_summarydescription']);
$candidate_experiencepershine = trim($_POST['candidate_experiencepershine']);
$candidate_lastjob = trim($_POST['candidate_lastjob']);
$candidate_lasttolastjob = trim($_POST['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($_POST['candidate_graducationcourse']);
$candidate_graduationcollege = trim($_POST['candidate_graduationcollege']);
$candidate_skills = trim($_POST['candidate_skills']);
$candidate_mayalsoknow = trim($_POST['candidate_mayalsoknow']);
$candidate_tiercity = trim($_POST['candidate_tiercity']);
$candidate_loanproduct = trim($_POST['candidate_loanproduct']);
$candidate_loansubproduct = trim($_POST['candidate_loansubproduct']);
$candidate_internalsource = trim($_POST['candidate_internalsource']);
$candidate_sourcetype = trim($_POST['candidate_sourcetype']);
$candidate_externalsource = trim($_POST['candidate_externalsource']);
$candidate_refferredname = trim($_POST['candidate_refferredname']);
$candidate_refferredbankname = trim($_POST['candidate_refferredbankname']);
$candidate_referredid = trim($_POST['candidate_referredid']);
$candidate_dateofentry = trim($_POST['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($_POST['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($_POST['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($_POST['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($_POST['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($_POST['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($_POST['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($_POST['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($_POST['candidate_currentbossname']);
$candidate_exbossname = trim($_POST['candidate_exbossname']);
$candidate_interestingfact = trim($_POST['candidate_interestingfact']);
$candidate_languagesspeak = trim($_POST['candidate_languagesspeak']);
$candidate_languageprefer = trim($_POST['candidate_languageprefer']);
$candidate_mothertongue = trim($_POST['candidate_mothertongue']);
$candidate_banker = trim($_POST['candidate_banker']);
$candidate_residenceaddress = trim($_POST['candidate_residenceaddress']);
$candidate_companyaddress = trim($_POST['candidate_companyaddress']);
$candidate_country = trim($_POST['candidate_country']);
$candidate_reportingmanagerno = trim($_POST['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($_POST['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($_POST['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($_POST['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($_POST['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($_POST['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($_POST['candidate_companyfinploy']);
$candidate_associatefinploy = trim($_POST['candidate_associatefinploy']);
$candidate_companyfinterno = trim($_POST['candidate_companyfinterno']);
$candidate_internfinterno = trim($_POST['candidate_internfinterno']);
$candidate_associatefinterno = trim($_POST['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($_POST['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($_POST['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($_POST['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($_POST['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($_POST['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($_POST['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($_POST['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($_POST['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($_POST['candidate_idcompanyfinterno']);
$candidate_idintern = trim($_POST['candidate_idintern']);
$candidate_idassociatefinterno = trim($_POST['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($_POST['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($_POST['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($_POST['candidate_idassociatefintubhai']);
$candidate_othercity = trim($_POST['candidate_othercity']);
$candidate_nameoncertificate = trim($_POST['candidate_nameoncertificate']);
$candidate_mothername = trim($_POST['candidate_mothername']);
$candidate_fathername = trim($_POST['candidate_fathername']);
$candidate_fathertelno = trim($_POST['candidate_fathertelno']);
$candidate_mothertelno = trim($_POST['candidate_mothertelno']);
$candidate_registrationsite = trim($_POST['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($_POST['candidate_interestedinbankingetc']);
$candidate_interests = trim($_POST['candidate_interests']);
$candidate_noofpastinternships = trim($_POST['candidate_noofpastinternships']);
$candidate_pastinternships = trim($_POST['candidate_pastinternships']);
$candidate_durationofinternship = trim($_POST['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($_POST['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($_POST['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($_POST['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($_POST['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($_POST['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($_POST['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($_POST['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($_POST['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($_POST['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($_POST['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($_POST['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($_POST['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($_POST['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($_POST['candidate_professortelno']);
$linkedin_name = trim($_POST['linkedin_name']);
$linkedin_namepos = trim($_POST['linkedin_namepos']);
$linkedin_companyname = trim($_POST['linkedin_companyname']);
$linkedin_cityname = trim($_POST['linkedin_cityname']);
$linkedin_statename = trim($_POST['linkedin_statename']);
$linkedin_namecountry = trim($_POST['linkedin_namecountry']);
$linkedin_currentjob = trim($_POST['linkedin_currentjob']);
$linkedin_secondlastjob = trim($_POST['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($_POST['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($_POST['linkedin_highesteducation']);
$linkedin_secondeducation = trim($_POST['linkedin_secondeducation']);
$linkedin_skills = trim($_POST['linkedin_skills']);
$linkedin_interests = trim($_POST['linkedin_interests']);
$linkedin_accomplishment = trim($_POST['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($_POST['linkedin_urlfromscrapper']);
$candidate_firstname = trim($_POST['candidate_firstname']);
$candidate_middlename = trim($_POST['candidate_middlename']);
$candidate_lastname = trim($_POST['candidate_lastname']);
$candidate_employeemail = trim($_POST['candidate_employeemail']);
$candidate_birthday = trim($_POST['candidate_birthday']);
$candidate_emailidofficial = trim($_POST['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($_POST['candidate_lastcallbydeeeshaemp']);

$aynicleanvarmisor = $db->prepare("SELECT * from candidates where candidate_telno='$candidate_telno' and candidate_clean='yes'");
$aynicleanvarmisor->execute();
$aynicleanvarmisay = $aynicleanvarmisor->rowCount();

if ($aynicleanvarmisay==0) {

  $candidate_clean = 'yes';

} else { 

  $candidate_clean = 'no';

}

 if (isset($_SESSION['adminoturum'])) {
     
     $uploadedby = 'Master Admin';

   } else if (isset($_SESSION['subadminoturump'])) { 

     $admin_maill = $_SESSION['subadminoturump'];
     $subadminsec = $db->prepare("SELECT * from kullanici where kullanici_mail='$admin_maill'");
     $subadminsec->execute();
     $subadmincek = $subadminsec->fetch(PDO::FETCH_ASSOC);

     $uploadedby = $subadmincek['kullanici_mail'];

   } else if (isset($_SESSION{'subadminoturumc'})){

$admin_maill = $_SESSION['subadminoturumc'];
     $subadminsec = $db->prepare("SELECT * from kullanici where kullanici_mail='$admin_maill'");
     $subadminsec->execute();
     $subadmincek = $subadminsec->fetch(PDO::FETCH_ASSOC);

     $uploadedby = $subadmincek['kullanici_mail'];


   }

$hazirla = $db->prepare("INSERT into candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno,
kullanici_id=:kullanici_id,
candidate_called=:candidate_called,
candidate_tarihi=:candidate_tarihi,
candidate_remark=:candidate_remark,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_respond=:candidate_respond,
candidate_markdate=:candidate_markdate,
candidate_company=:candidate_company,
candidate_location=:candidate_location,
candidate_designation=:candidate_designation,
candidate_pincode=:candidate_pincode,
candidate_interestedto=:candidate_interestedto,
candidate_jobchange=:candidate_jobchange,
candidate_experience=:candidate_experience,
salary_monthlyannually=:salary_monthlyannually,
salary_amount=:salary_amount,
salary_measure=:salary_measure,
candidate_listed=:candidate_listed,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp,
candidate_raw=:candidate_raw,
candidate_clean=:candidate_clean,
candidate_uploadedby=:candidate_uploadedby

  ");


$derle = $hazirla->execute(array(

"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno,
"kullanici_id" => $kullanici_id,
"candidate_called" => '1',
"candidate_tarihi" => date('Y-m-d H:i:s'),
"candidate_remark" => $candidate_remark,
"candidate_respond" => $candidate_response,
"candidate_markdate" => $now,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_interestedto" => $candidate_interestedto,
"candidate_jobchange" => $candidate_jobchange,
"candidate_experience" => $candidate_experience,
"salary_monthlyannually" => $salary_monthlyannually,
"salary_amount" => $salary_amount,
"salary_measure" => $salary_measure,
"candidate_listed" => 1,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp,
"candidate_raw" => 'yes',
"candidate_clean" => $candidate_clean,
"candidate_uploadedby" => $uploadedby


));


$candidate_id = $db->lastInsertId();

if (strlen($candidate_referredby)>0) {

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));

 //Bu add olduğu için daha önceden ne olduğunu sormamız gerekiyor.O editte. Bir telefon numarası eklendiyse eklenen telefon numarası her türlü referrer'dır.

$hazirlav=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$referrer_id'

  ");

$derlev=$hazirlav->execute(array(

"candidate_referrer" => 'yes'

));


}





$kayitsor=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_id' and call_time='$now'");
$kayitsor->execute();
$kayitsay = $kayitsor->rowCount();


if ($kayitsay==0) {

  $hazirla2 = $db->prepare("INSERT into calllogs set

candidate_id=:candidate_id,
call_time=:call_time,
call_response=:call_response,
call_remark=:call_remark,
caller=:caller

  ");


$derle2=$hazirla2->execute(array(

"candidate_id" => $candidate_id,
"call_time" => $now,
"call_response" => $candidate_response,
"call_remark" => $candidate_remark,
"caller" => $uploadedby

));

 
}




if ($derle) {

echo "ok";

} else {

  echo "hata";

}






} else if (isset($_POST['editcandidate'])){


$candidate_ad = trim($_POST['candidate_ad']);
$candidate_soyad = trim($_POST['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_location = trim($_POST['candidate_location']);
$candidate_linkedin = trim($_POST['candidate_linkedin']);
$candidate_telno = trim($_POST['candidate_telno']);
$candidate_id = $_POST['candidate_id'];



$hazirla = $db->prepare("UPDATE candidates set

candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_location=:candidate_location,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno

where candidate_id = '$candidate_id'

  ");


$derle = $hazirla->execute(array(

"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_location" => $candidate_location,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno
));


if ($derle) {

echo "ok";

} else {

  echo "hata";

}





} else if (isset($_POST['editcandidateadmin'])){


$kullanici_id = $_POST['kullanici_id'];
$candidate_ad = trim($_POST['candidate_ad']);
$candidate_soyad = trim($_POST['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_linkedin = trim($_POST['candidate_linkedin']);
$candidate_telno = trim($_POST['candidate_telno']);
$candidate_id = $_POST['candidate_id'];







$hazirla = $db->prepare("UPDATE candidates set

kullanici_id=:kullanici_id,
candidate_ad=:candidate_ad,
candidate_soyad=:candidate_soyad,
candidate_adsoyad=:candidate_adsoyad,
candidate_linkedin=:candidate_linkedin,
candidate_telno=:candidate_telno

where candidate_id = '$candidate_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_id" => $kullanici_id,
"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_linkedin" => $candidate_linkedin,
"candidate_telno" => $candidate_telno
));


if ($derle) {

echo "ok";

} else {

  echo "hata";

}





} else if (isset($_POST['markcandidate'])){

  


$candidate_id = $_POST['candidate_id'];
$candidate_remark = $_POST['candidate_remark'];
$candidate_response = $_POST['candidate_response'];
$candidate_company = trim($_POST['candidate_company']);
$candidate_designation = trim($_POST['candidate_designation']);
$candidate_mail = trim($_POST['candidate_mail']);
$candidate_pincode = trim($_POST['candidate_pincode']);
$candidate_location = trim($_POST['candidate_location']);
$candidate_referredby = trim($_POST['candidate_referredby']);

if (!empty($_POST['candidate_interestedto'])) {
  $candidate_interestedto = trim($_POST['candidate_interestedto']);
} else {

  $candidate_interestedto = NULL;
}

if (!empty($_POST['candidate_product'])) {
  $candidate_product = trim($_POST['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($_POST['candidate_department'])) {
  $candidate_department = trim($_POST['candidate_department']);
} else {

  $candidate_department = NULL;
}


if ($_POST['candidate_jobchange']=='select') {
  
  $candidate_jobchange = NULL;
  
} else {

$candidate_jobchange = trim($_POST['candidate_jobchange']);
  
}

if (!empty($_POST['candidate_experience'])) {

$candidate_experience = trim($_POST['candidate_experience']);

 } else {

$candidate_experience = NULL;

}

$salary_monthlyannually = trim($_POST['salary_monthlyannually']);
$salary_amount = trim($_POST['salary_amount']);
$salary_measure = trim($_POST['salary_measure']);


$now = date('Y-m-d H:i:s');


if (strlen($candidate_referredby)>0) {
 
 // Aynı mı değişmiş mi soruyoruz.

$aynimisor=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$aynimisor->execute();
$aynimicek=$aynimisor->fetch(PDO::FETCH_ASSOC);
$aynimi_id = $aynimicek['referrer_id'];

$aynimisec=$db->prepare("SELECT * from candidates where candidate_id='$aynimi_id'");
$aynimisec->execute();
$aynimicek2=$aynimisec->fetch(PDO::FETCH_ASSOC);


if ($candidate_referredby!=$aynimicek2['candidate_telno']) {
  
//Aynı değilse yeni bir aksiyon demektir. Aynıysa değişme yok.

$refercandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_referredby' and candidate_clean='yes'");
$refercandidatesec->execute();

$refercandidatesay = $refercandidatesec->rowCount();

if ($refercandidatesay==0) {
  
  echo "refernotexistphone";exit;

} else { 


// Input dolu geldi demektir. Eğer input önceden de doluysa farklı bir veri gelmiştir, önceden boşsa referrer her türlü 'yes' olacak.

$referkontrolsec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$referkontrolsec->execute();
$referkontrolsay=$referkontrolsec->rowCount();
$refercandidatecek=$refercandidatesec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $refercandidatecek['candidate_id'];

if ($referkontrolsay==0) { //Boşsa

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));

 //Yeni referrer numarasına sen artık referrer'sın diyoruz.

 $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_telno='$candidate_referredby' and candidate_clean='yes'

  ");


 $derlex = $hazirlax->execute(array(

"candidate_referrer" => 'yes'

 ));
  


} else { //Zaten dolu ama farklı numaraysa.



  //Yeni referrer numarasına sen artık referrer'sın diyoruz.

 $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_telno='$candidate_referredby' and candidate_listed='1'

  ");


 $derlex = $hazirlax->execute(array(

"candidate_referrer" => 'yes'

 ));


$referchainsil=$db->prepare("DELETE from referchain where referred_id='$candidate_id'");
$referchainsil->execute();

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));


 //Yeni refer'in status'u yes yapıldı. eski chain silindi. Eski numaranın refer ettiği hala var mı diye soruyoruz. Kalmadıysa status 'no' çekiyoruz.



 $sec2=$db->prepare("SELECT * from referchain where referrer_id='$aynimi_id'");
$sec2->execute();
$say2=$sec2->rowCount();

if ($say2==0) {
  
  $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$aynimi_id'

    ");


  $derlex=$hazirlax->execute(array(

"candidate_referrer" => 'no'

  ));

}


}



}

}


} else {

  //GÖNDERİLEN INPUT BOŞSA ----------------

  $sec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$sec->execute();
$cek=$sec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $cek['referrer_id'];


$referchainsil=$db->prepare("DELETE from referchain where referred_id='$candidate_id'");
$referchainsil->execute();


//Eski refer'in referliği kalmamışsa status'u no'ya çevirioruz. Hala refer olduğu kişiler varsa dokunmuyoruz.

if (strlen($referrer_id)>0) { //Zaten önceden de boşsa işlemi yapmaya gerek yok.


$sec2=$db->prepare("SELECT * from referchain where referrer_id='$referrer_id'");
$sec2->execute();
$say2=$sec2->rowCount();

if ($say2==0) {
  
  $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$referrer_id'

    ");


  $derlex=$hazirlax->execute(array(

"candidate_referrer" => 'no'

  ));

}

}

//GÖNDERİLEN INPUT BOŞSA --------------


}




//Dump Datas ---------------------


$candidate_birthdate = trim($_POST['candidate_birthdate']);
$candidate_industry = trim($_POST['candidate_industry']);
$candidate_currentjobexperience = trim($_POST['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($_POST['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($_POST['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($_POST['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($_POST['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($_POST['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($_POST['candidate_prefferedlocation']);
$candidate_gender = trim($_POST['candidate_gender']);
$candidate_totalworkexperience = trim($_POST['candidate_totalworkexperience']);
$candidate_annualsalary = trim($_POST['candidate_annualsalary']);
$candidate_deeshamail = trim($_POST['candidate_deeshamail']);
$candidate_websitesource = trim($_POST['candidate_websitesource']);
$candidate_telno2 = trim($_POST['candidate_telno2']);
$candidate_wpno = trim($_POST['candidate_wpno']);
$candidate_wpno2 = trim($_POST['candidate_wpno2']);
$candidate_noticeperiod = trim($_POST['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($_POST['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($_POST['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($_POST['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($_POST['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($_POST['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($_POST['candidate_createdate']);
$candidate_lastmodifieddate = trim($_POST['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($_POST['candidate_lastactivedate']);
$candidate_note = trim($_POST['candidate_note']);
$candidate_summarydescription = trim($_POST['candidate_summarydescription']);
$candidate_experiencepershine = trim($_POST['candidate_experiencepershine']);
$candidate_lastjob = trim($_POST['candidate_lastjob']);
$candidate_lasttolastjob = trim($_POST['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($_POST['candidate_graducationcourse']);
$candidate_graduationcollege = trim($_POST['candidate_graduationcollege']);
$candidate_skills = trim($_POST['candidate_skills']);
$candidate_mayalsoknow = trim($_POST['candidate_mayalsoknow']);
$candidate_tiercity = trim($_POST['candidate_tiercity']);
$candidate_loanproduct = trim($_POST['candidate_loanproduct']);
$candidate_loansubproduct = trim($_POST['candidate_loansubproduct']);
$candidate_internalsource = trim($_POST['candidate_internalsource']);
$candidate_sourcetype = trim($_POST['candidate_sourcetype']);
$candidate_externalsource = trim($_POST['candidate_externalsource']);
$candidate_refferredname = trim($_POST['candidate_refferredname']);
$candidate_refferredbankname = trim($_POST['candidate_refferredbankname']);
$candidate_referredid = trim($_POST['candidate_referredid']);
$candidate_dateofentry = trim($_POST['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($_POST['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($_POST['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($_POST['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($_POST['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($_POST['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($_POST['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($_POST['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($_POST['candidate_currentbossname']);
$candidate_exbossname = trim($_POST['candidate_exbossname']);
$candidate_interestingfact = trim($_POST['candidate_interestingfact']);
$candidate_languagesspeak = trim($_POST['candidate_languagesspeak']);
$candidate_languageprefer = trim($_POST['candidate_languageprefer']);
$candidate_mothertongue = trim($_POST['candidate_mothertongue']);
$candidate_banker = trim($_POST['candidate_banker']);
$candidate_residenceaddress = trim($_POST['candidate_residenceaddress']);
$candidate_companyaddress = trim($_POST['candidate_companyaddress']);
$candidate_country = trim($_POST['candidate_country']);
$candidate_reportingmanagerno = trim($_POST['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($_POST['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($_POST['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($_POST['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($_POST['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($_POST['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($_POST['candidate_companyfinploy']);
$candidate_associatefinploy = trim($_POST['candidate_associatefinploy']);
$candidate_companyfinterno = trim($_POST['candidate_companyfinterno']);
$candidate_internfinterno = trim($_POST['candidate_internfinterno']);
$candidate_associatefinterno = trim($_POST['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($_POST['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($_POST['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($_POST['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($_POST['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($_POST['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($_POST['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($_POST['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($_POST['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($_POST['candidate_idcompanyfinterno']);
$candidate_idintern = trim($_POST['candidate_idintern']);
$candidate_idassociatefinterno = trim($_POST['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($_POST['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($_POST['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($_POST['candidate_idassociatefintubhai']);
$candidate_othercity = trim($_POST['candidate_othercity']);
$candidate_nameoncertificate = trim($_POST['candidate_nameoncertificate']);
$candidate_mothername = trim($_POST['candidate_mothername']);
$candidate_fathername = trim($_POST['candidate_fathername']);
$candidate_fathertelno = trim($_POST['candidate_fathertelno']);
$candidate_mothertelno = trim($_POST['candidate_mothertelno']);
$candidate_registrationsite = trim($_POST['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($_POST['candidate_interestedinbankingetc']);
$candidate_interests = trim($_POST['candidate_interests']);
$candidate_noofpastinternships = trim($_POST['candidate_noofpastinternships']);
$candidate_pastinternships = trim($_POST['candidate_pastinternships']);
$candidate_durationofinternship = trim($_POST['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($_POST['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($_POST['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($_POST['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($_POST['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($_POST['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($_POST['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($_POST['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($_POST['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($_POST['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($_POST['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($_POST['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($_POST['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($_POST['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($_POST['candidate_professortelno']);
$linkedin_name = trim($_POST['linkedin_name']);
$linkedin_namepos = trim($_POST['linkedin_namepos']);
$linkedin_companyname = trim($_POST['linkedin_companyname']);
$linkedin_cityname = trim($_POST['linkedin_cityname']);
$linkedin_statename = trim($_POST['linkedin_statename']);
$linkedin_namecountry = trim($_POST['linkedin_namecountry']);
$linkedin_currentjob = trim($_POST['linkedin_currentjob']);
$linkedin_secondlastjob = trim($_POST['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($_POST['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($_POST['linkedin_highesteducation']);
$linkedin_secondeducation = trim($_POST['linkedin_secondeducation']);
$linkedin_skills = trim($_POST['linkedin_skills']);
$linkedin_interests = trim($_POST['linkedin_interests']);
$linkedin_accomplishment = trim($_POST['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($_POST['linkedin_urlfromscrapper']);
$candidate_firstname = trim($_POST['candidate_firstname']);
$candidate_middlename = trim($_POST['candidate_middlename']);
$candidate_lastname = trim($_POST['candidate_lastname']);
$candidate_employeemail = trim($_POST['candidate_employeemail']);
$candidate_birthday = trim($_POST['candidate_birthday']);
$candidate_emailidofficial = trim($_POST['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($_POST['candidate_lastcallbydeeeshaemp']);


if (empty($salary_amount)) {
  
  $salary_amount = NULL;

}

$kayitsor=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_id' and call_time='$now'");
$kayitsor->execute();
$kayitsay = $kayitsor->rowCount();

if ($kayitsay==0) {


if (isset($_SESSION['adminoturum'])) {
  
$uploadedby = 'Master Admin';

} else if(isset($_SESSION['kullanicioturum'])) {

$maill = $_SESSION['kullanicioturum'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail='$maill'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$uploadedby = $kullanicicek['kullanici_mail'];

} else if(isset($_SESSION['subadminoturump'])) {

$maill = $_SESSION['subadminoturump'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail='$maill'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$uploadedby = $kullanicicek['kullanici_mail'];

} else if(isset($_SESSION['subadminoturumc'])) {

$maill = $_SESSION['subadminoturumc'];

$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_mail='$maill'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$uploadedby = $kullanicicek['kullanici_mail'];

}


  $hazirla2 = $db->prepare("INSERT into calllogs set

candidate_id=:candidate_id,
call_time=:call_time,
call_response=:call_response,
call_remark=:call_remark,
caller=:caller

  ");


$derle2=$hazirla2->execute(array(

"candidate_id" => $candidate_id,
"call_time" => $now,
"call_response" => $candidate_response,
"call_remark" => $candidate_remark,
"caller" => $uploadedby

));

 
}



$hazirla = $db->prepare("UPDATE candidates set

candidate_remark=:candidate_remark,
candidate_respond=:candidate_respond,
candidate_called=:candidate_called,
candidate_markdate=:candidate_markdate,
candidate_company=:candidate_company,
candidate_location=:candidate_location,
candidate_designation=:candidate_designation,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_pincode=:candidate_pincode,
candidate_interestedto=:candidate_interestedto,
candidate_jobchange=:candidate_jobchange,
candidate_experience=:candidate_experience,
salary_monthlyannually=:salary_monthlyannually,
salary_amount=:salary_amount,
salary_measure=:salary_measure,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp

where candidate_id='$candidate_id'

  ");


$derle = $hazirla->execute(array(

"candidate_remark" => $candidate_remark,
"candidate_respond" => $candidate_response,
"candidate_called" => '1',
"candidate_markdate" => $now,
"candidate_company" => $candidate_company,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_interestedto" => $candidate_interestedto,
"candidate_jobchange" => $candidate_jobchange,
"candidate_experience" => $candidate_experience,
"salary_monthlyannually" => $salary_monthlyannually,
"salary_amount" => $salary_amount,
"salary_measure" => $salary_measure,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp

));



if ($derle) {
 
 echo "ok";

}




} else if (isset($_POST['markcandidatepeople'])){

  


$candidate_id = $_POST['candidate_id'];
$candidate_remark = $_POST['candidate_remark'];
$candidate_response = $_POST['candidate_response'];
$candidate_company = trim($_POST['candidate_company']);
$candidate_designation = trim($_POST['candidate_designation']);
$candidate_mail = trim($_POST['candidate_mail']);
$candidate_pincode = trim($_POST['candidate_pincode']);
$candidate_location = trim($_POST['candidate_location']);

if (!empty($_POST['candidate_interestedto'])) {
  $candidate_interestedto = trim($_POST['candidate_interestedto']);
} else {

  $candidate_interestedto = NULL;
}

if (!empty($_POST['candidate_product'])) {
  $candidate_product = trim($_POST['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($_POST['candidate_department'])) {
  $candidate_department = trim($_POST['candidate_department']);
} else {

  $candidate_department = NULL;
}


if ($_POST['candidate_jobchange']=='select') {
  
  $candidate_jobchange = NULL;
  
} else {

$candidate_jobchange = trim($_POST['candidate_jobchange']);
  
}

if (!empty($_POST['candidate_experience'])) {

$candidate_experience = trim($_POST['candidate_experience']);

 } else {

$candidate_experience = NULL;

}

$salary_monthlyannually = trim($_POST['salary_monthlyannually']);
$salary_amount = trim($_POST['salary_amount']);
$salary_measure = trim($_POST['salary_measure']);


//Dump Datas ---------------------


$candidate_birthdate = trim($_POST['candidate_birthdate']);
$candidate_industry = trim($_POST['candidate_industry']);
$candidate_currentjobexperience = trim($_POST['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($_POST['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($_POST['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($_POST['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($_POST['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($_POST['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($_POST['candidate_prefferedlocation']);
$candidate_gender = trim($_POST['candidate_gender']);
$candidate_totalworkexperience = trim($_POST['candidate_totalworkexperience']);
$candidate_annualsalary = trim($_POST['candidate_annualsalary']);
$candidate_deeshamail = trim($_POST['candidate_deeshamail']);
$candidate_websitesource = trim($_POST['candidate_websitesource']);
$candidate_telno2 = trim($_POST['candidate_telno2']);
$candidate_wpno = trim($_POST['candidate_wpno']);
$candidate_wpno2 = trim($_POST['candidate_wpno2']);
$candidate_noticeperiod = trim($_POST['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($_POST['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($_POST['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($_POST['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($_POST['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($_POST['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($_POST['candidate_createdate']);
$candidate_lastmodifieddate = trim($_POST['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($_POST['candidate_lastactivedate']);
$candidate_note = trim($_POST['candidate_note']);
$candidate_summarydescription = trim($_POST['candidate_summarydescription']);
$candidate_experiencepershine = trim($_POST['candidate_experiencepershine']);
$candidate_lastjob = trim($_POST['candidate_lastjob']);
$candidate_lasttolastjob = trim($_POST['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($_POST['candidate_graducationcourse']);
$candidate_graduationcollege = trim($_POST['candidate_graduationcollege']);
$candidate_skills = trim($_POST['candidate_skills']);
$candidate_mayalsoknow = trim($_POST['candidate_mayalsoknow']);
$candidate_tiercity = trim($_POST['candidate_tiercity']);
$candidate_loanproduct = trim($_POST['candidate_loanproduct']);
$candidate_loansubproduct = trim($_POST['candidate_loansubproduct']);
$candidate_internalsource = trim($_POST['candidate_internalsource']);
$candidate_sourcetype = trim($_POST['candidate_sourcetype']);
$candidate_externalsource = trim($_POST['candidate_externalsource']);
$candidate_refferredname = trim($_POST['candidate_refferredname']);
$candidate_refferredbankname = trim($_POST['candidate_refferredbankname']);
$candidate_referredid = trim($_POST['candidate_referredid']);
$candidate_dateofentry = trim($_POST['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($_POST['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($_POST['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($_POST['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($_POST['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($_POST['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($_POST['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($_POST['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($_POST['candidate_currentbossname']);
$candidate_exbossname = trim($_POST['candidate_exbossname']);
$candidate_interestingfact = trim($_POST['candidate_interestingfact']);
$candidate_languagesspeak = trim($_POST['candidate_languagesspeak']);
$candidate_languageprefer = trim($_POST['candidate_languageprefer']);
$candidate_mothertongue = trim($_POST['candidate_mothertongue']);
$candidate_banker = trim($_POST['candidate_banker']);
$candidate_residenceaddress = trim($_POST['candidate_residenceaddress']);
$candidate_companyaddress = trim($_POST['candidate_companyaddress']);
$candidate_country = trim($_POST['candidate_country']);
$candidate_reportingmanagerno = trim($_POST['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($_POST['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($_POST['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($_POST['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($_POST['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($_POST['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($_POST['candidate_companyfinploy']);
$candidate_associatefinploy = trim($_POST['candidate_associatefinploy']);
$candidate_companyfinterno = trim($_POST['candidate_companyfinterno']);
$candidate_internfinterno = trim($_POST['candidate_internfinterno']);
$candidate_associatefinterno = trim($_POST['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($_POST['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($_POST['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($_POST['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($_POST['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($_POST['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($_POST['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($_POST['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($_POST['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($_POST['candidate_idcompanyfinterno']);
$candidate_idintern = trim($_POST['candidate_idintern']);
$candidate_idassociatefinterno = trim($_POST['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($_POST['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($_POST['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($_POST['candidate_idassociatefintubhai']);
$candidate_othercity = trim($_POST['candidate_othercity']);
$candidate_nameoncertificate = trim($_POST['candidate_nameoncertificate']);
$candidate_mothername = trim($_POST['candidate_mothername']);
$candidate_fathername = trim($_POST['candidate_fathername']);
$candidate_fathertelno = trim($_POST['candidate_fathertelno']);
$candidate_mothertelno = trim($_POST['candidate_mothertelno']);
$candidate_registrationsite = trim($_POST['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($_POST['candidate_interestedinbankingetc']);
$candidate_interests = trim($_POST['candidate_interests']);
$candidate_noofpastinternships = trim($_POST['candidate_noofpastinternships']);
$candidate_pastinternships = trim($_POST['candidate_pastinternships']);
$candidate_durationofinternship = trim($_POST['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($_POST['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($_POST['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($_POST['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($_POST['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($_POST['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($_POST['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($_POST['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($_POST['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($_POST['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($_POST['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($_POST['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($_POST['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($_POST['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($_POST['candidate_professortelno']);
$linkedin_name = trim($_POST['linkedin_name']);
$linkedin_namepos = trim($_POST['linkedin_namepos']);
$linkedin_companyname = trim($_POST['linkedin_companyname']);
$linkedin_cityname = trim($_POST['linkedin_cityname']);
$linkedin_statename = trim($_POST['linkedin_statename']);
$linkedin_namecountry = trim($_POST['linkedin_namecountry']);
$linkedin_currentjob = trim($_POST['linkedin_currentjob']);
$linkedin_secondlastjob = trim($_POST['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($_POST['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($_POST['linkedin_highesteducation']);
$linkedin_secondeducation = trim($_POST['linkedin_secondeducation']);
$linkedin_skills = trim($_POST['linkedin_skills']);
$linkedin_interests = trim($_POST['linkedin_interests']);
$linkedin_accomplishment = trim($_POST['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($_POST['linkedin_urlfromscrapper']);
$candidate_firstname = trim($_POST['candidate_firstname']);
$candidate_middlename = trim($_POST['candidate_middlename']);
$candidate_lastname = trim($_POST['candidate_lastname']);
$candidate_employeemail = trim($_POST['candidate_employeemail']);
$candidate_birthday = trim($_POST['candidate_birthday']);
$candidate_emailidofficial = trim($_POST['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($_POST['candidate_lastcallbydeeeshaemp']);


$now = date('Y-m-d H:i:s');





if (empty($salary_amount)) {
  
  $salary_amount = NULL;

}

$kayitsor=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_id' and call_time='$now'");
$kayitsor->execute();
$kayitsay = $kayitsor->rowCount();

if ($kayitsay==0) {

  $hazirla2 = $db->prepare("INSERT into calllogs set

candidate_id=:candidate_id,
call_time=:call_time,
call_response=:call_response,
call_remark=:call_remark

  ");


$derle2=$hazirla2->execute(array(

"candidate_id" => $candidate_id,
"call_time" => $now,
"call_response" => $candidate_response,
"call_remark" => $candidate_remark

));

 
}



$hazirla = $db->prepare("UPDATE candidates set

candidate_remark=:candidate_remark,
candidate_respond=:candidate_respond,
candidate_called=:candidate_called,
candidate_markdate=:candidate_markdate,
candidate_company=:candidate_company,
candidate_location=:candidate_location,
candidate_designation=:candidate_designation,
candidate_mail=:candidate_mail,
candidate_product=:candidate_product,
candidate_department=:candidate_department,
candidate_pincode=:candidate_pincode,
candidate_interestedto=:candidate_interestedto,
candidate_jobchange=:candidate_jobchange,
candidate_experience=:candidate_experience,
salary_monthlyannually=:salary_monthlyannually,
salary_amount=:salary_amount,
salary_measure=:salary_measure,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp

where candidate_id='$candidate_id'

  ");


$derle = $hazirla->execute(array(

"candidate_remark" => $candidate_remark,
"candidate_respond" => $candidate_response,
"candidate_called" => '1',
"candidate_markdate" => $now,
"candidate_company" => $candidate_company,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_interestedto" => $candidate_interestedto,
"candidate_jobchange" => $candidate_jobchange,
"candidate_experience" => $candidate_experience,
"salary_monthlyannually" => $salary_monthlyannually,
"salary_amount" => $salary_amount,
"salary_measure" => $salary_measure,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp

));



if ($derle) {
 
 echo "ok";

}




}  else if (isset($_POST['kullanicistatssec'])){



  $kullanici_mail = $_SESSION['kullanicioturum'];

  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
  $kullanicisec->execute();
  $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

  $kullanici_idd = $kullanicicek['kullanici_id'];

  $zaman = $_POST['zaman'];
  $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and DATE(candidate_tarihi) = '$zaman' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>






                          
                      <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                </div>


                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                </div>

                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                </div>

                             

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                </div>


                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                </div>

                               <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                </div>


                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                </div>

                               

                            </div>

                           



                          

 <?php } else if (isset($_POST['adminstatssec'])){




  $zaman = $_POST['zaman'];
  $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT candidate_id from candidates where DATE(candidate_tarihi) = '$zaman' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT candidate_id from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT candidate_id from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>






                          
                      <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                 <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexport=ok&date=<?php echo $zaman; ?>&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>
                           



                          

 <?php } else if (isset($_POST['admincstatssec'])){




  $zaman = $_POST['zaman'];
  $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>






                          
                      <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                 

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                 

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                 

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  

                                </div>

                               

                            </div>
                           



                          

 <?php } else if (isset($_POST['adminstatssecemployee'])){




  $zaman = $_POST['zaman'];
  $employee_id = $_POST['employee_id'];
  $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>






                          
                      <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                 <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <input type="hidden" id="employee_id" value="<?php echo $employee_id; ?>" name="employee_id">

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?datesingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&date=<?php echo $zaman; ?>&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <input type="hidden" id="employee_id" value="<?php echo $employee_id; ?>" name="employee_id">

                               

                            </div>
                           



                          

 <?php } else if (isset($_POST['admincstatssecemployee'])){




  $zaman = $_POST['zaman'];
  $employee_id = $_POST['employee_id'];
  $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>






                          
                      <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                 

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                 

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                 

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                 

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                 

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  

                                </div>


                                <input type="hidden" id="employee_id" value="<?php echo $employee_id; ?>" name="employee_id">

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  

                                </div>


                                <input type="hidden" id="employee_id" value="<?php echo $employee_id; ?>" name="employee_id">

                               

                            </div>
                           



                          

 <?php } else if (isset($_GET['employeesexport']) and $_GET['employeesexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "employees_" . date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('DATE CREATED', 'ID', 'NAME', 'SURNAME','PHONE', 'MAIL','PASSWORD','CITY NAME', 'LAST MODIFIED'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='1' order by kullanici_kayitzaman DESC");
$kullanicisec->execute();
while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {

  $kayit_tarihi = $kullanicicek['kullanici_kayitzaman'];
  $last_modified = $kullanicicek['kullanici_datamodified'];

  $date = substr($kayit_tarihi, 0,10);
  $date2 = substr($last_modified, 0,10);

  $lineData = array($date,$kullanicicek['kullanici_id'],$kullanicicek['kullanici_ad'],$kullanicicek['kullanici_soyad'],$kullanicicek['kullanici_telno'],$kullanicicek['kullanici_mail'],$kullanicicek['kullanici_password'],$kullanicicek['kullanici_sehir'],$date2);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['subadminsexport']) and $_GET['subadminsexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "subadmins_" . date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('DATE CREATED', 'ID', 'NAME', 'SURNAME','PHONE', 'MAIL','PASSWORD','CITY NAME', 'LAST MODIFIED'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='4' order by kullanici_kayitzaman DESC");
$kullanicisec->execute();
while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {

  $kayit_tarihi = $kullanicicek['kullanici_kayitzaman'];
  $last_modified = $kullanicicek['kullanici_datamodified'];

  $date = substr($kayit_tarihi, 0,10);
  $date2 = substr($last_modified, 0,10);

  $lineData = array($date,$kullanicicek['kullanici_id'],$kullanicicek['kullanici_ad'],$kullanicicek['kullanici_soyad'],$kullanicicek['kullanici_telno'],$kullanicicek['kullanici_mail'],$kullanicicek['kullanici_password'],$kullanicicek['kullanici_sehir'],$date2);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['childsubadminsexport']) and $_GET['childsubadminsexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "subadmins_" . date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('DATE CREATED', 'ID', 'NAME', 'SURNAME','PHONE', 'MAIL','PASSWORD','CITY NAME', 'LAST MODIFIED'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='4' and subadmin_type='child' order by kullanici_kayitzaman DESC");
$kullanicisec->execute();
while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {

  $kayit_tarihi = $kullanicicek['kullanici_kayitzaman'];
  $last_modified = $kullanicicek['kullanici_datamodified'];

  $date = substr($kayit_tarihi, 0,10);
  $date2 = substr($last_modified, 0,10);

  $lineData = array($date,$kullanicicek['kullanici_id'],$kullanicicek['kullanici_ad'],$kullanicicek['kullanici_soyad'],$kullanicicek['kullanici_telno'],$kullanicicek['kullanici_mail'],$kullanicicek['kullanici_password'],$kullanicicek['kullanici_sehir'],$date2);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['candidatesexport']) and $_GET['candidatesexport']=='ok'){


 if (isset($_SESSION['subadminoturump'])) {


   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "candidates_" . date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'NAME', 'SURNAME', 'MAIL', 'PHONE', 'Added Date'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_yetki='1' order by kullanici_kayitzaman DESC");
$kullanicisec->execute();
while ($kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC)) {

  $kayit_tarihi = $kullanicicek['kullanici_kayitzaman'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($kullanicicek['kullanici_id'],$kullanicicek['kullanici_ad'],$kullanicicek['kullanici_soyad'],$kullanicicek['kullanici_mail'],$kullanicicek['kullanici_telno'],$date);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['candidateexport']) and $_GET['candidateexport']=='ok'){



  if (isset($_SESSION['subadminoturump'])) {

    $subadmin_id = $adminsessioncek['kullanici_id'];

 
  $kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {

     $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

      ");


    $derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_todayprofileview+1

    ));


  }

} else {


  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

      ");


    $derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => 1

    ));


}

 




  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

  $candidate_id = $_GET['candidate_id'];


  $candidatesecx=$db->prepare("SELECT * from candidates where candidate_id = '$candidate_id'");
  $candidatesecx->execute();
  $candidatecekx = $candidatesecx->fetch(PDO::FETCH_ASSOC);

  $candidate_called = $candidatecekx['candidate_called'];
  $candidate_salary = $candidatecekx['salary_monthlyannually']." ".$candidatecekx['salary_amount']." ".$candidatecekx['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "candidate_". $candidate_id ."_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT' ,'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK','EMPLOYEE MAIL','FIRST NAME','MIDDLE NAME','LAST NAME','DOB','Current Industry','Years in Current Job','Current Functional Area','Banking department 1','Banking sub-department 2','Location handled - More than 1 city - Yes / No?','If yes, then names of all cities handled (system allow multiple option entry, city or state or combination, etc.) similar to shine - maximum 20','Preferred Location','Gender','Total Work Experience','Current Annual Salary','Email ID Official','Deeeshas email id','Deeesha Group Website source','Contact Number2','Whatsapp Number1','Whatsapp Number2','Notice Period','Highest Education Level','Highest Education Stream','Highest Education Institute','Year Of Passing','Highest Education Course Type','Create date','Last Modified Date','Last Active Date','Note','3rd line - person description summary','Total Work Experience as per Shine portal copy/paste','5th line - part 1 - last job','5th line - part 2 - last to last job','7th line - part 1 graduation course','7thh line part -2 graduation college','8th - skills','9th may also know','Tier city','Loan product','Loan sub-product','Internal Source','Source Type (Excel of SQL)','External source: Company/Shine/Linkedin/Workindia/Deeesha','Referred by : Person Name','Referred by : Bankname of the Person Name','Referred by: Person Sr. no','Date of entry','Deeesha Employee name who referred','Deeesha Employee name who entered the data','Birthday (etc. 9 July, not 09-07)','Marriage Anniv day','Last access date & time','Last access person','Deeesha employee feedback on the person - e..g friendly, supportive, always busy, not interested in us, etc. multiple button, just click few buttons','Remark / Comment by Deeesha employee, if any - note format','Current Boss name','Ex-boss name','Last Call by Deeesha employee to the person - date / time and name of person - click button - automated filling','Interesting fact about the person','Which Languages do you speak?','Which languages do you prefer?','Mother Tongue','banker','residence address','companys address','country','Reporting Managers no.','are saturdays working?','Associate - Deeesha','Banker - Deeesha','Customer - Deeesha','Candidate - FInploy','Company - Finploy','Associate - FInploy','Company - Finterno','Intern- Finterno','Associate- Finterno','Company - Fintubhai','Customer - Fintubhai','Associate- Fintubhai','ID Associate - Deeesha ','ID Banker - Deeesha','ID Customer - Deeesha','ID Candidate - FInploy','ID Associate - FInploy','ID Company - Finterno','ID Intern- Finterno','ID Associate- Finterno','ID Company - Fintubhai','ID Customer - Fintubhai','ID Associate- Fintubhai','Other City','Name as you want on the certificate','Mothers name','fathers name','fathers contact no.','mothers contact no.','Registration site [D2C,FINTERNO,GOOGLE FORMS]','Are You Interested in Banking/Finance Industry?','Interests','No. Of Past Internships','Past Internships(mention if more than one)','Duration Of Internship','Have you done an Internship with DEEESHA Finance?','Are You Looking for an Education Loan?','Roles in previous Internship','What type of internship are you looking for?','Would you like to join in as a full time employee','what type of internship do you prefer? Part time/Full time','How many hours can you dedicate?','Do you have a personalized laptop at home?','Do you have stable internet connection?','what type of internship do you prefer? In-Office or Work From Home.','How many days do you prefer working in a week?','What is your desired Income?','Do you have  technical knowledge? [Operating Basic Computer]','Professor contact no.','Linkedin name','Linkedin name pos','Linkedin name company','Linkedin name city','Linkedin name state','Linkedin name country','Linkedin name current_job','Linkedin name second_last_job','Linkedin name third_last_job','Linkedin name highest_education','Linkedin name second_education','Linkedin name skills','Linkedin name interests','Linkedin name accomplishment','Linkedin name url from scraper'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) {

  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark'],$candidatecek['candidate_employeemail'],$candidatecek['candidate_firstname'],$candidatecek['candidate_middlename'],$candidatecek['candidate_lastname'],$candidatecek['candidate_birthdate'],$candidatecek['candidate_industry'],$candidatecek['candidate_currentjobexperience'],$candidatecek['candidate_currentfunctionalarea'],$candidatecek['candidate_bankingdepartment'],$candidatecek['candidate_bankingsubdepartment'],$candidatecek['candidate_multiplelocation'],$candidatecek['candidate_multiplelocationnames'],$candidatecek['candidate_prefferedlocation'],$candidatecek['candidate_gender'],$candidatecek['candidate_totalworkexperience'],$candidatecek['candidate_annualsalary'],$candidatecek['candidate_emailidofficial'],$candidatecek['candidate_deeshamail'],$candidatecek['candidate_websitesource'],$candidatecek['candidate_telno2'],$candidatecek['candidate_wpno'],$candidatecek['candidate_wpno2'],$candidatecek['candidate_noticeperiod'],$candidatecek['candidate_highesteducationlevel'],$candidatecek['candidate_highesteducationstream'],$candidatecek['candidate_highesteducationinsitute'],$candidatecek['candidate_yearofpassing'],$candidatecek['candidate_highesteducationcoursetype'],$candidatecek['candidate_createdate'],$candidatecek['candidate_lastmodifieddate'],$candidatecek['candidate_lastactivedatex'],$candidatecek['candidate_note'],$candidatecek['candidate_summarydescription'],$candidatecek['candidate_experiencepershine'],$candidatecek['candidate_lastjob'],$candidatecek['candidate_lasttolastjob'],$candidatecek['candidate_graducationcourse'],$candidatecek['candidate_graduationcollege'],$candidatecek['candidate_skills'],$candidatecek['candidate_mayalsoknow'],$candidatecek['candidate_tiercity'],$candidatecek['candidate_loanproduct'],$candidatecek['candidate_loansubproduct'],$candidatecek['candidate_internalsource'],$candidatecek['candidate_sourcetype'],$candidatecek['candidate_externalsource'],$candidatecek['candidate_refferredname'],$candidatecek['candidate_refferredbankname'],$candidatecek['candidate_referredid'],$candidatecek['candidate_dateofentry'],$candidatecek['candidate_deeshaemployeenamerefer'],$candidatecek['candidate_deeshaemployeenameenter'],$candidatecek['candidate_birthday'],$candidatecek['candidate_marriageanniv'],$candidatecek['candidate_lastaccessdate'],$candidatecek['candidate_lastaccessperson'],$candidatecek['candidate_deeshaemployeefeedback'],$candidatecek['candidate_deeshaemployeecomment'],$candidatecek['candidate_currentbossname'],$candidatecek['candidate_exbossname'],$candidatecek['candidate_lastcallbydeeeshaemp'],$candidatecek['candidate_interestingfact'],$candidatecek['candidate_languagesspeak'],$candidatecek['candidate_languageprefer'],$candidatecek['candidate_mothertongue'],$candidatecek['candidate_banker'],$candidatecek['candidate_residenceaddress'],$candidatecek['candidate_companyaddress'],$candidatecek['candidate_country'],$candidatecek['candidate_reportingmanagerno'],$candidatecek['candidate_saturdayworking'],$candidatecek['candidate_associatedeeesha'],$candidatecek['candidate_bankerdeeesha'],$candidatecek['candidate_customerdeeesha'],$candidatecek['candidate_candidatefinploy'],$candidatecek['candidate_companyfinploy'],$candidatecek['candidate_associatefinploy'],$candidatecek['candidate_companyfinterno'],$candidatecek['candidate_internfinterno'],$candidatecek['candidate_associatefinterno'],$candidatecek['candidate_companyfintubhai'],$candidatecek['candidate_customerfintubhai'],$candidatecek['candidate_associatefintubhai'],$candidatecek['candidate_idassociatedeeesha'],$candidatecek['candidate_idbankerdeeesha'],$candidatecek['candidate_idcustomerdeeesha'],$candidatecek['candidate_idcandidatefinploy'],$candidatecek['candidate_idassociatefinploy'],$candidatecek['candidate_idcompanyfinterno'],$candidatecek['candidate_idintern'],$candidatecek['candidate_idassociatefinterno'],$candidatecek['candidate_idcompanyfintubhai'],$candidatecek['candidate_idcustomerfintubhai'],$candidatecek['candidate_idassociatefintubhai'],$candidatecek['candidate_othercity'],$candidatecek['candidate_nameoncertificate'],$candidatecek['candidate_mothername'],$candidatecek['candidate_fathername'],$candidatecek['candidate_fathertelno'],$candidatecek['candidate_mothertelno'],$candidatecek['candidate_registrationsite'],$candidatecek['candidate_interestedinbankingetc'],$candidatecek['candidate_interests'],$candidatecek['candidate_noofpastinternships'],$candidatecek['candidate_pastinternships'],$candidatecek['candidate_durationofinternship'],$candidatecek['candidate_haveyoudonewithdeeesha'],$candidatecek['candidate_areyoulookeducationloan'],$candidatecek['candidate_rolesinpreviousinternship'],$candidatecek['candidate_typeofinternship'],$candidatecek['candidate_joinasafulltimeemployee'],$candidatecek['candidate_internshipprefer'],$candidatecek['candidate_hoursdedicate'],$candidatecek['candidate_personalizedlaptop'],$candidatecek['candidate_stableconnection'],$candidatecek['candidate_typeofinternship2'],$candidatecek['candidate_howdaysworkaweek'],$candidatecek['candidate_desiredincome'],$candidatecek['candidate_havetechnicalknowledge'],$candidatecek['candidate_professortelno'],$candidatecek['linkedin_name'],$candidatecek['linkedin_namepos'],$candidatecek['linkedin_companyname'],$candidatecek['linkedin_cityname'],$candidatecek['linkedin_statename'],$candidatecek['linkedin_namecountry'],$candidatecek['linkedin_currentjob'],$candidatecek['linkedin_secondlastjob'],$candidatecek['linkedin_thirdlastjob'],$candidatecek['linkedin_highesteducation'],$candidatecek['linkedin_secondeducation'],$candidatecek['linkedin_skills'],$candidatecek['linkedin_interests'],$candidatecek['linkedin_accomplishment'],$candidatecek['linkedin_urlfromscrapper']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['alreadyexistexport']) and $_GET['alreadyexistexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

$datee=$_GET['date'];

// Excel file name for download 
$fileName = "uploadreport_". $datee . ".xls"; 


// Column names 
$fields = array('EXIST STATUS','ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_tarihi='$datee' order by candidate_tarihi DESC");
$candidatesec->execute();
while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) {


  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $candidate_called = $candidatecek['candidate_called'];
  $candidate_alreadyexist = $candidatecek['candidate_alreadyexist'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }


  if ($candidate_alreadyexist=='1') {

    $existstatus = 'ALREADY EXIST';

  } else {

    $existstatus = 'NEW';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($existstatus,$candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['rawcandidatesexport']) and $_GET['rawcandidatesexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "rawdumpcandidates_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK','EMPLOYEE MAIL','FIRST NAME','MIDDLE NAME','LAST NAME','DOB','Current Industry','Years in Current Job','Current Functional Area','Banking department 1','Banking sub-department 2','Location handled - More than 1 city - Yes / No?','If yes, then names of all cities handled (system allow multiple option entry, city or state or combination, etc.) similar to shine - maximum 20','Preferred Location','Gender','Total Work Experience','Current Annual Salary','Email ID Official','Deeeshas email id','Deeesha Group Website source','Contact Number2','Whatsapp Number1','Whatsapp Number2','Notice Period','Highest Education Level','Highest Education Stream','Highest Education Institute','Year Of Passing','Highest Education Course Type','Create date','Last Modified Date','Last Active Date','Note','3rd line - person description summary','Total Work Experience as per Shine portal copy/paste','5th line - part 1 - last job','5th line - part 2 - last to last job','7th line - part 1 graduation course','7thh line part -2 graduation college','8th - skills','9th may also know','Tier city','Loan product','Loan sub-product','Internal Source','Source Type (Excel of SQL)','External source: Company/Shine/Linkedin/Workindia/Deeesha','Referred by : Person Name','Referred by : Bankname of the Person Name','Referred by: Person Sr. no','Date of entry','Deeesha Employee name who referred','Deeesha Employee name who entered the data','Birthday (etc. 9 July, not 09-07)','Marriage Anniv day','Last access date & time','Last access person','Deeesha employee feedback on the person - e..g friendly, supportive, always busy, not interested in us, etc. multiple button, just click few buttons','Remark / Comment by Deeesha employee, if any - note format','Current Boss name','Ex-boss name','Last Call by Deeesha employee to the person - date / time and name of person - click button - automated filling','Interesting fact about the person','Which Languages do you speak?','Which languages do you prefer?','Mother Tongue','banker','residence address','companys address','country','Reporting Managers no.','are saturdays working?','Associate - Deeesha','Banker - Deeesha','Customer - Deeesha','Candidate - FInploy','Company - Finploy','Associate - FInploy','Company - Finterno','Intern- Finterno','Associate- Finterno','Company - Fintubhai','Customer - Fintubhai','Associate- Fintubhai','ID Associate - Deeesha ','ID Banker - Deeesha','ID Customer - Deeesha','ID Candidate - FInploy','ID Associate - FInploy','ID Company - Finterno','ID Intern- Finterno','ID Associate- Finterno','ID Company - Fintubhai','ID Customer - Fintubhai','ID Associate- Fintubhai','Other City','Name as you want on the certificate','Mothers name','fathers name','fathers contact no.','mothers contact no.','Registration site [D2C,FINTERNO,GOOGLE FORMS]','Are You Interested in Banking/Finance Industry?','Interests','No. Of Past Internships','Past Internships(mention if more than one)','Duration Of Internship','Have you done an Internship with DEEESHA Finance?','Are You Looking for an Education Loan?','Roles in previous Internship','What type of internship are you looking for?','Would you like to join in as a full time employee','what type of internship do you prefer? Part time/Full time','How many hours can you dedicate?','Do you have a personalized laptop at home?','Do you have stable internet connection?','what type of internship do you prefer? In-Office or Work From Home.','How many days do you prefer working in a week?','What is your desired Income?','Do you have  technical knowledge? [Operating Basic Computer]','Professor contact no.','Linkedin name','Linkedin name pos','Linkedin name company','Linkedin name city','Linkedin name state','Linkedin name country','Linkedin name current_job','Linkedin name second_last_job','Linkedin name third_last_job','Linkedin name highest_education','Linkedin name second_education','Linkedin name skills','Linkedin name interests','Linkedin name accomplishment','Linkedin name url from scraper'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_raw='yes' order by candidate_tarihi DESC");
$candidatesec->execute();
$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;

while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;


  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark'],$candidatecek['candidate_employeemail'],$candidatecek['candidate_firstname'],$candidatecek['candidate_middlename'],$candidatecek['candidate_lastname'],$candidatecek['candidate_birthdate'],$candidatecek['candidate_industry'],$candidatecek['candidate_currentjobexperience'],$candidatecek['candidate_currentfunctionalarea'],$candidatecek['candidate_bankingdepartment'],$candidatecek['candidate_bankingsubdepartment'],$candidatecek['candidate_multiplelocation'],$candidatecek['candidate_multiplelocationnames'],$candidatecek['candidate_prefferedlocation'],$candidatecek['candidate_gender'],$candidatecek['candidate_totalworkexperience'],$candidatecek['candidate_annualsalary'],$candidatecek['candidate_emailidofficial'],$candidatecek['candidate_deeshamail'],$candidatecek['candidate_websitesource'],$candidatecek['candidate_telno2'],$candidatecek['candidate_wpno'],$candidatecek['candidate_wpno2'],$candidatecek['candidate_noticeperiod'],$candidatecek['candidate_highesteducationlevel'],$candidatecek['candidate_highesteducationstream'],$candidatecek['candidate_highesteducationinsitute'],$candidatecek['candidate_yearofpassing'],$candidatecek['candidate_highesteducationcoursetype'],$candidatecek['candidate_createdate'],$candidatecek['candidate_lastmodifieddate'],$candidatecek['candidate_lastactivedatex'],$candidatecek['candidate_note'],$candidatecek['candidate_summarydescription'],$candidatecek['candidate_experiencepershine'],$candidatecek['candidate_lastjob'],$candidatecek['candidate_lasttolastjob'],$candidatecek['candidate_graducationcourse'],$candidatecek['candidate_graduationcollege'],$candidatecek['candidate_skills'],$candidatecek['candidate_mayalsoknow'],$candidatecek['candidate_tiercity'],$candidatecek['candidate_loanproduct'],$candidatecek['candidate_loansubproduct'],$candidatecek['candidate_internalsource'],$candidatecek['candidate_sourcetype'],$candidatecek['candidate_externalsource'],$candidatecek['candidate_refferredname'],$candidatecek['candidate_refferredbankname'],$candidatecek['candidate_referredid'],$candidatecek['candidate_dateofentry'],$candidatecek['candidate_deeshaemployeenamerefer'],$candidatecek['candidate_deeshaemployeenameenter'],$candidatecek['candidate_birthday'],$candidatecek['candidate_marriageanniv'],$candidatecek['candidate_lastaccessdate'],$candidatecek['candidate_lastaccessperson'],$candidatecek['candidate_deeshaemployeefeedback'],$candidatecek['candidate_deeshaemployeecomment'],$candidatecek['candidate_currentbossname'],$candidatecek['candidate_exbossname'],$candidatecek['candidate_lastcallbydeeeshaemp'],$candidatecek['candidate_interestingfact'],$candidatecek['candidate_languagesspeak'],$candidatecek['candidate_languageprefer'],$candidatecek['candidate_mothertongue'],$candidatecek['candidate_banker'],$candidatecek['candidate_residenceaddress'],$candidatecek['candidate_companyaddress'],$candidatecek['candidate_country'],$candidatecek['candidate_reportingmanagerno'],$candidatecek['candidate_saturdayworking'],$candidatecek['candidate_associatedeeesha'],$candidatecek['candidate_bankerdeeesha'],$candidatecek['candidate_customerdeeesha'],$candidatecek['candidate_candidatefinploy'],$candidatecek['candidate_companyfinploy'],$candidatecek['candidate_associatefinploy'],$candidatecek['candidate_companyfinterno'],$candidatecek['candidate_internfinterno'],$candidatecek['candidate_associatefinterno'],$candidatecek['candidate_companyfintubhai'],$candidatecek['candidate_customerfintubhai'],$candidatecek['candidate_associatefintubhai'],$candidatecek['candidate_idassociatedeeesha'],$candidatecek['candidate_idbankerdeeesha'],$candidatecek['candidate_idcustomerdeeesha'],$candidatecek['candidate_idcandidatefinploy'],$candidatecek['candidate_idassociatefinploy'],$candidatecek['candidate_idcompanyfinterno'],$candidatecek['candidate_idintern'],$candidatecek['candidate_idassociatefinterno'],$candidatecek['candidate_idcompanyfintubhai'],$candidatecek['candidate_idcustomerfintubhai'],$candidatecek['candidate_idassociatefintubhai'],$candidatecek['candidate_othercity'],$candidatecek['candidate_nameoncertificate'],$candidatecek['candidate_mothername'],$candidatecek['candidate_fathername'],$candidatecek['candidate_fathertelno'],$candidatecek['candidate_mothertelno'],$candidatecek['candidate_registrationsite'],$candidatecek['candidate_interestedinbankingetc'],$candidatecek['candidate_interests'],$candidatecek['candidate_noofpastinternships'],$candidatecek['candidate_pastinternships'],$candidatecek['candidate_durationofinternship'],$candidatecek['candidate_haveyoudonewithdeeesha'],$candidatecek['candidate_areyoulookeducationloan'],$candidatecek['candidate_rolesinpreviousinternship'],$candidatecek['candidate_typeofinternship'],$candidatecek['candidate_joinasafulltimeemployee'],$candidatecek['candidate_internshipprefer'],$candidatecek['candidate_hoursdedicate'],$candidatecek['candidate_personalizedlaptop'],$candidatecek['candidate_stableconnection'],$candidatecek['candidate_typeofinternship2'],$candidatecek['candidate_howdaysworkaweek'],$candidatecek['candidate_desiredincome'],$candidatecek['candidate_havetechnicalknowledge'],$candidatecek['candidate_professortelno'],$candidatecek['linkedin_name'],$candidatecek['linkedin_namepos'],$candidatecek['linkedin_companyname'],$candidatecek['linkedin_cityname'],$candidatecek['linkedin_statename'],$candidatecek['linkedin_namecountry'],$candidatecek['linkedin_currentjob'],$candidatecek['linkedin_secondlastjob'],$candidatecek['linkedin_thirdlastjob'],$candidatecek['linkedin_highesteducation'],$candidatecek['linkedin_secondeducation'],$candidatecek['linkedin_skills'],$candidatecek['linkedin_interests'],$candidatecek['linkedin_accomplishment'],$candidatecek['linkedin_urlfromscrapper']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 


if ($sayi==$indirsayisi) {

  break;

}


}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['cleancandidatesexport']) and $_GET['cleancandidatesexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "cleancdumpandidates_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK','EMPLOYEE MAIL','FIRST NAME','MIDDLE NAME','LAST NAME','DOB','Current Industry','Years in Current Job','Current Functional Area','Banking department 1','Banking sub-department 2','Location handled - More than 1 city - Yes / No?','If yes, then names of all cities handled (system allow multiple option entry, city or state or combination, etc.) similar to shine - maximum 20','Preferred Location','Gender','Total Work Experience','Current Annual Salary','Email ID Official','Deeeshas email id','Deeesha Group Website source','Contact Number2','Whatsapp Number1','Whatsapp Number2','Notice Period','Highest Education Level','Highest Education Stream','Highest Education Institute','Year Of Passing','Highest Education Course Type','Create date','Last Modified Date','Last Active Date','Note','3rd line - person description summary','Total Work Experience as per Shine portal copy/paste','5th line - part 1 - last job','5th line - part 2 - last to last job','7th line - part 1 graduation course','7thh line part -2 graduation college','8th - skills','9th may also know','Tier city','Loan product','Loan sub-product','Internal Source','Source Type (Excel of SQL)','External source: Company/Shine/Linkedin/Workindia/Deeesha','Referred by : Person Name','Referred by : Bankname of the Person Name','Referred by: Person Sr. no','Date of entry','Deeesha Employee name who referred','Deeesha Employee name who entered the data','Birthday (etc. 9 July, not 09-07)','Marriage Anniv day','Last access date & time','Last access person','Deeesha employee feedback on the person - e..g friendly, supportive, always busy, not interested in us, etc. multiple button, just click few buttons','Remark / Comment by Deeesha employee, if any - note format','Current Boss name','Ex-boss name','Last Call by Deeesha employee to the person - date / time and name of person - click button - automated filling','Interesting fact about the person','Which Languages do you speak?','Which languages do you prefer?','Mother Tongue','banker','residence address','companys address','country','Reporting Managers no.','are saturdays working?','Associate - Deeesha','Banker - Deeesha','Customer - Deeesha','Candidate - FInploy','Company - Finploy','Associate - FInploy','Company - Finterno','Intern- Finterno','Associate- Finterno','Company - Fintubhai','Customer - Fintubhai','Associate- Fintubhai','ID Associate - Deeesha ','ID Banker - Deeesha','ID Customer - Deeesha','ID Candidate - FInploy','ID Associate - FInploy','ID Company - Finterno','ID Intern- Finterno','ID Associate- Finterno','ID Company - Fintubhai','ID Customer - Fintubhai','ID Associate- Fintubhai','Other City','Name as you want on the certificate','Mothers name','fathers name','fathers contact no.','mothers contact no.','Registration site [D2C,FINTERNO,GOOGLE FORMS]','Are You Interested in Banking/Finance Industry?','Interests','No. Of Past Internships','Past Internships(mention if more than one)','Duration Of Internship','Have you done an Internship with DEEESHA Finance?','Are You Looking for an Education Loan?','Roles in previous Internship','What type of internship are you looking for?','Would you like to join in as a full time employee','what type of internship do you prefer? Part time/Full time','How many hours can you dedicate?','Do you have a personalized laptop at home?','Do you have stable internet connection?','what type of internship do you prefer? In-Office or Work From Home.','How many days do you prefer working in a week?','What is your desired Income?','Do you have  technical knowledge? [Operating Basic Computer]','Professor contact no.','Linkedin name','Linkedin name pos','Linkedin name company','Linkedin name city','Linkedin name state','Linkedin name country','Linkedin name current_job','Linkedin name second_last_job','Linkedin name third_last_job','Linkedin name highest_education','Linkedin name second_education','Linkedin name skills','Linkedin name interests','Linkedin name accomplishment','Linkedin name url from scraper'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_clean='yes' order by candidate_tarihi DESC");
$candidatesec->execute();

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;

while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;


  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark'],$candidatecek['candidate_employeemail'],$candidatecek['candidate_firstname'],$candidatecek['candidate_middlename'],$candidatecek['candidate_lastname'],$candidatecek['candidate_birthdate'],$candidatecek['candidate_industry'],$candidatecek['candidate_currentjobexperience'],$candidatecek['candidate_currentfunctionalarea'],$candidatecek['candidate_bankingdepartment'],$candidatecek['candidate_bankingsubdepartment'],$candidatecek['candidate_multiplelocation'],$candidatecek['candidate_multiplelocationnames'],$candidatecek['candidate_prefferedlocation'],$candidatecek['candidate_gender'],$candidatecek['candidate_totalworkexperience'],$candidatecek['candidate_annualsalary'],$candidatecek['candidate_emailidofficial'],$candidatecek['candidate_deeshamail'],$candidatecek['candidate_websitesource'],$candidatecek['candidate_telno2'],$candidatecek['candidate_wpno'],$candidatecek['candidate_wpno2'],$candidatecek['candidate_noticeperiod'],$candidatecek['candidate_highesteducationlevel'],$candidatecek['candidate_highesteducationstream'],$candidatecek['candidate_highesteducationinsitute'],$candidatecek['candidate_yearofpassing'],$candidatecek['candidate_highesteducationcoursetype'],$candidatecek['candidate_createdate'],$candidatecek['candidate_lastmodifieddate'],$candidatecek['candidate_lastactivedatex'],$candidatecek['candidate_note'],$candidatecek['candidate_summarydescription'],$candidatecek['candidate_experiencepershine'],$candidatecek['candidate_lastjob'],$candidatecek['candidate_lasttolastjob'],$candidatecek['candidate_graducationcourse'],$candidatecek['candidate_graduationcollege'],$candidatecek['candidate_skills'],$candidatecek['candidate_mayalsoknow'],$candidatecek['candidate_tiercity'],$candidatecek['candidate_loanproduct'],$candidatecek['candidate_loansubproduct'],$candidatecek['candidate_internalsource'],$candidatecek['candidate_sourcetype'],$candidatecek['candidate_externalsource'],$candidatecek['candidate_refferredname'],$candidatecek['candidate_refferredbankname'],$candidatecek['candidate_referredid'],$candidatecek['candidate_dateofentry'],$candidatecek['candidate_deeshaemployeenamerefer'],$candidatecek['candidate_deeshaemployeenameenter'],$candidatecek['candidate_birthday'],$candidatecek['candidate_marriageanniv'],$candidatecek['candidate_lastaccessdate'],$candidatecek['candidate_lastaccessperson'],$candidatecek['candidate_deeshaemployeefeedback'],$candidatecek['candidate_deeshaemployeecomment'],$candidatecek['candidate_currentbossname'],$candidatecek['candidate_exbossname'],$candidatecek['candidate_lastcallbydeeeshaemp'],$candidatecek['candidate_interestingfact'],$candidatecek['candidate_languagesspeak'],$candidatecek['candidate_languageprefer'],$candidatecek['candidate_mothertongue'],$candidatecek['candidate_banker'],$candidatecek['candidate_residenceaddress'],$candidatecek['candidate_companyaddress'],$candidatecek['candidate_country'],$candidatecek['candidate_reportingmanagerno'],$candidatecek['candidate_saturdayworking'],$candidatecek['candidate_associatedeeesha'],$candidatecek['candidate_bankerdeeesha'],$candidatecek['candidate_customerdeeesha'],$candidatecek['candidate_candidatefinploy'],$candidatecek['candidate_companyfinploy'],$candidatecek['candidate_associatefinploy'],$candidatecek['candidate_companyfinterno'],$candidatecek['candidate_internfinterno'],$candidatecek['candidate_associatefinterno'],$candidatecek['candidate_companyfintubhai'],$candidatecek['candidate_customerfintubhai'],$candidatecek['candidate_associatefintubhai'],$candidatecek['candidate_idassociatedeeesha'],$candidatecek['candidate_idbankerdeeesha'],$candidatecek['candidate_idcustomerdeeesha'],$candidatecek['candidate_idcandidatefinploy'],$candidatecek['candidate_idassociatefinploy'],$candidatecek['candidate_idcompanyfinterno'],$candidatecek['candidate_idintern'],$candidatecek['candidate_idassociatefinterno'],$candidatecek['candidate_idcompanyfintubhai'],$candidatecek['candidate_idcustomerfintubhai'],$candidatecek['candidate_idassociatefintubhai'],$candidatecek['candidate_othercity'],$candidatecek['candidate_nameoncertificate'],$candidatecek['candidate_mothername'],$candidatecek['candidate_fathername'],$candidatecek['candidate_fathertelno'],$candidatecek['candidate_mothertelno'],$candidatecek['candidate_registrationsite'],$candidatecek['candidate_interestedinbankingetc'],$candidatecek['candidate_interests'],$candidatecek['candidate_noofpastinternships'],$candidatecek['candidate_pastinternships'],$candidatecek['candidate_durationofinternship'],$candidatecek['candidate_haveyoudonewithdeeesha'],$candidatecek['candidate_areyoulookeducationloan'],$candidatecek['candidate_rolesinpreviousinternship'],$candidatecek['candidate_typeofinternship'],$candidatecek['candidate_joinasafulltimeemployee'],$candidatecek['candidate_internshipprefer'],$candidatecek['candidate_hoursdedicate'],$candidatecek['candidate_personalizedlaptop'],$candidatecek['candidate_stableconnection'],$candidatecek['candidate_typeofinternship2'],$candidatecek['candidate_howdaysworkaweek'],$candidatecek['candidate_desiredincome'],$candidatecek['candidate_havetechnicalknowledge'],$candidatecek['candidate_professortelno'],$candidatecek['linkedin_name'],$candidatecek['linkedin_namepos'],$candidatecek['linkedin_companyname'],$candidatecek['linkedin_cityname'],$candidatecek['linkedin_statename'],$candidatecek['linkedin_namecountry'],$candidatecek['linkedin_currentjob'],$candidatecek['linkedin_secondlastjob'],$candidatecek['linkedin_thirdlastjob'],$candidatecek['linkedin_highesteducation'],$candidatecek['linkedin_secondeducation'],$candidatecek['linkedin_skills'],$candidatecek['linkedin_interests'],$candidatecek['linkedin_accomplishment'],$candidatecek['linkedin_urlfromscrapper']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {
    break;
  }

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['allcandidatesexport']) and $_GET['allcandidatesexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "allcandidates_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;

while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;


  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {

    break;

  }

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['calledcandidatesexport']) and $_GET['calledcandidatesexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "calledcandidates_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_called='1' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;

while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;



  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];


  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {
    
    break;

  }

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['notcalledcandidatesexport']) and $_GET['notcalledcandidatesexport']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "notcalledcandidates_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesec=$db->prepare("SELECT * from candidates where candidate_called='0' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;

while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;


  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);

  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {

    break;

  }

}

// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['alldataexportemployee']) and $_GET['alldataexportemployee']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

$employee_id = $_GET['employee_id'];

$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_yetki='1' and kullanici_id='$employee_id'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_id = $kullanicicek['kullanici_id'];


// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "alltimereport_".$kullanici_id."_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('DATE','Total Number of Calls assigned', 'Total Number of Calls actually made', 'Total Number of Interested candidates', 'Total Number of Not interested', 'Total Number of Calls not connected', '1st round Whatsapp group made / message sent ','2nd round - Total Number called again and finally interested', 'FULLY Interested', 'Send me details I will see', 'Busy right now, call later', 'Wrong Numbe', 'FULLY Not Interested', 'Mobile Switch Off', 'Call Not Answered', 'Out of Network Area', 'Call Rejected' ); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount();


                      $birlesim1 = $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay;

                      $birlesim2 = $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11;

                      $birlesim3 = $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; 


  $lineData = array($buguntarih,$candidateassignedsay,$birlesim1,$birlesim2,$candidatesay4+$candidatesay5,$birlesim3,$candidatesay10,$candidatesay11,$candidatesay,$candidatesay2,$candidatesay3,$candidatesay4,$candidatesay5,$candidatesay6,$candidatesay7,$candidatesay8,$candidatesay9);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['alldataexport']) and $_GET['alldataexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}




// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "alltimereport_". date('Y-m-d') . ".xls"; 


// Column names 
$fields = array('DATE','Total Number of Calls assigned', 'Total Number of Calls actually made', 'Total Number of Interested candidates', 'Total Number of Not interested', 'Total Number of Calls not connected', '1st round Whatsapp group made / message sent ','2nd round - Total Number called again and finally interested', 'FULLY Interested', 'Send me details I will see', 'Busy right now, call later', 'Wrong Numbe', 'FULLY Not Interested', 'Mobile Switch Off', 'Call Not Answered', 'Out of Network Area', 'Call Rejected' ); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount();


                      $birlesim1 = $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay;

                      $birlesim2 = $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11;

                      $birlesim3 = $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; 


  $lineData = array($buguntarih,$candidateassignedsay,$birlesim1,$birlesim2,$candidatesay4+$candidatesay5,$birlesim3,$candidatesay10,$candidatesay11,$candidatesay,$candidatesay2,$candidatesay3,$candidatesay4,$candidatesay5,$candidatesay6,$candidatesay7,$candidatesay8,$candidatesay9);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['specificdataexport']) and $_GET['specificdataexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}


$zaman = $_GET['date'];


// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "report_date_". $zaman . ".xls"; 


// Column names 
$fields = array('Total Number of Calls assigned', 'Total Number of Calls actually made', 'Total Number of Interested candidates', 'Total Number of Not interested', 'Total Number of Calls not connected', '1st round Whatsapp group made / message sent ','2nd round - Total Number called again and finally interested', 'FULLY Interested', 'Send me details I will see', 'Busy right now, call later', 'Wrong Numbe', 'FULLY Not Interested', 'Mobile Switch Off', 'Call Not Answered', 'Out of Network Area', 'Call Rejected' ); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 




  $candidateassignedsec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount();


                      $birlesim1 = $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay;

                      $birlesim2 = $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11;

                      $birlesim3 = $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9;


  $lineData = array($candidateassignedsay,$birlesim1,$birlesim2,$candidatesay4+$candidatesay5,$birlesim3,$candidatesay10,$candidatesay11,$candidatesay,$candidatesay2,$candidatesay3,$candidatesay4,$candidatesay5,$candidatesay6,$candidatesay7,$candidatesay8,$candidatesay9);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['specificdataexportemployee']) and $_GET['specificdataexportemployee']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

$zaman = $_GET['date'];
$employee_id = $_GET['employee_id'];


// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "report_date_". $zaman . ".xls"; 


// Column names 
$fields = array('Total Number of Calls assigned', 'Total Number of Calls actually made', 'Total Number of Interested candidates', 'Total Number of Not interested', 'Total Number of Calls not connected', '1st round Whatsapp group made / message sent ','2nd round - Total Number called again and finally interested', 'FULLY Interested', 'Send me details I will see', 'Busy right now, call later', 'Wrong Numbe', 'FULLY Not Interested', 'Mobile Switch Off', 'Call Not Answered', 'Out of Network Area', 'Call Rejected' ); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 




  $candidateassignedsec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount();


                      $birlesim1 = $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay;

                      $birlesim2 = $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11;

                      $birlesim3 = $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9;


  $lineData = array($candidateassignedsay,$birlesim1,$birlesim2,$candidatesay4+$candidatesay5,$birlesim3,$candidatesay10,$candidatesay11,$candidatesay,$candidatesay2,$candidatesay3,$candidatesay4,$candidatesay5,$candidatesay6,$candidatesay7,$candidatesay8,$candidatesay9);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['allsingledataexport']) and $_GET['allsingledataexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}


$status = $_GET['status'];
$buguntarih = date('Y-m-d');
$seostatus = seo($status);

switch ($status) {

  case 'Total Number of Calls Assigned':
   
$candidatesec = $db->prepare("SELECT * from candidates where candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;

    case 'Total Number of Calls actually made':

$candidatesec = $db->prepare("SELECT * from candidates where candidate_called='1' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Interested candidates':
 
$candidatesec = $db->prepare("SELECT * from candidates where candidate_listed='1' and (candidate_respond='FULLY Interested' or candidate_respond='Send me details I will see' or candidate_respond='1st round Whatsapp group made / message sent' or candidate_respond='2nd round called again check if interested') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Not interested':
  
$candidatesec = $db->prepare("SELECT * from candidates where candidate_listed='1' and (candidate_respond='FULLY Not Interested' or candidate_respond='Wrong Number') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Calls not connected':
  
$candidatesec = $db->prepare("SELECT * from candidates where candidate_listed='1' and (candidate_respond='Busy right now, call later' or candidate_respond='Mobile Switch Off' or candidate_respond='Call Not Answered' or candidate_respond='Out of Network Area' or candidate_respond='Call Rejected') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case '1st round Whatsapp group made / message sent':

$candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case '2nd round - Total Number called again and finally interested':
    
$candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'FULLY Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Send me details I will see':
   
     $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Busy right now, call later':
   
   $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Wrong Number':
   
   $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'FULLY Not Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Mobile Switch Off':
   
   $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Not Answered':
   
   $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Out of Network Area':
    
     $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Rejected':
    
    $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;
  

}




// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "all_".$seostatus."_". $buguntarih . ".xls"; 


// Column names 
 

$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}




$sayi=0;


while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;
  
  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);
  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }


  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

if ($sayi==$indirsayisi) {
 
 break;
 
}


}
                      



  



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['allsingledataexportemployee']) and $_GET['allsingledataexportemployee']=='ok'){

if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}

$employee_id = $_GET['employee_id'];
$status = $_GET['status'];
$buguntarih = date('Y-m-d');
$seostatus = seo($status);

switch ($status) {

  case 'Total Number of Calls Assigned':
   
$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;

    case 'Total Number of Calls actually made':

$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_called='1' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Interested candidates':
 
$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='FULLY Interested' or candidate_respond='Send me details I will see' or candidate_respond='1st round Whatsapp group made / message sent' or candidate_respond='2nd round called again check if interested') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Not interested':
  
$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='FULLY Not Interested' or candidate_respond='Wrong Number') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Calls not connected':
  
$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='Busy right now, call later' or candidate_respond='Mobile Switch Off' or candidate_respond='Call Not Answered' or candidate_respond='Out of Network Area' or candidate_respond='Call Rejected') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case '1st round Whatsapp group made / message sent':

$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case '2nd round - Total Number called again and finally interested':
    
$candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='2nd round called again check if interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'FULLY Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' 
      and candidate_respond='FULLY Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Send me details I will see':
   
     $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Send me details I will see' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Busy right now, call later':
   
   $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Busy right now, call later' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Wrong Number':
   
   $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Wrong Number' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'FULLY Not Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='FULLY Not Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Mobile Switch Off':
   
   $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Mobile Switch Off' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Not Answered':
   
   $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Call Not Answered' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Out of Network Area':
    
     $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Out of Network Area' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Call Rejected':
    
    $candidatesec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_respond='Call Rejected' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;
  

}




// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "all_".$seostatus."_". $buguntarih . ".xls"; 


// Column names 
 

$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT', 'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;


while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;
  
  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);
  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }


  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {
    
    break;

  }

}
                      



  



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['datesingledataexportemployee']) and $_GET['datesingledataexportemployee']=='ok'){

$employee_id = $_GET['employee_id'];

$status = $_GET['status'];
$zaman = $_GET['date'];
$seostatus = seo($status);

switch ($status) {

  case 'Total Number of Calls Assigned':
   
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;

    case 'Total Number of Calls actually made':

$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Interested candidates':
 
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='FULLY Interested' or candidate_respond='Send me details I will see' or candidate_respond='1st round Whatsapp group made / message sent' or candidate_respond='2nd round called again check if interested') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Not interested':
  
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='FULLY Not Interested' or candidate_respond='Wrong Number') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Total Number of Calls not connected':
  
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_listed='1' and (candidate_respond='Busy right now, call later' or candidate_respond='Mobile Switch Off' or candidate_respond='Call Not Answered' or candidate_respond='Out of Network Area' or candidate_respond='Call Rejected') order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case '1st round Whatsapp group made / message sent':

$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case '2nd round - Total Number called again and finally interested':
    
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='2nd round called again check if interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'FULLY Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='FULLY Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Send me details I will see':
   
     $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Send me details I will see' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Busy right now, call later':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Busy right now, call later' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Wrong Number':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Wrong Number' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'FULLY Not Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='FULLY Not Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Mobile Switch Off':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Mobile Switch Off' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Not Answered':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Call Not Answered' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Out of Network Area':
    
     $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Out of Network Area' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Rejected':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and kullanici_id='$employee_id' and candidate_respond='Call Rejected' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;
  

}




// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "all_".$seostatus."_". $zaman . ".xls"; 


// Column names 
 

$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT' ,'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;


while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;
  
  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);
  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }


  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {
    
    break;

  }

}
                      



  



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['datesingledataexport']) and $_GET['datesingledataexport']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}


$status = $_GET['status'];
$zaman = $_GET['date'];
$seostatus = seo($status);

switch ($status) {

  case 'Total Number of Calls Assigned':
   
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_tarihi) = '$zaman' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;

    case 'Total Number of Calls actually made':

$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Total Number of Interested candidates':
 
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_listed='1' and (candidate_respond='FULLY Interested' or candidate_respond='Send me details I will see' or candidate_respond='1st round Whatsapp group made / message sent' or candidate_respond='2nd round called again check if interested') order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Total Number of Not interested':
  
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_listed='1' and (candidate_respond='FULLY Not Interested' or candidate_respond='Wrong Number') order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Total Number of Calls not connected':
  
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_listed='1' and (candidate_respond='Busy right now, call later' or candidate_respond='Mobile Switch Off' or candidate_respond='Call Not Answered' or candidate_respond='Out of Network Area' or candidate_respond='Call Rejected') order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case '1st round Whatsapp group made / message sent':

$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();



    break;


    case '2nd round - Total Number called again and finally interested':
    
$candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='2nd round called again check if interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();



    break;


    case 'FULLY Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='FULLY Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Send me details I will see':
   
     $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Send me details I will see' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Busy right now, call later':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Busy right now, call later' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Wrong Number':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Wrong Number' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'FULLY Not Interested':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='FULLY Not Interested' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Mobile Switch Off':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Mobile Switch Off' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Call Not Answered':
   
   $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Call Not Answered' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;


    case 'Out of Network Area':
    
     $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Out of Network Area' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();

    break;


    case 'Call Rejected':
    
    $candidatesec = $db->prepare("SELECT * from candidates where DATE(candidate_markdate) = '$zaman' and candidate_respond='Call Rejected' and candidate_listed='1' order by candidate_tarihi DESC");
$candidatesec->execute();


    break;
  

}




// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "date_".$zaman."_".$seostatus.".xls"; 


// Column names 
$fields = array('ID', 'DATE CREATED', 'CALLING PERSON', 'NAME', 'PHONE', 'LINKEDIN', 'STATUS', 'INTERESTED TO' , 'JOB CHANGE', 'COMPANY', 'DESIGNATION','PINCODE','LOCATION', 'MAIL', 'PRODUCT', 'DEPARTMENT' ,'SALARY', 'EXPERIENCE','RESPONSE', 'REMARK'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 

$candidatesay=$candidatesec->rowCount();

if (isset($_SESSION['subadminoturump'])) {


$kalan_goruntuleme = $kullanici_profileviewlimit-$kullanici_todayprofileview;

  $dt = new DateTime($kullanici_lastprofileview);
$dtt=$dt->format('Y-m-d');

$tarih = date('Y-m-d');

if ($tarih==$dtt) {
  
 if ($kalan_goruntuleme==0) {
    
    echo "You have reached your daily profile view limit.";exit;

  } else {


 if ($candidatesay>=$kalan_goruntuleme) {
  

  $hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kalan_goruntuleme;


 } else {

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay+$kullanici_todayprofileview

));

$indirsayisi = $candidatesay;
    

  }

 }

} else {

if ($candidatesay>=$kullanici_profileviewlimit) {
 

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $kullanici_profileviewlimit

));

$indirsayisi = $kullanici_profileviewlimit;


} else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastprofileview=:kullanici_lastprofileview,
kullanici_todayprofileview=:kullanici_todayprofileview

where kullanici_id='$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastprofileview" => date('Y-m-d H:i:s'),
"kullanici_todayprofileview" => $candidatesay

));

$indirsayisi = $candidatesay;


}



}





} else {

$indirsayisi = $candidatesay;

}


$sayi=0;


while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) { $sayi++;
  
  $kullanici_id=$candidatecek['kullanici_id'];
  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id'");
  $kullanicisec->execute();
  $kullanicicek = $kullanicisec->fetch(PDO::FETCH_ASSOC);
  $candidate_called = $candidatecek['candidate_called'];
  $candidate_salary = $candidatecek['salary_monthlyannually']." ".$candidatecek['salary_amount']." ".$candidatecek['salary_measure'];

  if ($candidate_called=='1') {

    $status = 'CALLED';

  } else {

    $status = 'NOT CALLED';
  }


  $calling_person = $kullanicicek['kullanici_ad']." ".$kullanicicek['kullanici_soyad'];

  $kayit_tarihi = $candidatecek['candidate_tarihi'];

  $date = substr($kayit_tarihi, 0,10);

  $lineData = array($candidatecek['candidate_id'],$date,$calling_person,$candidatecek['candidate_adsoyad'],$candidatecek['candidate_telno'],$candidatecek['candidate_linkedin'],$status,$candidatecek['candidate_interestedto'],$candidatecek['candidate_jobchange'],$candidatecek['candidate_company'],$candidatecek['candidate_designation'],$candidatecek['candidate_pincode'],$candidatecek['candidate_location'],$candidatecek['candidate_mail'],$candidatecek['candidate_product'],$candidatecek['candidate_department'],$candidate_salary,$candidatecek['candidate_experience'],$candidatecek['candidate_respond'],$candidatecek['candidate_remark']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

  if ($sayi==$indirsayisi) {
    
    break;

  }

}
                      



  



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_GET['calllogsdownload']) and $_GET['calllogsdownload']=='ok'){

  if (isset($_SESSION['subadminoturump'])) {
   
  $subadmin_id = $adminsessioncek['kullanici_id'];

  $thismonth = date('Y-m');
  $today = date('Y-m-d');
  $tamtarih = date('Y-m-d H:i:s');

  $dt = new DateTime($kullanici_lastdownload);

  $lastdownloadmonth = $dt->format('Y-m');
  $lastdownloadday = $dt->format('Y-m-d');



  if (($thismonth==$lastdownloadmonth) and ($kullanici_monthlydownloadlimit<$kullanici_thismonthdownload+1)) {
  
  echo "You have reached this month download limit. Will be renewed on the 1st of next month."; exit;

} else if (($today==$lastdownloadday) and ($kullanici_dailydownloadlimit<$kullanici_todaydownload+1)){


echo "You have reached daily download limit. Will be renewed next day."; exit;

}

//Ulaşılmamışsa devam.




  if ($thismonth!=$lastdownloadmonth) {
    
$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload,
kullanici_todaydownload=:kullanici_todaydownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_thismonthdownload" => 1,
"kullanici_todaydownload" => 1

));

  } else if ($today!=$lastdownloadday){

$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => 1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  } else {


$hazirla=$db->prepare("UPDATE kullanici set

kullanici_lastdownload=:kullanici_lastdownload,
kullanici_todaydownload=:kullanici_todaydownload,
kullanici_thismonthdownload=:kullanici_thismonthdownload

where kullanici_id = '$subadmin_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_lastdownload" => $tamtarih,
"kullanici_todaydownload" => $kullanici_todaydownload+1,
"kullanici_thismonthdownload" => $kullanici_thismonthdownload+1

));

  }






}


$candidate_id = $_GET['candidate_id'];
$candidatesec = $db->prepare("SELECT * from candidates where candidate_id='$candidate_id' and candidate_listed='1'");
$candidatesec->execute();

$candidatecek = $candidatesec->fetch(PDO::FETCH_ASSOC);

$kullanici_id = $candidatecek['kullanici_id'];

$kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_id='$kullanici_id' and kullanici_yetki='1'");
$kullanicisec->execute();
$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

$kullanici_adsoyad = $kullanicicek['kullanici_adsoyad'];
$candidate_adsoyad = $candidatecek['candidate_adsoyad'];


$calllogssec=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_id' order by call_time DESC");
$calllogssec->execute();
$calllogssay=$calllogssec->rowCount();
$i=$calllogssay+1;



// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "calllogsdata_".$candidate_id.".xls"; 


// Column names 
$fields = array('CALLING PERSON', 'CANDIDATE','ORDER of CALL', 'TIME', 'RESPONSE', 'REMARK', 'CALLED BY'); 


// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 


while ($calllogscek=$calllogssec->fetch(PDO::FETCH_ASSOC)) { $i--;
  
   if (strlen($calllogscek['call_remark'])==0) {

    $call_remark = "N/A";

                          } else {

    $call_remark = $calllogscek['call_remark'];

                          } 

  $lineData = array($kullanici_adsoyad, $candidate_adsoyad, $i, $calllogscek['call_time'], $calllogscek['call_response'], $call_remark, $calllogscek['caller']);

  array_walk($lineData, 'filterData'); 
  $excelData .= implode("\t", array_values($lineData)) . "\n"; 

}
                      



  



// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;

 } else if (isset($_POST['deactiveemployee'])){


$kullanici_id = $_POST['kullanici_id'];

$hazirla = $db->prepare("UPDATE kullanici set

kullanici_aktif=:kullanici_aktif

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_aktif" => 'inactive'

));


if ($derle) {
  
  echo "ok";

}


 } else if (isset($_POST['activeemployee'])){


$kullanici_id = $_POST['kullanici_id'];

$hazirla = $db->prepare("UPDATE kullanici set

kullanici_aktif=:kullanici_aktif

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"kullanici_aktif" => 'active'

));


if ($derle) {
  
  echo "ok";

}


 } else if (isset($_POST['applyadminrights'])){

$kullanici_id = $_POST['kullanici_id'];
$right_1 = $_POST['right_1'];
$right_2 = $_POST['right_2'];
$right_3 = $_POST['right_3'];
$right_4 = $_POST['right_4'];
$right_5 = $_POST['right_5'];
$right_6 = $_POST['right_6'];
$right_7 = $_POST['right_7'];
$right_8 = $_POST['right_8'];
$right_9 = $_POST['right_9'];
$right_10 = $_POST['right_10'];

$hazirla = $db->prepare("UPDATE kullanici set

right_1=:right_1,
right_2=:right_2,
right_3=:right_3,
right_4=:right_4,
right_5=:right_5,
right_6=:right_6,
right_7=:right_7,
right_8=:right_8,
right_9=:right_9,
right_10=:right_10

where kullanici_id='$kullanici_id'

  ");


$derle = $hazirla->execute(array(

"right_1" => $right_1,
"right_2" => $right_2,
"right_3" => $right_3,
"right_4" => $right_4,
"right_5" => $right_5,
"right_6" => $right_6,
"right_7" => $right_7,
"right_8" => $right_8,
"right_9" => $right_9,
"right_10" => $right_10

));


if ($derle) {

echo "ok";

}


 } else if (isset($_POST['editdumbcandidateadmin'])){



$candidate_id = $_POST['candidate_id'];
$candidate_ad = trim($_POST['candidate_ad']);
$candidate_soyad = trim($_POST['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_telno = trim($_POST['candidate_telno']);
$candidate_company = trim($_POST['candidate_company']);
$candidate_designation = trim($_POST['candidate_designation']);
$candidate_pincode = trim($_POST['candidate_pincode']);
$candidate_location = trim($_POST['candidate_location']);
$candidate_linkedin = trim($_POST['candidate_linkedin']);
$candidate_mail = trim($_POST['candidate_mail']);
$candidate_referredby = trim($_POST['candidate_referredby']);

if (!empty($_POST['candidate_product'])) {
  $candidate_product = trim($_POST['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($_POST['candidate_department'])) {
  $candidate_department = trim($_POST['candidate_department']);
} else {

  $candidate_department = NULL;
};



if (strlen($candidate_referredby)>0) {
 
 // Aynı mı değişmiş mi soruyoruz.

$aynimisor=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$aynimisor->execute();
$aynimicek=$aynimisor->fetch(PDO::FETCH_ASSOC);
$aynimi_id = $aynimicek['referrer_id'];

$aynimisec=$db->prepare("SELECT * from candidates where candidate_id='$aynimi_id'");
$aynimisec->execute();
$aynimicek2=$aynimisec->fetch(PDO::FETCH_ASSOC);


if ($candidate_referredby!=$aynimicek2['candidate_telno']) {
  
//Aynı değilse yeni bir aksiyon demektir. Aynıysa değişme yok.

$refercandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_referredby' and candidate_clean='yes'");
$refercandidatesec->execute();

$refercandidatesay = $refercandidatesec->rowCount();

if ($refercandidatesay==0) {
  
  echo "refernotexistphone";exit;

} else { 


// Input dolu geldi demektir. Eğer input önceden de doluysa farklı bir veri gelmiştir, önceden boşsa referrer her türlü 'yes' olacak.

$referkontrolsec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$referkontrolsec->execute();
$referkontrolsay=$referkontrolsec->rowCount();
$refercandidatecek=$refercandidatesec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $refercandidatecek['candidate_id'];

if ($referkontrolsay==0) { //Boşsa

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));

 //Yeni referrer numarasına sen artık referrer'sın diyoruz.

 $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_telno='$candidate_referredby' and candidate_listed='1'

  ");


 $derlex = $hazirlax->execute(array(

"candidate_referrer" => 'yes'

 ));
  


} else { //Zaten dolu ama farklı numaraysa.



  //Yeni referrer numarasına sen artık referrer'sın diyoruz.

 $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_telno='$candidate_referredby' and candidate_clean='yes'

  ");


 $derlex = $hazirlax->execute(array(

"candidate_referrer" => 'yes'

 ));


$referchainsil=$db->prepare("DELETE from referchain where referred_id='$candidate_id'");
$referchainsil->execute();

$hazirla=$db->prepare("INSERT into referchain set

referrer_id=:referrer_id,
referred_id=:referred_id


  ");


 $derle = $hazirla->execute(array(

"referrer_id" => $referrer_id,
"referred_id" => $candidate_id

 ));


 //Yeni refer'in status'u yes yapıldı. eski chain silindi. Eski numaranın refer ettiği hala var mı diye soruyoruz. Kalmadıysa status 'no' çekiyoruz.



 $sec2=$db->prepare("SELECT * from referchain where referrer_id='$aynimi_id'");
$sec2->execute();
$say2=$sec2->rowCount();

if ($say2==0) {
  
  $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$aynimi_id'

    ");


  $derlex=$hazirlax->execute(array(

"candidate_referrer" => 'no'

  ));

}


}



}

}


} else {

  //GÖNDERİLEN INPUT BOŞSA ----------------

  $sec=$db->prepare("SELECT * from referchain where referred_id='$candidate_id'");
$sec->execute();
$cek=$sec->fetch(PDO::FETCH_ASSOC);
$referrer_id = $cek['referrer_id'];


$referchainsil=$db->prepare("DELETE from referchain where referred_id='$candidate_id'");
$referchainsil->execute();


//Eski refer'in referliği kalmamışsa status'u no'ya çevirioruz. Hala refer olduğu kişiler varsa dokunmuyoruz.

if (strlen($referrer_id)>0) { //Zaten önceden de boşsa işlemi yapmaya gerek yok.


$sec2=$db->prepare("SELECT * from referchain where referrer_id='$referrer_id'");
$sec2->execute();
$say2=$sec2->rowCount();

if ($say2==0) {
  
  $hazirlax=$db->prepare("UPDATE candidates set

candidate_referrer=:candidate_referrer

where candidate_id='$referrer_id'

    ");


  $derlex=$hazirlax->execute(array(

"candidate_referrer" => 'no'

  ));

}

}

//GÖNDERİLEN INPUT BOŞSA --------------


}


//Dump Datas ---------------------


$candidate_birthdate = trim($_POST['candidate_birthdate']);
$candidate_industry = trim($_POST['candidate_industry']);
$candidate_currentjobexperience = trim($_POST['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($_POST['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($_POST['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($_POST['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($_POST['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($_POST['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($_POST['candidate_prefferedlocation']);
$candidate_gender = trim($_POST['candidate_gender']);
$candidate_totalworkexperience = trim($_POST['candidate_totalworkexperience']);
$candidate_annualsalary = trim($_POST['candidate_annualsalary']);
$candidate_deeshamail = trim($_POST['candidate_deeshamail']);
$candidate_websitesource = trim($_POST['candidate_websitesource']);
$candidate_telno2 = trim($_POST['candidate_telno2']);
$candidate_wpno = trim($_POST['candidate_wpno']);
$candidate_wpno2 = trim($_POST['candidate_wpno2']);
$candidate_noticeperiod = trim($_POST['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($_POST['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($_POST['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($_POST['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($_POST['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($_POST['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($_POST['candidate_createdate']);
$candidate_lastmodifieddate = trim($_POST['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($_POST['candidate_lastactivedate']);
$candidate_note = trim($_POST['candidate_note']);
$candidate_summarydescription = trim($_POST['candidate_summarydescription']);
$candidate_experiencepershine = trim($_POST['candidate_experiencepershine']);
$candidate_lastjob = trim($_POST['candidate_lastjob']);
$candidate_lasttolastjob = trim($_POST['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($_POST['candidate_graducationcourse']);
$candidate_graduationcollege = trim($_POST['candidate_graduationcollege']);
$candidate_skills = trim($_POST['candidate_skills']);
$candidate_mayalsoknow = trim($_POST['candidate_mayalsoknow']);
$candidate_tiercity = trim($_POST['candidate_tiercity']);
$candidate_loanproduct = trim($_POST['candidate_loanproduct']);
$candidate_loansubproduct = trim($_POST['candidate_loansubproduct']);
$candidate_internalsource = trim($_POST['candidate_internalsource']);
$candidate_sourcetype = trim($_POST['candidate_sourcetype']);
$candidate_externalsource = trim($_POST['candidate_externalsource']);
$candidate_refferredname = trim($_POST['candidate_refferredname']);
$candidate_refferredbankname = trim($_POST['candidate_refferredbankname']);
$candidate_referredid = trim($_POST['candidate_referredid']);
$candidate_dateofentry = trim($_POST['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($_POST['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($_POST['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($_POST['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($_POST['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($_POST['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($_POST['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($_POST['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($_POST['candidate_currentbossname']);
$candidate_exbossname = trim($_POST['candidate_exbossname']);
$candidate_interestingfact = trim($_POST['candidate_interestingfact']);
$candidate_languagesspeak = trim($_POST['candidate_languagesspeak']);
$candidate_languageprefer = trim($_POST['candidate_languageprefer']);
$candidate_mothertongue = trim($_POST['candidate_mothertongue']);
$candidate_banker = trim($_POST['candidate_banker']);
$candidate_residenceaddress = trim($_POST['candidate_residenceaddress']);
$candidate_companyaddress = trim($_POST['candidate_companyaddress']);
$candidate_country = trim($_POST['candidate_country']);
$candidate_reportingmanagerno = trim($_POST['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($_POST['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($_POST['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($_POST['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($_POST['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($_POST['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($_POST['candidate_companyfinploy']);
$candidate_associatefinploy = trim($_POST['candidate_associatefinploy']);
$candidate_companyfinterno = trim($_POST['candidate_companyfinterno']);
$candidate_internfinterno = trim($_POST['candidate_internfinterno']);
$candidate_associatefinterno = trim($_POST['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($_POST['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($_POST['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($_POST['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($_POST['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($_POST['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($_POST['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($_POST['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($_POST['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($_POST['candidate_idcompanyfinterno']);
$candidate_idintern = trim($_POST['candidate_idintern']);
$candidate_idassociatefinterno = trim($_POST['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($_POST['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($_POST['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($_POST['candidate_idassociatefintubhai']);
$candidate_othercity = trim($_POST['candidate_othercity']);
$candidate_nameoncertificate = trim($_POST['candidate_nameoncertificate']);
$candidate_mothername = trim($_POST['candidate_mothername']);
$candidate_fathername = trim($_POST['candidate_fathername']);
$candidate_fathertelno = trim($_POST['candidate_fathertelno']);
$candidate_mothertelno = trim($_POST['candidate_mothertelno']);
$candidate_registrationsite = trim($_POST['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($_POST['candidate_interestedinbankingetc']);
$candidate_interests = trim($_POST['candidate_interests']);
$candidate_noofpastinternships = trim($_POST['candidate_noofpastinternships']);
$candidate_pastinternships = trim($_POST['candidate_pastinternships']);
$candidate_durationofinternship = trim($_POST['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($_POST['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($_POST['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($_POST['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($_POST['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($_POST['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($_POST['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($_POST['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($_POST['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($_POST['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($_POST['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($_POST['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($_POST['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($_POST['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($_POST['candidate_professortelno']);
$linkedin_name = trim($_POST['linkedin_name']);
$linkedin_namepos = trim($_POST['linkedin_namepos']);
$linkedin_companyname = trim($_POST['linkedin_companyname']);
$linkedin_cityname = trim($_POST['linkedin_cityname']);
$linkedin_statename = trim($_POST['linkedin_statename']);
$linkedin_namecountry = trim($_POST['linkedin_namecountry']);
$linkedin_currentjob = trim($_POST['linkedin_currentjob']);
$linkedin_secondlastjob = trim($_POST['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($_POST['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($_POST['linkedin_highesteducation']);
$linkedin_secondeducation = trim($_POST['linkedin_secondeducation']);
$linkedin_skills = trim($_POST['linkedin_skills']);
$linkedin_interests = trim($_POST['linkedin_interests']);
$linkedin_accomplishment = trim($_POST['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($_POST['linkedin_urlfromscrapper']);
$candidate_firstname = trim($_POST['candidate_firstname']);
$candidate_middlename = trim($_POST['candidate_middlename']);
$candidate_lastname = trim($_POST['candidate_lastname']);
$candidate_employeemail = trim($_POST['candidate_employeemail']);
$candidate_birthday = trim($_POST['candidate_birthday']);
$candidate_emailidofficial = trim($_POST['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($_POST['candidate_lastcallbydeeeshaemp']);




$hazirla = $db->prepare("UPDATE candidates set

  candidate_ad=:candidate_ad,
  candidate_soyad=:candidate_soyad,
  candidate_adsoyad=:candidate_adsoyad,
  candidate_telno=:candidate_telno,
  candidate_company=:candidate_company,
  candidate_designation=:candidate_designation,
  candidate_pincode=:candidate_pincode,
  candidate_location=:candidate_location,
  candidate_linkedin=:candidate_linkedin,
  candidate_mail=:candidate_mail,
  candidate_product=:candidate_product,
  candidate_department=:candidate_department,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp




where candidate_id='$candidate_id'

  ");


$derle = $hazirla->execute(array(

"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_telno" => $candidate_telno,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_linkedin" => $candidate_linkedin,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp

));

if ($derle) {
  echo "ok";
}

 } else if (isset($_POST['candidateaddlist'])){

$candidate_id = $_POST['candidate_id'];
$kullanici_id = $_POST['kullanici_id'];


$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

$candidate_telno = $candidatecek['candidate_telno'];

$candidatesor = $db->prepare("SELECT * from candidates where candidate_listed='1' and candidate_telno='$candidate_telno'");
$candidatesor->execute();
$existcandidatesay = $candidatesor->rowCount();

if ($existcandidatesay>0) {
 
 echo "exist";

} else {

$hazirla=$db->prepare("UPDATE candidates set

candidate_listed=:candidate_listed,
kullanici_id=:kullanici_id

where candidate_id='$candidate_id'

  ");


$derle = $hazirla->execute(array(

"candidate_listed" => 1,
"kullanici_id" => $kullanici_id

));


if ($derle) {

echo "ok"; 

}

}






 } else if (isset($_POST['addandoverruledata'])){

$candidate_id = $_POST['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

$candidate_telno = $candidatecek['candidate_telno'];

$aynicandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_telno' and candidate_listed='1'");
$aynicandidatesec->execute();
$aynicandidatecek=$aynicandidatesec->fetch(PDO::FETCH_ASSOC);

$aynicandidate_id = $aynicandidatecek['candidate_id'];

// Tüm updateler

$candidate_ad = trim($candidatecek['candidate_ad']);
$candidate_soyad = trim($candidatecek['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_company = trim($candidatecek['candidate_company']);
$candidate_designation = trim($candidatecek['candidate_designation']);
$candidate_pincode = trim($candidatecek['candidate_pincode']);
$candidate_location = trim($candidatecek['candidate_location']);
$candidate_linkedin = trim($candidatecek['candidate_linkedin']);
$candidate_mail = trim($candidatecek['candidate_mail']);

if (!empty($candidatecek['candidate_product'])) {
  $candidate_product = trim($candidatecek['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($candidatecek['candidate_department'])) {
  $candidate_department = trim($candidatecek['candidate_department']);
} else {

  $candidate_department = NULL;
}


//Dump Datas ---------------------


$candidate_birthdate = trim($candidatecek['candidate_birthdate']);
$candidate_industry = trim($candidatecek['candidate_industry']);
$candidate_currentjobexperience = trim($candidatecek['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($candidatecek['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($candidatecek['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($candidatecek['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($candidatecek['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($candidatecek['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($candidatecek['candidate_prefferedlocation']);
$candidate_gender = trim($candidatecek['candidate_gender']);
$candidate_totalworkexperience = trim($candidatecek['candidate_totalworkexperience']);
$candidate_annualsalary = trim($candidatecek['candidate_annualsalary']);
$candidate_deeshamail = trim($candidatecek['candidate_deeshamail']);
$candidate_websitesource = trim($candidatecek['candidate_websitesource']);
$candidate_telno2 = trim($candidatecek['candidate_telno2']);
$candidate_wpno = trim($candidatecek['candidate_wpno']);
$candidate_wpno2 = trim($candidatecek['candidate_wpno2']);
$candidate_noticeperiod = trim($candidatecek['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($candidatecek['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($candidatecek['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($candidatecek['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($candidatecek['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($candidatecek['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($candidatecek['candidate_createdate']);
$candidate_lastmodifieddate = trim($candidatecek['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($candidatecek['candidate_lastactivedate']);
$candidate_note = trim($candidatecek['candidate_note']);
$candidate_summarydescription = trim($candidatecek['candidate_summarydescription']);
$candidate_experiencepershine = trim($candidatecek['candidate_experiencepershine']);
$candidate_lastjob = trim($candidatecek['candidate_lastjob']);
$candidate_lasttolastjob = trim($candidatecek['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($candidatecek['candidate_graducationcourse']);
$candidate_graduationcollege = trim($candidatecek['candidate_graduationcollege']);
$candidate_skills = trim($candidatecek['candidate_skills']);
$candidate_mayalsoknow = trim($candidatecek['candidate_mayalsoknow']);
$candidate_tiercity = trim($candidatecek['candidate_tiercity']);
$candidate_loanproduct = trim($candidatecek['candidate_loanproduct']);
$candidate_loansubproduct = trim($candidatecek['candidate_loansubproduct']);
$candidate_internalsource = trim($candidatecek['candidate_internalsource']);
$candidate_sourcetype = trim($candidatecek['candidate_sourcetype']);
$candidate_externalsource = trim($candidatecek['candidate_externalsource']);
$candidate_refferredname = trim($candidatecek['candidate_refferredname']);
$candidate_refferredbankname = trim($candidatecek['candidate_refferredbankname']);
$candidate_referredid = trim($candidatecek['candidate_referredid']);
$candidate_dateofentry = trim($candidatecek['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($candidatecek['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($candidatecek['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($candidatecek['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($candidatecek['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($candidatecek['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($candidatecek['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($candidatecek['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($candidatecek['candidate_currentbossname']);
$candidate_exbossname = trim($candidatecek['candidate_exbossname']);
$candidate_interestingfact = trim($candidatecek['candidate_interestingfact']);
$candidate_languagesspeak = trim($candidatecek['candidate_languagesspeak']);
$candidate_languageprefer = trim($candidatecek['candidate_languageprefer']);
$candidate_mothertongue = trim($candidatecek['candidate_mothertongue']);
$candidate_banker = trim($candidatecek['candidate_banker']);
$candidate_residenceaddress = trim($candidatecek['candidate_residenceaddress']);
$candidate_companyaddress = trim($candidatecek['candidate_companyaddress']);
$candidate_country = trim($candidatecek['candidate_country']);
$candidate_reportingmanagerno = trim($candidatecek['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($candidatecek['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($candidatecek['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($candidatecek['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($candidatecek['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($candidatecek['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($candidatecek['candidate_companyfinploy']);
$candidate_associatefinploy = trim($candidatecek['candidate_associatefinploy']);
$candidate_companyfinterno = trim($candidatecek['candidate_companyfinterno']);
$candidate_internfinterno = trim($candidatecek['candidate_internfinterno']);
$candidate_associatefinterno = trim($candidatecek['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($candidatecek['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($candidatecek['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($candidatecek['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($candidatecek['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($candidatecek['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($candidatecek['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($candidatecek['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($candidatecek['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($candidatecek['candidate_idcompanyfinterno']);
$candidate_idintern = trim($candidatecek['candidate_idintern']);
$candidate_idassociatefinterno = trim($candidatecek['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($candidatecek['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($candidatecek['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($candidatecek['candidate_idassociatefintubhai']);
$candidate_othercity = trim($candidatecek['candidate_othercity']);
$candidate_nameoncertificate = trim($candidatecek['candidate_nameoncertificate']);
$candidate_mothername = trim($candidatecek['candidate_mothername']);
$candidate_fathername = trim($candidatecek['candidate_fathername']);
$candidate_fathertelno = trim($candidatecek['candidate_fathertelno']);
$candidate_mothertelno = trim($candidatecek['candidate_mothertelno']);
$candidate_registrationsite = trim($candidatecek['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($candidatecek['candidate_interestedinbankingetc']);
$candidate_interests = trim($candidatecek['candidate_interests']);
$candidate_noofpastinternships = trim($candidatecek['candidate_noofpastinternships']);
$candidate_pastinternships = trim($candidatecek['candidate_pastinternships']);
$candidate_durationofinternship = trim($candidatecek['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($candidatecek['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($candidatecek['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($candidatecek['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($candidatecek['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($candidatecek['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($candidatecek['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($candidatecek['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($candidatecek['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($candidatecek['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($candidatecek['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($candidatecek['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($candidatecek['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($candidatecek['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($candidatecek['candidate_professortelno']);
$linkedin_name = trim($candidatecek['linkedin_name']);
$linkedin_namepos = trim($candidatecek['linkedin_namepos']);
$linkedin_companyname = trim($candidatecek['linkedin_companyname']);
$linkedin_cityname = trim($candidatecek['linkedin_cityname']);
$linkedin_statename = trim($candidatecek['linkedin_statename']);
$linkedin_namecountry = trim($candidatecek['linkedin_namecountry']);
$linkedin_currentjob = trim($candidatecek['linkedin_currentjob']);
$linkedin_secondlastjob = trim($candidatecek['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($candidatecek['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($candidatecek['linkedin_highesteducation']);
$linkedin_secondeducation = trim($candidatecek['linkedin_secondeducation']);
$linkedin_skills = trim($candidatecek['linkedin_skills']);
$linkedin_interests = trim($candidatecek['linkedin_interests']);
$linkedin_accomplishment = trim($candidatecek['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($candidatecek['linkedin_urlfromscrapper']);
$candidate_firstname = trim($candidatecek['candidate_firstname']);
$candidate_middlename = trim($candidatecek['candidate_middlename']);
$candidate_lastname = trim($candidatecek['candidate_lastname']);
$candidate_employeemail = trim($candidatecek['candidate_employeemail']);
$candidate_birthday = trim($candidatecek['candidate_birthday']);
$candidate_emailidofficial = trim($candidatecek['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($candidatecek['candidate_lastcallbydeeeshaemp']);

// Tüm updateler

$hazirla=$db->prepare("UPDATE candidates set

candidate_ad=:candidate_ad,
  candidate_soyad=:candidate_soyad,
  candidate_adsoyad=:candidate_adsoyad,
  candidate_telno=:candidate_telno,
  candidate_company=:candidate_company,
  candidate_designation=:candidate_designation,
  candidate_pincode=:candidate_pincode,
  candidate_location=:candidate_location,
  candidate_linkedin=:candidate_linkedin,
  candidate_mail=:candidate_mail,
  candidate_product=:candidate_product,
  candidate_department=:candidate_department,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp

where candidate_id='$aynicandidate_id'

  ");



$derle = $hazirla->execute(array(



"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_telno" => $candidate_telno,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_linkedin" => $candidate_linkedin,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp


));


if ($derle) {

 
  
  echo "ok";

}

 } else if (isset($_POST['overruleexistcandidate'])){

$candidate_id = $_POST['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

$candidate_telno = $candidatecek['candidate_telno'];

$aynicandidatesec=$db->prepare("SELECT * from candidates where candidate_telno='$candidate_telno' and candidate_listed='1'");
$aynicandidatesec->execute();
$aynicandidatecek=$aynicandidatesec->fetch(PDO::FETCH_ASSOC);

$aynicandidate_id = $aynicandidatecek['candidate_id'];

// Tüm updateler

$candidate_ad = trim($candidatecek['candidate_ad']);
$candidate_soyad = trim($candidatecek['candidate_soyad']);
$candidate_adsoyad = $candidate_ad." ".$candidate_soyad;
$candidate_company = trim($candidatecek['candidate_company']);
$candidate_designation = trim($candidatecek['candidate_designation']);
$candidate_pincode = trim($candidatecek['candidate_pincode']);
$candidate_location = trim($candidatecek['candidate_location']);
$candidate_linkedin = trim($candidatecek['candidate_linkedin']);
$candidate_mail = trim($candidatecek['candidate_mail']);

if (!empty($candidatecek['candidate_product'])) {
  $candidate_product = trim($candidatecek['candidate_product']);
} else {

  $candidate_product = NULL;
}

if (!empty($candidatecek['candidate_department'])) {
  $candidate_department = trim($candidatecek['candidate_department']);
} else {

  $candidate_department = NULL;
}


//Dump Datas ---------------------


$candidate_birthdate = trim($candidatecek['candidate_birthdate']);
$candidate_industry = trim($candidatecek['candidate_industry']);
$candidate_currentjobexperience = trim($candidatecek['candidate_currentjobexperience']);
$candidate_currentfunctionalarea = trim($candidatecek['candidate_currentfunctionalarea']);
$candidate_bankingdepartment = trim($candidatecek['candidate_bankingdepartment']);
$candidate_bankingsubdepartment = trim($candidatecek['candidate_bankingsubdepartment']);
$candidate_multiplelocation = trim($candidatecek['candidate_multiplelocation']);
$candidate_multiplelocationnames = trim($candidatecek['candidate_multiplelocationnames']);
$candidate_prefferedlocation = trim($candidatecek['candidate_prefferedlocation']);
$candidate_gender = trim($candidatecek['candidate_gender']);
$candidate_totalworkexperience = trim($candidatecek['candidate_totalworkexperience']);
$candidate_annualsalary = trim($candidatecek['candidate_annualsalary']);
$candidate_deeshamail = trim($candidatecek['candidate_deeshamail']);
$candidate_websitesource = trim($candidatecek['candidate_websitesource']);
$candidate_telno2 = trim($candidatecek['candidate_telno2']);
$candidate_wpno = trim($candidatecek['candidate_wpno']);
$candidate_wpno2 = trim($candidatecek['candidate_wpno2']);
$candidate_noticeperiod = trim($candidatecek['candidate_noticeperiod']);
$candidate_highesteducationlevel = trim($candidatecek['candidate_highesteducationlevel']);
$candidate_highesteducationstream = trim($candidatecek['candidate_highesteducationstream']);
$candidate_highesteducationinsitute = trim($candidatecek['candidate_highesteducationinsitute']);
$candidate_yearofpassing = trim($candidatecek['candidate_yearofpassing']);
$candidate_highesteducationcoursetype = trim($candidatecek['candidate_highesteducationcoursetype']);
$candidate_createdate = trim($candidatecek['candidate_createdate']);
$candidate_lastmodifieddate = trim($candidatecek['candidate_lastmodifieddate']);
$candidate_lastactivedate = trim($candidatecek['candidate_lastactivedate']);
$candidate_note = trim($candidatecek['candidate_note']);
$candidate_summarydescription = trim($candidatecek['candidate_summarydescription']);
$candidate_experiencepershine = trim($candidatecek['candidate_experiencepershine']);
$candidate_lastjob = trim($candidatecek['candidate_lastjob']);
$candidate_lasttolastjob = trim($candidatecek['candidate_lasttolastjob']);
$candidate_graducationcourse = trim($candidatecek['candidate_graducationcourse']);
$candidate_graduationcollege = trim($candidatecek['candidate_graduationcollege']);
$candidate_skills = trim($candidatecek['candidate_skills']);
$candidate_mayalsoknow = trim($candidatecek['candidate_mayalsoknow']);
$candidate_tiercity = trim($candidatecek['candidate_tiercity']);
$candidate_loanproduct = trim($candidatecek['candidate_loanproduct']);
$candidate_loansubproduct = trim($candidatecek['candidate_loansubproduct']);
$candidate_internalsource = trim($candidatecek['candidate_internalsource']);
$candidate_sourcetype = trim($candidatecek['candidate_sourcetype']);
$candidate_externalsource = trim($candidatecek['candidate_externalsource']);
$candidate_refferredname = trim($candidatecek['candidate_refferredname']);
$candidate_refferredbankname = trim($candidatecek['candidate_refferredbankname']);
$candidate_referredid = trim($candidatecek['candidate_referredid']);
$candidate_dateofentry = trim($candidatecek['candidate_dateofentry']);
$candidate_deeshaemployeenamerefer = trim($candidatecek['candidate_deeshaemployeenamerefer']);
$candidate_deeshaemployeenameenter = trim($candidatecek['candidate_deeshaemployeenameenter']);
$candidate_marriageanniv = trim($candidatecek['candidate_marriageanniv']);
$candidate_lastaccessdate = trim($candidatecek['candidate_lastaccessdate']);
$candidate_lastaccessperson = trim($candidatecek['candidate_lastaccessperson']);
$candidate_deeshaemployeefeedback = trim($candidatecek['candidate_deeshaemployeefeedback']);
$candidate_deeshaemployeecomment = trim($candidatecek['candidate_deeshaemployeecomment']);
$candidate_currentbossname = trim($candidatecek['candidate_currentbossname']);
$candidate_exbossname = trim($candidatecek['candidate_exbossname']);
$candidate_interestingfact = trim($candidatecek['candidate_interestingfact']);
$candidate_languagesspeak = trim($candidatecek['candidate_languagesspeak']);
$candidate_languageprefer = trim($candidatecek['candidate_languageprefer']);
$candidate_mothertongue = trim($candidatecek['candidate_mothertongue']);
$candidate_banker = trim($candidatecek['candidate_banker']);
$candidate_residenceaddress = trim($candidatecek['candidate_residenceaddress']);
$candidate_companyaddress = trim($candidatecek['candidate_companyaddress']);
$candidate_country = trim($candidatecek['candidate_country']);
$candidate_reportingmanagerno = trim($candidatecek['candidate_reportingmanagerno']);
$candidate_saturdayworking = trim($candidatecek['candidate_saturdayworking']);
$candidate_associatedeeesha = trim($candidatecek['candidate_associatedeeesha']);
$candidate_bankerdeeesha = trim($candidatecek['candidate_bankerdeeesha']);
$candidate_customerdeeesha = trim($candidatecek['candidate_customerdeeesha']);
$candidate_candidatefinploy = trim($candidatecek['candidate_candidatefinploy']);
$candidate_companyfinploy = trim($candidatecek['candidate_companyfinploy']);
$candidate_associatefinploy = trim($candidatecek['candidate_associatefinploy']);
$candidate_companyfinterno = trim($candidatecek['candidate_companyfinterno']);
$candidate_internfinterno = trim($candidatecek['candidate_internfinterno']);
$candidate_associatefinterno = trim($candidatecek['candidate_associatefinterno']);
$candidate_companyfintubhai = trim($candidatecek['candidate_companyfintubhai']);
$candidate_customerfintubhai = trim($candidatecek['candidate_customerfintubhai']);
$candidate_associatefintubhai = trim($candidatecek['candidate_associatefintubhai']);
$candidate_idassociatedeeesha = trim($candidatecek['candidate_idassociatedeeesha']);
$candidate_idbankerdeeesha = trim($candidatecek['candidate_idbankerdeeesha']);
$candidate_idcustomerdeeesha = trim($candidatecek['candidate_idcustomerdeeesha']);
$candidate_idcandidatefinploy = trim($candidatecek['candidate_idcandidatefinploy']);
$candidate_idassociatefinploy = trim($candidatecek['candidate_idassociatefinploy']);
$candidate_idcompanyfinterno = trim($candidatecek['candidate_idcompanyfinterno']);
$candidate_idintern = trim($candidatecek['candidate_idintern']);
$candidate_idassociatefinterno = trim($candidatecek['candidate_idassociatefinterno']);
$candidate_idcompanyfintubhai = trim($candidatecek['candidate_idcompanyfintubhai']);
$candidate_idcustomerfintubhai = trim($candidatecek['candidate_idcustomerfintubhai']);
$candidate_idassociatefintubhai = trim($candidatecek['candidate_idassociatefintubhai']);
$candidate_othercity = trim($candidatecek['candidate_othercity']);
$candidate_nameoncertificate = trim($candidatecek['candidate_nameoncertificate']);
$candidate_mothername = trim($candidatecek['candidate_mothername']);
$candidate_fathername = trim($candidatecek['candidate_fathername']);
$candidate_fathertelno = trim($candidatecek['candidate_fathertelno']);
$candidate_mothertelno = trim($candidatecek['candidate_mothertelno']);
$candidate_registrationsite = trim($candidatecek['candidate_registrationsite']);
$candidate_interestedinbankingetc = trim($candidatecek['candidate_interestedinbankingetc']);
$candidate_interests = trim($candidatecek['candidate_interests']);
$candidate_noofpastinternships = trim($candidatecek['candidate_noofpastinternships']);
$candidate_pastinternships = trim($candidatecek['candidate_pastinternships']);
$candidate_durationofinternship = trim($candidatecek['candidate_durationofinternship']);
$candidate_haveyoudonewithdeeesha = trim($candidatecek['candidate_haveyoudonewithdeeesha']);
$candidate_areyoulookeducationloan = trim($candidatecek['candidate_areyoulookeducationloan']);
$candidate_rolesinpreviousinternship = trim($candidatecek['candidate_rolesinpreviousinternship']);
$candidate_typeofinternship = trim($candidatecek['candidate_typeofinternship']);
$candidate_joinasafulltimeemployee = trim($candidatecek['candidate_joinasafulltimeemployee']);
$candidate_internshipprefer = trim($candidatecek['candidate_internshipprefer']);
$candidate_hoursdedicate = trim($candidatecek['candidate_hoursdedicate']);
$candidate_personalizedlaptop = trim($candidatecek['candidate_personalizedlaptop']);
$candidate_stableconnection = trim($candidatecek['candidate_stableconnection']);
$candidate_typeofinternship2 = trim($candidatecek['candidate_typeofinternship2']);
$candidate_howdaysworkaweek = trim($candidatecek['candidate_howdaysworkaweek']);
$candidate_desiredincome = trim($candidatecek['candidate_desiredincome']);
$candidate_havetechnicalknowledge = trim($candidatecek['candidate_havetechnicalknowledge']);
$candidate_professortelno = trim($candidatecek['candidate_professortelno']);
$linkedin_name = trim($candidatecek['linkedin_name']);
$linkedin_namepos = trim($candidatecek['linkedin_namepos']);
$linkedin_companyname = trim($candidatecek['linkedin_companyname']);
$linkedin_cityname = trim($candidatecek['linkedin_cityname']);
$linkedin_statename = trim($candidatecek['linkedin_statename']);
$linkedin_namecountry = trim($candidatecek['linkedin_namecountry']);
$linkedin_currentjob = trim($candidatecek['linkedin_currentjob']);
$linkedin_secondlastjob = trim($candidatecek['linkedin_secondlastjob']);
$linkedin_thirdlastjob = trim($candidatecek['linkedin_thirdlastjob']);
$linkedin_highesteducation = trim($candidatecek['linkedin_highesteducation']);
$linkedin_secondeducation = trim($candidatecek['linkedin_secondeducation']);
$linkedin_skills = trim($candidatecek['linkedin_skills']);
$linkedin_interests = trim($candidatecek['linkedin_interests']);
$linkedin_accomplishment = trim($candidatecek['linkedin_accomplishment']);
$linkedin_urlfromscrapper = trim($candidatecek['linkedin_urlfromscrapper']);
$candidate_firstname = trim($candidatecek['candidate_firstname']);
$candidate_middlename = trim($candidatecek['candidate_middlename']);
$candidate_lastname = trim($candidatecek['candidate_lastname']);
$candidate_employeemail = trim($candidatecek['candidate_employeemail']);
$candidate_birthday = trim($candidatecek['candidate_birthday']);
$candidate_emailidofficial = trim($candidatecek['candidate_emailidofficial']);
$candidate_lastcallbydeeeshaemp = trim($candidatecek['candidate_lastcallbydeeeshaemp']);

// Tüm updateler

$hazirla=$db->prepare("UPDATE candidates set

candidate_ad=:candidate_ad,
  candidate_soyad=:candidate_soyad,
  candidate_adsoyad=:candidate_adsoyad,
  candidate_telno=:candidate_telno,
  candidate_company=:candidate_company,
  candidate_designation=:candidate_designation,
  candidate_pincode=:candidate_pincode,
  candidate_location=:candidate_location,
  candidate_linkedin=:candidate_linkedin,
  candidate_mail=:candidate_mail,
  candidate_product=:candidate_product,
  candidate_department=:candidate_department,
candidate_birthdate=:candidate_birthdate,
candidate_industry=:candidate_industry,
candidate_currentjobexperience=:candidate_currentjobexperience,
candidate_currentfunctionalarea=:candidate_currentfunctionalarea,
candidate_bankingdepartment=:candidate_bankingdepartment,
candidate_bankingsubdepartment=:candidate_bankingsubdepartment,
candidate_multiplelocation=:candidate_multiplelocation,
candidate_multiplelocationnames=:candidate_multiplelocationnames,
candidate_prefferedlocation=:candidate_prefferedlocation,
candidate_gender=:candidate_gender,
candidate_totalworkexperience=:candidate_totalworkexperience,
candidate_annualsalary=:candidate_annualsalary,
candidate_deeshamail=:candidate_deeshamail,
candidate_websitesource=:candidate_websitesource,
candidate_telno2=:candidate_telno2,
candidate_wpno=:candidate_wpno,
candidate_wpno2=:candidate_wpno2,
candidate_noticeperiod=:candidate_noticeperiod,
candidate_highesteducationlevel=:candidate_highesteducationlevel,
candidate_highesteducationstream=:candidate_highesteducationstream,
candidate_highesteducationinsitute=:candidate_highesteducationinsitute,
candidate_yearofpassing=:candidate_yearofpassing,
candidate_highesteducationcoursetype=:candidate_highesteducationcoursetype,
candidate_createdate=:candidate_createdate,
candidate_lastmodifieddate=:candidate_lastmodifieddate,
candidate_lastactivedate=:candidate_lastactivedate,
candidate_note=:candidate_note,
candidate_summarydescription=:candidate_summarydescription,
candidate_experiencepershine=:candidate_experiencepershine,
candidate_lastjob=:candidate_lastjob,
candidate_lasttolastjob=:candidate_lasttolastjob,
candidate_graducationcourse=:candidate_graducationcourse,
candidate_graduationcollege=:candidate_graduationcollege,
candidate_skills=:candidate_skills,
candidate_mayalsoknow=:candidate_mayalsoknow,
candidate_tiercity=:candidate_tiercity,
candidate_loanproduct=:candidate_loanproduct,
candidate_loansubproduct=:candidate_loansubproduct,
candidate_internalsource=:candidate_internalsource,
candidate_sourcetype=:candidate_sourcetype,
candidate_externalsource=:candidate_externalsource,
candidate_refferredname=:candidate_refferredname,
candidate_refferredbankname=:candidate_refferredbankname,
candidate_referredid=:candidate_referredid,
candidate_dateofentry=:candidate_dateofentry,
candidate_deeshaemployeenamerefer=:candidate_deeshaemployeenamerefer,
candidate_deeshaemployeenameenter=:candidate_deeshaemployeenameenter,
candidate_marriageanniv=:candidate_marriageanniv,
candidate_lastaccessdate=:candidate_lastaccessdate,
candidate_lastaccessperson=:candidate_lastaccessperson,
candidate_deeshaemployeefeedback=:candidate_deeshaemployeefeedback,
candidate_deeshaemployeecomment=:candidate_deeshaemployeecomment,
candidate_currentbossname=:candidate_currentbossname,
candidate_exbossname=:candidate_exbossname,
candidate_interestingfact=:candidate_interestingfact,
candidate_languagesspeak=:candidate_languagesspeak,
candidate_languageprefer=:candidate_languageprefer,
candidate_mothertongue=:candidate_mothertongue,
candidate_banker=:candidate_banker,
candidate_residenceaddress=:candidate_residenceaddress,
candidate_companyaddress=:candidate_companyaddress,
candidate_country=:candidate_country,
candidate_reportingmanagerno=:candidate_reportingmanagerno,
candidate_saturdayworking=:candidate_saturdayworking,
candidate_associatedeeesha=:candidate_associatedeeesha,
candidate_bankerdeeesha=:candidate_bankerdeeesha,
candidate_customerdeeesha=:candidate_customerdeeesha,
candidate_candidatefinploy=:candidate_candidatefinploy,
candidate_companyfinploy=:candidate_companyfinploy,
candidate_associatefinploy=:candidate_associatefinploy,
candidate_companyfinterno=:candidate_companyfinterno,
candidate_internfinterno=:candidate_internfinterno,
candidate_associatefinterno=:candidate_associatefinterno,
candidate_companyfintubhai=:candidate_companyfintubhai,
candidate_customerfintubhai=:candidate_customerfintubhai,
candidate_associatefintubhai=:candidate_associatefintubhai,
candidate_idassociatedeeesha=:candidate_idassociatedeeesha,
candidate_idbankerdeeesha=:candidate_idbankerdeeesha,
candidate_idcustomerdeeesha=:candidate_idcustomerdeeesha,
candidate_idcandidatefinploy=:candidate_idcandidatefinploy,
candidate_idassociatefinploy=:candidate_idassociatefinploy,
candidate_idcompanyfinterno=:candidate_idcompanyfinterno,
candidate_idintern=:candidate_idintern,
candidate_idassociatefinterno=:candidate_idassociatefinterno,
candidate_idcompanyfintubhai=:candidate_idcompanyfintubhai,
candidate_idcustomerfintubhai=:candidate_idcustomerfintubhai,
candidate_idassociatefintubhai=:candidate_idassociatefintubhai,
candidate_othercity=:candidate_othercity,
candidate_nameoncertificate=:candidate_nameoncertificate,
candidate_mothername=:candidate_mothername,
candidate_fathername=:candidate_fathername,
candidate_fathertelno=:candidate_fathertelno,
candidate_mothertelno=:candidate_mothertelno,
candidate_registrationsite=:candidate_registrationsite,
candidate_interestedinbankingetc=:candidate_interestedinbankingetc,
candidate_interests=:candidate_interests,
candidate_noofpastinternships=:candidate_noofpastinternships,
candidate_pastinternships=:candidate_pastinternships,
candidate_durationofinternship=:candidate_durationofinternship,
candidate_haveyoudonewithdeeesha=:candidate_haveyoudonewithdeeesha,
candidate_areyoulookeducationloan=:candidate_areyoulookeducationloan,
candidate_rolesinpreviousinternship=:candidate_rolesinpreviousinternship,
candidate_typeofinternship=:candidate_typeofinternship,
candidate_joinasafulltimeemployee=:candidate_joinasafulltimeemployee,
candidate_internshipprefer=:candidate_internshipprefer,
candidate_hoursdedicate=:candidate_hoursdedicate,
candidate_personalizedlaptop=:candidate_personalizedlaptop,
candidate_stableconnection=:candidate_stableconnection,
candidate_typeofinternship2=:candidate_typeofinternship2,
candidate_howdaysworkaweek=:candidate_howdaysworkaweek,
candidate_desiredincome=:candidate_desiredincome,
candidate_havetechnicalknowledge=:candidate_havetechnicalknowledge,
candidate_professortelno=:candidate_professortelno,
linkedin_name=:linkedin_name,
linkedin_namepos=:linkedin_namepos,
linkedin_companyname=:linkedin_companyname,
linkedin_cityname=:linkedin_cityname,
linkedin_statename=:linkedin_statename,
linkedin_namecountry=:linkedin_namecountry,
linkedin_currentjob=:linkedin_currentjob,
linkedin_secondlastjob=:linkedin_secondlastjob,
linkedin_thirdlastjob=:linkedin_thirdlastjob,
linkedin_highesteducation=:linkedin_highesteducation,
linkedin_secondeducation=:linkedin_secondeducation,
linkedin_skills=:linkedin_skills,
linkedin_interests=:linkedin_interests,
linkedin_accomplishment=:linkedin_accomplishment,
linkedin_urlfromscrapper=:linkedin_urlfromscrapper,
candidate_firstname=:candidate_firstname,
candidate_middlename=:candidate_middlename,
candidate_lastname=:candidate_lastname,
candidate_employeemail=:candidate_employeemail,
candidate_birthday=:candidate_birthday,
candidate_emailidofficial=:candidate_emailidofficial,
candidate_lastcallbydeeeshaemp=:candidate_lastcallbydeeeshaemp

where candidate_id='$aynicandidate_id'

  ");



$derle = $hazirla->execute(array(



"candidate_ad" => $candidate_ad,
"candidate_soyad" => $candidate_soyad,
"candidate_adsoyad" => $candidate_adsoyad,
"candidate_telno" => $candidate_telno,
"candidate_company" => $candidate_company,
"candidate_designation" => $candidate_designation,
"candidate_pincode" => $candidate_pincode,
"candidate_location" => $candidate_location,
"candidate_linkedin" => $candidate_linkedin,
"candidate_mail" => $candidate_mail,
"candidate_product" => $candidate_product,
"candidate_department" => $candidate_department,
"candidate_birthdate" => $candidate_birthdate,
"candidate_industry" => $candidate_industry,
"candidate_currentjobexperience" => $candidate_currentjobexperience,
"candidate_currentfunctionalarea" => $candidate_currentfunctionalarea,
"candidate_bankingdepartment" => $candidate_bankingdepartment,
"candidate_bankingsubdepartment" => $candidate_bankingsubdepartment,
"candidate_multiplelocation" => $candidate_multiplelocation,
"candidate_multiplelocationnames" => $candidate_multiplelocationnames,
"candidate_prefferedlocation" => $candidate_prefferedlocation,
"candidate_gender" => $candidate_gender,
"candidate_totalworkexperience" => $candidate_totalworkexperience,
"candidate_annualsalary" => $candidate_annualsalary,
"candidate_deeshamail" => $candidate_deeshamail,
"candidate_websitesource" => $candidate_websitesource,
"candidate_telno2" => $candidate_telno2,
"candidate_wpno" => $candidate_wpno,
"candidate_wpno2" => $candidate_wpno2,
"candidate_noticeperiod" => $candidate_noticeperiod,
"candidate_highesteducationlevel" => $candidate_highesteducationlevel,
"candidate_highesteducationstream" => $candidate_highesteducationstream,
"candidate_highesteducationinsitute" => $candidate_highesteducationinsitute,
"candidate_yearofpassing" => $candidate_yearofpassing,
"candidate_highesteducationcoursetype" => $candidate_highesteducationcoursetype,
"candidate_createdate" => $candidate_createdate,
"candidate_lastmodifieddate" => $candidate_lastmodifieddate,
"candidate_lastactivedate" => $candidate_lastactivedate,
"candidate_note" => $candidate_note,
"candidate_summarydescription" => $candidate_summarydescription,
"candidate_experiencepershine" => $candidate_experiencepershine,
"candidate_lastjob" => $candidate_lastjob,
"candidate_lasttolastjob" => $candidate_lasttolastjob,
"candidate_graducationcourse" => $candidate_graducationcourse,
"candidate_graduationcollege" => $candidate_graduationcollege,
"candidate_skills" => $candidate_skills,
"candidate_mayalsoknow" => $candidate_mayalsoknow,
"candidate_tiercity" => $candidate_tiercity,
"candidate_loanproduct" => $candidate_loanproduct,
"candidate_loansubproduct" => $candidate_loansubproduct,
"candidate_internalsource" => $candidate_internalsource,
"candidate_sourcetype" => $candidate_sourcetype,
"candidate_externalsource" => $candidate_externalsource,
"candidate_refferredname" => $candidate_refferredname,
"candidate_refferredbankname" => $candidate_refferredbankname,
"candidate_referredid" => $candidate_referredid,
"candidate_dateofentry" => $candidate_dateofentry,
"candidate_deeshaemployeenamerefer" => $candidate_deeshaemployeenamerefer,
"candidate_deeshaemployeenameenter" => $candidate_deeshaemployeenameenter,
"candidate_marriageanniv" => $candidate_marriageanniv,
"candidate_lastaccessdate" => $candidate_lastaccessdate,
"candidate_lastaccessperson" => $candidate_lastaccessperson,
"candidate_deeshaemployeefeedback" => $candidate_deeshaemployeefeedback,
"candidate_deeshaemployeecomment" => $candidate_deeshaemployeecomment,
"candidate_currentbossname" => $candidate_currentbossname,
"candidate_exbossname" => $candidate_exbossname,
"candidate_interestingfact" => $candidate_interestingfact,
"candidate_languagesspeak" => $candidate_languagesspeak,
"candidate_languageprefer" => $candidate_languageprefer,
"candidate_mothertongue" => $candidate_mothertongue,
"candidate_banker" => $candidate_banker,
"candidate_residenceaddress" => $candidate_residenceaddress,
"candidate_companyaddress" => $candidate_companyaddress,
"candidate_country" => $candidate_country,
"candidate_reportingmanagerno" => $candidate_reportingmanagerno,
"candidate_saturdayworking" => $candidate_saturdayworking,
"candidate_associatedeeesha" => $candidate_associatedeeesha,
"candidate_bankerdeeesha" => $candidate_bankerdeeesha,
"candidate_customerdeeesha" => $candidate_customerdeeesha,
"candidate_candidatefinploy" => $candidate_candidatefinploy,
"candidate_companyfinploy" => $candidate_companyfinploy,
"candidate_associatefinploy" => $candidate_associatefinploy,
"candidate_companyfinterno" => $candidate_companyfinterno,
"candidate_internfinterno" => $candidate_internfinterno,
"candidate_associatefinterno" => $candidate_associatefinterno,
"candidate_companyfintubhai" => $candidate_companyfintubhai,
"candidate_customerfintubhai" => $candidate_customerfintubhai,
"candidate_associatefintubhai" => $candidate_associatefintubhai,
"candidate_idassociatedeeesha" => $candidate_idassociatedeeesha,
"candidate_idbankerdeeesha" => $candidate_idbankerdeeesha,
"candidate_idcustomerdeeesha" => $candidate_idcustomerdeeesha,
"candidate_idcandidatefinploy" => $candidate_idcandidatefinploy,
"candidate_idassociatefinploy" => $candidate_idassociatefinploy,
"candidate_idcompanyfinterno" => $candidate_idcompanyfinterno,
"candidate_idintern" => $candidate_idintern,
"candidate_idassociatefinterno" => $candidate_idassociatefinterno,
"candidate_idcompanyfintubhai" => $candidate_idcompanyfintubhai,
"candidate_idcustomerfintubhai" => $candidate_idcustomerfintubhai,
"candidate_idassociatefintubhai" => $candidate_idassociatefintubhai,
"candidate_othercity" => $candidate_othercity,
"candidate_nameoncertificate" => $candidate_nameoncertificate,
"candidate_mothername" => $candidate_mothername,
"candidate_fathername" => $candidate_fathername,
"candidate_fathertelno" => $candidate_fathertelno,
"candidate_mothertelno" => $candidate_mothertelno,
"candidate_registrationsite" => $candidate_registrationsite,
"candidate_interestedinbankingetc" => $candidate_interestedinbankingetc,
"candidate_interests" => $candidate_interests,
"candidate_noofpastinternships" => $candidate_noofpastinternships,
"candidate_pastinternships" => $candidate_pastinternships,
"candidate_durationofinternship" => $candidate_durationofinternship,
"candidate_haveyoudonewithdeeesha" => $candidate_haveyoudonewithdeeesha,
"candidate_areyoulookeducationloan" => $candidate_areyoulookeducationloan,
"candidate_rolesinpreviousinternship" => $candidate_rolesinpreviousinternship,
"candidate_typeofinternship" => $candidate_typeofinternship,
"candidate_joinasafulltimeemployee" => $candidate_joinasafulltimeemployee,
"candidate_internshipprefer" => $candidate_internshipprefer,
"candidate_hoursdedicate" => $candidate_hoursdedicate,
"candidate_personalizedlaptop" => $candidate_personalizedlaptop,
"candidate_stableconnection" => $candidate_stableconnection,
"candidate_typeofinternship2" => $candidate_typeofinternship2,
"candidate_howdaysworkaweek" => $candidate_howdaysworkaweek,
"candidate_desiredincome" => $candidate_desiredincome,
"candidate_havetechnicalknowledge" => $candidate_havetechnicalknowledge,
"candidate_professortelno" => $candidate_professortelno,
"linkedin_name" => $linkedin_name,
"linkedin_namepos" => $linkedin_namepos,
"linkedin_companyname" => $linkedin_companyname,
"linkedin_cityname" => $linkedin_cityname,
"linkedin_statename" => $linkedin_statename,
"linkedin_namecountry" => $linkedin_namecountry,
"linkedin_currentjob" => $linkedin_currentjob,
"linkedin_secondlastjob" => $linkedin_secondlastjob,
"linkedin_thirdlastjob" => $linkedin_thirdlastjob,
"linkedin_highesteducation" => $linkedin_highesteducation,
"linkedin_secondeducation" => $linkedin_secondeducation,
"linkedin_skills" => $linkedin_skills,
"linkedin_interests" => $linkedin_interests,
"linkedin_accomplishment" => $linkedin_accomplishment,
"linkedin_urlfromscrapper" => $linkedin_urlfromscrapper,
"candidate_firstname" => $candidate_firstname,
"candidate_middlename" => $candidate_middlename,
"candidate_lastname" => $candidate_lastname,
"candidate_employeemail" => $candidate_employeemail,
"candidate_birthday" => $candidate_birthday,
"candidate_emailidofficial" => $candidate_emailidofficial,
"candidate_lastcallbydeeeshaemp" => $candidate_lastcallbydeeeshaemp


));


if ($derle) {

  
  echo "ok";

}

 } else if ($_POST['deleteip']){

$ip_id = $_POST['ip_id'];

$ipsil=$db->prepare("DELETE from allowedips where ip_id='$ip_id'");
$silip = $ipsil->execute();

if ($silip) {
  
  echo "ok";

}



 } else if (isset($_POST['addipaddress'])){

$ip_address = $_POST['ip_address'];

$hazirla=$db->prepare("INSERT into allowedips set

ip_address=:ip_address

  ");

$derle=$hazirla->execute(array(

"ip_address" => $ip_address

));

if ($derle) {
 
 echo "ok";

}

 } else if (isset($_POST['iplockupdate'])){

$ip_lock = $_POST['ip_lock'];

$hazirla = $db->prepare("UPDATE iplock set

iplock=:iplock

  ");

$derle = $hazirla->execute(array(
"iplock" => $ip_lock
));

if ($derle) {
  
  echo "ok";
}

 } else if (isset($_POST['adminindexyukle'])){ ?>


                            
                            
                            
                            





                            <?php $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             
                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>
                    

                          



                          

                          
                          

 <?php } else if (isset($_POST['peopleindexyukle'])){ ?>





                            <?php


                            $kullanici_mail = $_SESSION['kullanicioturum'];

  $kullanicisec = $db->prepare("SELECT * from kullanici where kullanici_mail='$kullanici_mail'");
  $kullanicisec->execute();
  $kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);

  $kullanici_idd = $kullanicicek['kullanici_id'];

   $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT candidate_id from candidates where kullanici_id='$kullanici_idd' and candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                </div>


                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                </div>

                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                </div>

                             

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                </div>


                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                </div>

                               <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                </div>

                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                </div>


                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                               <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                </div>

                                
                                <div align="center" style="height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                </div>

                            

                               

                            </div>
                    

                          


<?php } else if (isset($_POST['childsubadminindexyukle'])){ ?>


                            





                            <?php $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                  

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                 

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             
                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                 

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                 

                                </div>

                               

                            </div>
                    

                          



                          


 <?php } else if (isset($_POST['parentsubadminindexyukle'])){ ?>



                            





                            <?php $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                             
                             <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexport=ok&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               

                            </div>
                    

                          



                          


 <?php } else if (isset($_POST['subadmincemployeereportyukle'])){ ?>



                            





                            <?php

 $employee_id = $_POST['employee_id'];

                             $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                 
                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                 

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  
                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  

                                </div>

                                <input type="hidden" id="employee_id" value="<?php echo $_GET['employee_id']; ?>" name="employee_id">

                               

                            </div>

                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                              


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                 

                                </div>

                                <input type="hidden" id="employee_id" value="<?php echo $_GET['employee_id']; ?>" name="employee_id">

                               

                            </div>
                    

                          



                          


 <?php } else if (isset($_POST['adminemployeereportyukle'])){ ?>



                            

                            





                            <?php

                    $employee_id = $_POST['employee_id'];

                             $buguntarih = date('Y-m-d');

  $candidateassignedsec = $db->prepare("SELECT * from candidates where kullanici_id='$employee_id' and candidate_listed='1'");
  $candidateassignedsec->execute();
  $candidateassignedsay=$candidateassignedsec->rowCount();

                      $candidatesec = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec->execute();
                      $candidatesay=$candidatesec->rowCount();


                      $candidatesec2 = $db->prepare("SELECT * from candidates where candidate_respond='Send me details I will see' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec2->execute();
                      $candidatesay2=$candidatesec2->rowCount();



                      $candidatesec3 = $db->prepare("SELECT * from candidates where candidate_respond='Busy right now, call later' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec3->execute();
                      $candidatesay3=$candidatesec3->rowCount();



                      $candidatesec4 = $db->prepare("SELECT * from candidates where candidate_respond='Wrong Number' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec4->execute();
                      $candidatesay4=$candidatesec4->rowCount();


                      $candidatesec5 = $db->prepare("SELECT * from candidates where candidate_respond='FULLY Not Interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec5->execute();
                      $candidatesay5=$candidatesec5->rowCount();


                      $candidatesec6 = $db->prepare("SELECT * from candidates where candidate_respond='Mobile Switch Off' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec6->execute();
                      $candidatesay6=$candidatesec6->rowCount();


                      $candidatesec7 = $db->prepare("SELECT * from candidates where candidate_respond='Call Not Answered' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec7->execute();
                      $candidatesay7=$candidatesec7->rowCount();


                      $candidatesec8 = $db->prepare("SELECT * from candidates where candidate_respond='Out of Network Area' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec8->execute();
                      $candidatesay8=$candidatesec8->rowCount();


                      $candidatesec9 = $db->prepare("SELECT * from candidates where candidate_respond='Call Rejected' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec9->execute();
                      $candidatesay9=$candidatesec9->rowCount();


                      $candidatesec10 = $db->prepare("SELECT * from candidates where candidate_respond='1st round Whatsapp group made / message sent' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec10->execute();
                      $candidatesay10=$candidatesec10->rowCount();


                      $candidatesec11 = $db->prepare("SELECT * from candidates where candidate_respond='2nd round called again check if interested' and kullanici_id='$employee_id' and candidate_listed='1'");
                      $candidatesec11->execute();
                      $candidatesay11=$candidatesec11->rowCount(); ?>
                            


<div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">SUMMARY</h4>

                              </div>

                         <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls assigned ( <?php echo $candidateassignedsay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Total Number of Calls Assigned"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;border:1px solid #BCBAB9;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Total Number of Calls actually made ( <?php echo $candidatesay3+$candidatesay4+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9+$candidatesay10+$candidatesay11+$candidatesay5+$candidatesay2+$candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Total Number of Calls actually made"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Interested candidates ( <?php echo $candidatesay+$candidatesay2+$candidatesay10+$candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Total Number of Interested candidates"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Not interested ( <?php echo $candidatesay4+$candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Total Number of Not interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Total Number of Calls not connected ( <?php echo $candidatesay3+$candidatesay6+$candidatesay7+$candidatesay8+$candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Total Number of Calls not connected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                              

                               

                            </div>

                            
                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Interested ( <?php echo $candidatesay; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=FULLY Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#4E9E11;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Send me details I will see ( <?php echo $candidatesay2; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Send me details I will see"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#DF9930;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Busy right now, call later ( <?php echo $candidatesay3; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Busy right now, call later"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Wrong Number ( <?php echo $candidatesay4; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Wrong Number"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;background-color:#C30808;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">FULLY Not Interested ( <?php echo $candidatesay5; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=FULLY Not Interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                               
                               

                              
                            </div>


                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF NOT CONNECTED</h4>

                              </div>

                              <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Mobile Switch Off ( <?php echo $candidatesay6; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Mobile Switch Off"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Not Answered ( <?php echo $candidatesay7; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Call Not Answered"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Out of Network Area ( <?php echo $candidatesay8; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Out of Network Area"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color:#DF9930;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">Call Rejected ( <?php echo $candidatesay9; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=Call Rejected"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <input type="hidden" id="employee_id" value="<?php echo $_GET['employee_id']; ?>" name="employee_id">

                               

                            </div>

                            <div class="col-md-3 col-sm-3 col-xs-12">
                              
                              <div style="margin-bottom: 20px;border:1px solid #043d75;background-color:rgba(4,61,117,0.2);width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #043d75;">IF INTERESTED</h4>

                              </div>

                              


                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">1st round Whatsapp group made / message sent ( <?php echo $candidatesay10; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=1st round Whatsapp group made / message sent"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                
                                <div align="center" style="height: 60px;position:relative;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;background-color: #4E9E11;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #fff;">2nd round - Total Number called again and finally interested ( <?php echo $candidatesay11; ?> )</span>

                                  <div style="height: 20px;width: 20px;border:1px solid #e7e7e7;background-color: #fff;position: absolute;top: 0;
                                  right: 0;"><a href="../islem.php?allsingledataexportemployee=ok&employee_id=<?php echo $employee_id; ?>&status=2nd round - Total Number called again and finally interested"><i style="font-size: 16px;margin-top: 5px;" class="fa fa-download"></i></a></div>

                                </div>

                                <input type="hidden" id="employee_id" value="<?php echo $_GET['employee_id']; ?>" name="employee_id">

                               

                            </div>
                    

                          



                          





                                                 


 <?php } 