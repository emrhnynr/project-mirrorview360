<?php require_once 'header.php';


$candidate_id = $_GET['candidate_id'];

$candidatesec=$db->prepare("SELECT * from candidates where candidate_id='$candidate_id'");
$candidatesec->execute();
$candidatesay=$candidatesec->rowCount();

if ($candidatesay==0) {
  
  header("Location:../people/");
  exit;

}

$candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC);

         $documentstestsec=$db->prepare("SELECT * from candidatedocuments where candidate_id='$candidate_id'");
         $documentstestsec->execute();

         $documentstestsay = $documentstestsec->rowCount();


                 


$documentssec=$db->prepare("SELECT * from candidatedocuments where candidate_id='$candidate_id' order by document_date DESC");
$documentssec->execute();

                          ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Candidate Documents : <?php echo $candidate_id; ?></h2>

                    <div  class="col-xs-12 col-sm-3 col-md-3 nav navbar-right panel_toolbox">


                       <div class="row">

                        
                         
                        

                        <div class="col-md-12 col-sm-12 col-xs-12"><a data-toggle="modal" data-target="#addfile" class="btn btn-block btn-success"><i class="fa fa-plus"></i> Add New</a></div>


                        <!-- Modal -->
<div class="modal fade" id="addfile" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Add New File</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <form onsubmit="return false;" id="addfileform">

          <div class="row">
            

       <div class="col-md-12 col-xs-12">
         
        <input type="text" id="title" maxlength="200" placeholder="Title (Not required)" name="document_title" class="form-control">

       </div>

       

       <div style="margin-top: 20px;" class="col-md-12 col-xs-12">
         
        <input id="file" type="file" class="form-control" name="document_path">

        <input type="hidden" id="candidate_id" value="<?php echo $candidatecek['candidate_id']; ?>" name="candidate_id" >

        <input type="hidden" name="candidateaddfile">

       </div>

       <br>

          </div>

                    <div style="margin-top: 20px;" align="center" class="col-md-12">
                      <a style="color: #fff;" href="javascript:void(0);" class="btn btn-success btn-block applybuton" name="addbuton">Add</a>
                    </div>

                    <br>

                    </form>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>  


                      

                       </div>
                    
                       
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Upload Date</th>
                          <th>Title</th>
                          <th>Download</th>
                          <th></th>
                          
                          
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php 

                         while ($documentscek=$documentssec->fetch(PDO::FETCH_ASSOC)) {


 $document_date = $documentscek['document_date'];
 $document_title = $documentscek['document_title']

 


                          ?>
                            

                            <tr id="file_<?php echo $documentscek['document_id']; ?>">
                          <td><?php echo $document_date; ?></td>

                          <td><?php echo $document_title; ?></td>

                         

                          <td><a class="btn btn-block" href="../<?php echo $documentscek['document_path']; ?>" download="<?php echo basename($documentscek['document_path']); ?>"><i class="fa fa-download"></i> Download File</a></td>
                         
                          
                          <td>
                            
                            <div class="row">
                              
                              

                               <div  align="center" class="col-md-12 col-sm-12 col-xs-12"><a class="btn btn-danger btn-sm deleteexcel" name="document_<?php echo $documentscek['document_id']; ?>" href="javascript:void(0);">Delete File</a></div>

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       <script type="text/javascript">
         
         $('.deleteexcel').click(function(){

         var buton = $(this);
          var id1=$(this).attr("name");
                var file_id=id1.substring(9);

swal({
  title: "Are you sure?",
  text: "This file will be deleted.",
  icon: "warning",
  buttons: ["Cancel", "Delete"],
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

    buton.html('Deleting...');

    $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'deletedocument':'ok','document_id':file_id},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


           



             if (sonuc=="ok") {


              $('#file_'+file_id).remove();
             

              

             }

               }

             });

   }

   })

         });


         $('.applybuton').click(function(){

                var input = $('#file');
var dosya = $('#file').val();
var filevalue = $('#file').get(0).files[0];
var dosyauzanti = dosya.split('.').pop();
var title = $.trim($('#title').val());
var candidate_id = $('#candidate_id').val();

var data = new FormData();
data.append('addcandidatefile',"ok");
data.append("file",filevalue);
data.append("title",title);
data.append("candidate_id",candidate_id);



 if ($('#file').val().length==0){

alert('Please upload a file');

  } else {

  $('.applybuton').prop('disabled',true);
  $('.applybuton').html('Uploading...');

  $.ajax({
            type : 'POST',
            url : '../islem.php',
            enctype : 'multipart/form-data',
            data : data,
            processData: false,
            contentType: false,
            cache: false,
            success : function(sonuc){

      sonuc=$.trim(sonuc);

     
      
      if (sonuc=="ok") {

        location.reload();
        

      } 

 }

 });


   }

              });

       </script>