<?php require_once 'header.php';

$kullanici_idd = $kullanicisessioncek['kullanici_id'];



if (!empty($_GET['search'])) {

  $search = $_GET['search'];

  $candidatetestsec=$db->prepare("SELECT * from candidates where kullanici_id='$kullanici_idd' and candidate_listed='1' and (candidate_id LIKE '$search%' or candidate_id LIKE '%$search%' or candidate_id LIKE '%$search' or candidate_adsoyad LIKE '$search%' or candidate_adsoyad LIKE '%$search%' or candidate_adsoyad LIKE '%$search' or candidate_telno LIKE '%$search' or candidate_telno LIKE '$search%' or candidate_telno LIKE '%$search%') order by candidate_tarihi DESC");


  $candidatetestsec->execute();

$candidatetestsay = $candidatetestsec->rowCount();

$sayfa=@$_GET['p'];
    if (empty($_GET['p'])) {
      $sayfa=1;
    };

$kacar=20;
$sayfasayisi=ceil($candidatetestsay/$kacar);
 $baslangic=($kacar*$sayfa)-$kacar;

 if ($candidatetestsay!=0 and ($sayfa>$sayfasayisi or $sayfa<1)) {
     
     header("Location:../people/");
 }
  
} else {


$arama = "yok";

}



//------------------------------------------------------------------------



                         

 ?>

 <style type="text/css">
   
   @media only screen and (max-width: 768px) {

.margin {

  margin-top: 14px;
}

 }

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">
              

              <!-- Bitiyor -->

              
       

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Candidates</h2>

                     <div  class="col-xs-12 col-sm-7 col-md-7 nav navbar-right panel_toolbox">
                       <div class="row">

                        <form action="candidates" method="GET">
                         
                        <div class="col-md-5 col-sm-4 col-xs-12 margin"></div>

                        <div class="col-md-5 col-sm-4 col-xs-12 margin"><input <?php if (isset($_GET['search']) and $_GET['search']!='') { ?>
                         value ='<?php echo $_GET['search']; ?>'
                        <?php } ?> type="text" placeholder="ID, Name, Phone" maxlength="150" name="search" class="form-control"></div>

                        <div class="col-md-2 col-sm-4 col-xs-12 margin"><button type="submit" class="btn btn-block btn-primary"><i class="fa fa-search"></i> Search</button></div>


                        </form>

                       </div>
                    </div>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <?php if (!empty($_GET['search'])) { ?>


                      <?php if ($candidatetestsay==0) { ?>
                        
                        <h4 align="center">Any data not found.</h4>

                      <?php } else { ?>



                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name</th>
                          

                          <th>Phone Number</th>

                          <th>Called</th>

                          <th>Call Time</th>

                         
                          

                         
                          
                          
                          <th></th>
                          
                        </tr>
                      </thead>
                      <tbody>

                        <?php



                        
                          

                           $candidatesec=$db->prepare("SELECT * from candidates where kullanici_id='$kullanici_idd' and candidate_listed='1' and (candidate_id LIKE '$search%' or candidate_id LIKE '%$search%' or candidate_id LIKE '%$search' or candidate_adsoyad LIKE '$search%' or candidate_adsoyad LIKE '%$search%' or candidate_adsoyad LIKE '%$search' or candidate_telno LIKE '%$search' or candidate_telno LIKE '$search%' or candidate_telno LIKE '%$search%') order by candidate_tarihi DESC limit $baslangic,$kacar");
                         $candidatesec->execute();
   

                        



                         
                         while ($candidatecek=$candidatesec->fetch(PDO::FETCH_ASSOC)) {?>
                            

                            <tr id="candidate_<?php echo $candidatecek['candidate_id']; ?>">
                          <td><?php echo $candidatecek['candidate_id']; ?></td>
                          <td><?php echo $candidatecek['candidate_ad']." ".$candidatecek['candidate_soyad']; ?></td>
                          
                          <td><a href="tel:<?php echo $candidatecek['candidate_telno']; ?>"><?php echo $candidatecek['candidate_telno']; ?></a></td>

                          <td>

                          <?php if ($candidatecek['candidate_called']=='1') { ?>
                            

                            <div style="background-color: green;" class="badge badge-success">Called</div>
                        

                          <?php } else if ($candidatecek['candidate_called']=='0'){ ?>

                            
                           <div style="background-color: orange;" class="badge badge-warning">Not Called</div>

                          <?php } ?>

                          </td>

                          <td><?php if ($candidatecek['candidate_called']=='1') { 

                           echo $candidatecek['candidate_markdate'];

                          } else {

                           echo "N/A";

                          } ?></td>
                           
                          <td>


                            
                            <div class="row">
                              
                              <div align="center" class="col-md-12 col-sm-12 col-xs-12">

                                <?php if ($candidatecek['candidate_called']=='1') { ?>
                                  
                                  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#candidated_<?php echo $candidatecek['candidate_id']; ?>">
  Call Logs
</button>

<!-- Modal -->
<div class="modal fade" id="candidated_<?php echo $candidatecek['candidate_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Call Logs</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Order of Call</th>
                          <th>Time</th>
                          <th>Response</th>
                          <th>Remark</th>
                          <th>Called By</th>
                          
                      </thead>
                      <tbody>
 
                   <?php

                    $candidate_idy = $candidatecek['candidate_id'];
                    

                    $calllogssec=$db->prepare("SELECT * from calllogs where candidate_id='$candidate_idy' order by call_time DESC");
                    $calllogssec->execute();
                    $calllogssay=$calllogssec->rowCount();
                    $i=$calllogssay+1;
                    while ($calllogscek=$calllogssec->fetch(PDO::FETCH_ASSOC)) { $i--; ?>
                      
                      <tr>

                          <td><?php echo $i; ?></td>
                          <td><?php echo $calllogscek['call_time']; ?></td>
                          <td><?php echo $calllogscek['call_response']; ?></td>
                          <td><?php if (strlen($calllogscek['call_remark'])==0) {

                            echo "N/A";

                          } else {

                            echo $calllogscek['call_remark'];

                          } ?></td>

                           <td><?php echo $calllogscek['caller']; ?></td>
                          
                        </tr>

                    <?php } ?>

                        
                        
                      </tbody>
                    </table>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>                    
                               <?php } ?>

                                <a target="_blank" class="btn btn-success btn-sm" href="candidate-profile?candidate_id=<?php echo $candidatecek['candidate_id']; ?>"><i class="fa fa-user"></i> Profile</a></div>

                               

                            </div>

                          </td>
                          
                        </tr>


                          <?php } ?>
                        
                        

                      </tbody>
                    </table>

                    <?php if ($candidatetestsay>$kacar) { 

                       $key = 'p';
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

   $filteredURL = preg_replace('~(\?|&)'.$key.'=[^&]*~', '$1', $current_url);

   ?>

                    <nav aria-label="Page navigation example">
  <ul class="pagination">

    <?php $p=0; if ($sayfa!=1) { ?>

    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="candidates?p=<?php echo $sayfa-1; ?>"

     <?php } else { ?>


       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa-1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa-1; ?>"


      <?php } ?>
       

    <?php } ?> aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>

  <?php } ?>

  <?php while ($p<$sayfasayisi) { $p++;

  if ($p<=$sayfa+3 and $p>=$sayfa-3) {

   ?>

    <li class="page-item <?php if($p==$sayfa){ ?>

                                        active

                                   <?php } ?>"><a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="candidates?p=<?php echo $p; ?>"
        
     <?php } else { ?>

       <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $p; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $p; ?>"


      <?php } ?>

    <?php } ?>  ><?php echo $p; ?></a></li>

  <?php } } ?>


    <?php if ($sayfa!=$sayfasayisi) { ?>
   
    <li class="page-item">
      <a class="page-link" <?php if (!isset($_GET['search'])) { ?>

        href="candidates?p=<?php echo $sayfa+1; ?>"
        
     <?php } else { ?>

 <?php if (empty($_GET['p'])) { ?>
         
     href="<?php echo $filteredURL; ?>&p=<?php echo $sayfa+1; ?>"

       <?php } else { ?>


        href="<?php echo $filteredURL; ?>p=<?php echo $sayfa+1; ?>"


      <?php } ?>

     <?php } ?>  aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>

  <?php } ?>

  </ul>
</nav>

<?php } ?>


                    <?php } ?>

            

                      

           

                    <?php } else { ?>

                      <h4 align="center"><i class="fa fa-search"></i> Search anything above for data.</h4>


                   <?php } ?>
                    
                    

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

       <?php require_once 'footer.php'; ?>

       