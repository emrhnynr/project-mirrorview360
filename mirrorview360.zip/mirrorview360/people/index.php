<?php require_once 'header.php';

$kullanici_idd = $kullanicisessioncek['kullanici_id'];

 ?>

<style type="text/css">
   
@media only screen and (max-width: 768px) {

.baslik {

  margin-top: 28px;
}

.gobtn {

  margin-top: 15px;
}

}

 </style>

        <!-- page content -->
        <div class="right_col" role="main">

          <div class="container">
          
       <div align="center" class="col-md-12 col-sm-12 col-xs-12">

        <h3 align="left">Call Response Report<hr></h3>


        <div  class="col-xs-12 col-sm-7 col-md-7 nav navbar-right panel_toolbox">
                       <div class="row">

                        <form onsubmit="return false;" action="candidates" method="GET">
                         
                        <div class="col-md-5 col-sm-4 col-xs-12 margin"></div>

                        <div class="col-md-5 col-sm-4 col-xs-12 margin"><input type="date" id="dateinput" class="form-control"></div>

                        <div class="col-md-2 col-sm-4 col-xs-12 margin"><button type="submit" class="btn btn-block btn-primary gobtn"> Show</button></div>


                        </form>

                       </div>
                    </div>

                    <br><br>

                    <input type="hidden" id="kullanici_idd" value="<?php echo $kullanici_idd; ?>">

       
         

                          <div class="row icerikk" style="margin-top: 20px;padding-bottom: 150px;">


                            
                            


                          </div>



                        


                         
                         
                   
                    
                   
                  

       </div>

       </div>
          
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">

          $('.icerikk').html('<h4 style="font-family:Arial;" align="center">Loading...</h4>');

$('.gobtn').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : '../islem.php',
            data : {'peopleindexyukle':'ok'},
            success : function(sonuc){

                sonuc=$.trim(sonuc);



                $('.gobtn').prop('disabled',false);

                $('.icerikk').html(sonuc);

                $('.gobtn').click(function(){

     var zaman = $('#dateinput').val();



$('.icerikk').html('<h4 style="font-family:Arial;" align="center">Loading...</h4>');

$('.gobtn').prop('disabled',true);

$.ajax({
            type : 'POST',
            url : '../islem.php',
            data : {'zaman':zaman,'kullanicistatssec':'ok'},
            success : function(sonuc){

                sonuc=$.trim(sonuc);



                $('.gobtn').prop('disabled',false);
                

                $('.icerikk').html(sonuc);

              

                

                 }

                });

          });

                 }

                 });
          
          

        </script>