<?php require_once 'header.php'; ?>

        

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Change Panel Password</h3>
              </div>

              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                    <br />
                    <form id="sifredegistirform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Current Password <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="password" id="passwordpresent" name="mevcut_sifre"  placeholder="Enter your current password" maxlength="100" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">New Password <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="password" id="passwordnew" name="yeni_sifre" placeholder="Enter your new password" maxlength="100" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <input type="hidden" name="sifredegistir">
                      <input type="hidden" value="<?php echo $kullanicisessioncek['kullanici_id']; ?>" name="kullanici_id">

                      
                     
                      
                      <div class="form-group">


                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                           <div style="display: none;" class="alert alert-danger uyari"></div>
                           <div style="display: none;" class="alert alert-success success"></div>
                          
                          <button type="submit" class="btn btn-success submitbuton">Change</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
              $('#sifredegistirform').submit(function(){

          var mevcutsifre = $('#passwordpresent').val();
          var yenisifre = $('#passwordnew').val();

          $('.submitbuton').prop('disabled',true);

        if (yenisifre.length<6) {

         $('.success').hide();
        $('.uyari').show();
        $('.uyari').html("New password can't be shorter than 6 characters.");
        $('.submitbuton').prop('disabled',false);

        } else {

          $('.submitbuton').html('Changing...');

          $.ajax({
            type : 'POST',
            url : '../islem.php',
            data : $('#sifredegistirform').serialize(),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              

              if (sonuc=="yanlissifre") {
           
           $('.submitbuton').prop('disabled',false);
           $('.success').hide();
           $('.uyari').show();
           $('.uyari').html('Please enter your current password correctly.');
           $('.submitbuton').html('Change');

              } else if (sonuc=="ok") {

         $('.submitbuton').prop('disabled',false);
         $('.submitbuton').html('Change');
         $('.uyari').hide();
        $('.success').show();
        $('.success').html('<i class="fa fa-check"></i> Password has changed!');
        $('#passwordnew').val('');
        $('#passwordpresent').val('');
               
            } 
              }
        })
        }

              })

            </script>


            