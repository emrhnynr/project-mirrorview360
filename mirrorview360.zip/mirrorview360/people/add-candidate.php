<?php require_once 'header.php'; ?>

 <style type="text/css">
   
@media only screen and (max-width: 768px) {

.baslik {

  margin-top: 28px;
}

.priceinputs {

margin-top: 15px;

}

}

 </style>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-user-plus"></i> Add New Candidate</h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form id="addcandidateform" class="form-horizontal form-label-left" onsubmit="return false;">

                     
                      <span class="section">Personal Info</span>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="candidate_ad" class="form-control col-md-7 col-xs-12" maxlength="200" name="candidate_ad"  type="text">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Surname 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="candidate_soyad" class="form-control col-md-7 col-xs-12" maxlength="200" type="text" name="candidate_soyad">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_telno" name="candidate_telno" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                     




                      
                      

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Linkedin URL 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_linkedin" name="candidate_linkedin" maxlength="500" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Interested to <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <div style="margin-top: 7px;" class="form-check">
  <input class="form-check-input" type="radio" value="becomeassociate" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault1">
    Become Associate
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" value="becomefulltimeemployee" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    Become Full Time Employee
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="radio" value="none" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    None
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="radio" value="company" name="candidate_interestedto">
  <label class="form-check-label" for="flexRadioDefault2">
    Company
  </label>
</div>
                        </div>
                      </div>

                      


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Looking for a job change?
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_jobchange" name="candidate_jobchange">
                            
                             
                              
                              <option value="select">Select</option>
                              
                            

                            <option value="yes">Yes</option>

                            <option value="no">No</option>

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Company Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_company" name="candidate_company" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Designation
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_designation" name="candidate_designation" maxlength="300" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">E-mail
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_mail" name="candidate_mail" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_product" name="candidate_product">
                            
                             
                              
                              <option value="select">Select</option>
                              
                            

                            <option>Personal Loan</option>

                            <option>Business Loan</option>

                            <option>Home Loan</option>

                            <option>Loan Against Property</option>

                            <option>Commercial Vehicle Loan</option>

                            <option>Gold Loan</option>

                            <option>Branch Banking</option>

                            <option>Broking</option>

                            <option>Insurance</option>

                            <option>Credit Card</option>

                            <option value="others">Others</option>

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Department
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select class="form-control" id="candidate_department" name="candidate_department">
                            
                             
                              
                              <option value="select">Select</option>
                              
                            

                            <option>Sales</option>

                            <option>Credit</option>

                            <option>Operations</option>

                            <option>IT</option>

                            <option>Others</option>

                            

                          </select>
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Location Pincode
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_pincode" name="candidate_pincode" placeholder="6 digit number" maxlength="6" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Location Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_location" name="candidate_location" maxlength="200" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>



                      
                      <br>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Current Salary
                        </label>
                        <div style="padding-left: 25px;" class="col-md-6 col-sm-6 col-xs-12 row">

                          <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <select class="form-control" id="salary_monthlyannually" name="salary_monthlyannually">
                              
                    
                       <option value="monthly">Monthly</option>
                   
                     <option value="annually">Annually</option>

                            </select>
                          </div>

                           <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <input class="form-control" placeholder="Amount" type="number" name="salary_amount" id='salary_amount'>
                          </div>

                           <div class="col-md-4 col-sm-4 col-xs-12 priceinputs">
                            <select class="form-control" id="salary_measure" name="salary_measure">
                          
                      <option value="thousands">Thousands</option>  
                     <option value="lakhs">Lakhs</option>
                     

                            </select>
                          </div>
                          
                        </div>
                      </div>


                      <br>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Total Year Experience
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          
                          <input class="form-control" type="number" id="candidate_experience" max='100' name="candidate_experience">

                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="number">Referred By (Phone No.)
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="candidate_referredby" name="candidate_referredby" maxlength="10" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <br><hr><br>


                          <div class="row">
                            
                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF CONNECTED</h4>

                              </div>

                              
                                
                                <a href="javascript:void(0);"><div align="center" style="
                                  border:1px solid #e7e7e7;height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">FULLY Interested</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Send me details I will see</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Busy right now, call later</span>

                                </div></a>


                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Wrong Number</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">FULLY Not Interested</span>

                                </div></a>

                               
                               

                              
                            </div>


                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF NOT CONNECTED</h4>

                              </div>

                              <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Mobile Switch Off</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Call Not Answered</span>

                                </div></a>

                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Out of Network Area</span>

                                </div></a>


                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">Call Rejected</span>

                                </div></a>

                               

                            </div>

                            <div class="col-md-4 col-sm-4 col-xs-12">
                              
                              <div style="margin-bottom: 20px;background-color:#043d75;width: 100%;" class="col-md-12 col-sm-12 col-12 baslik">
                                
                                <h4 style="text-align: center; font-size: 20px;color: #fff;">IF INTERESTED THEN</h4>

                              </div>

                              <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">1st round Whatsapp group made / message sent</span>

                                </div></a>

                                
                                <a href="javascript:void(0);"><div align="center" style="

                                  border:1px solid #e7e7e7;


                                 height: 60px;margin-top: 15px;width: 100%;display: flex;justify-content: center;align-items: center;" class="col-md-12 col-sm-12 col-12 radios">
                                  
                                  <span style="font-size: 15.5px;color: #043d75;">2nd round called again check if interested</span>

                                </div></a>

                               

                            </div>



                          </div>


                          <hr>

                          <textarea class="form-control" id="remark" placeholder="ANY REMARKS" maxlength="3000" rows="5"></textarea>



                  
                     

                     <input type="hidden" name="addcandidate">
                     <input type="hidden" id="kullanici_id" value="<?php echo $kullanicisessioncek['kullanici_id'] ?>" name="kullanici_id">
                     
                  
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div align="right" class="col-md-6 col-md-offset-3">

                          <div align="left" style="display: none;" class="alert alert-info uyari"></div>
                          <div align="left" style="display: none;" class="alert alert-success uyari2"><i class="fa fa-check"></i> Candidate has added successfully.</div>

                         
                         
                          <button id="send" type="submit" class="btn btn-success addbuton">Add</button>
                        </div>
                      </div>


                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <?php require_once 'footer.php'; ?>

        <script type="text/javascript">

          $('.radios').click(function(){

        

var buton = $(this);

$('.radios').css('border','1px solid #e7e7e7');
$('div').removeClass('selected');

buton.css('border','2px solid green');
buton.addClass('selected');


});


$('.addbuton').click(function(){

  var response = $.trim($('.selected').find('span').html());
var checkedradio = $('input:radio:checked').length;
 var candidate_ad = $.trim($('#candidate_ad').val());
          var candidate_soyad = $.trim($('#candidate_soyad').val());
          var kullanici_id = $('#kullanici_id').val();
        var candidate_linkedin = $('#candidate_linkedin').val();
        var candidate_telno = $.trim($('#candidate_telno').val());
  var candidate_company = $.trim($('#candidate_company').val());
         var candidate_designation = $.trim($('#candidate_designation').val());
         var candidate_mail = $.trim($('#candidate_mail').val());
         var candidate_product = $.trim($('#candidate_product').val());
         var candidate_department = $.trim($('#candidate_department').val());
        var candidate_pincode = $('#candidate_pincode').val();
        var candidate_location = $('#candidate_location').val();
        var candidate_interestedto = $('input[name="candidate_interestedto"]:checked').val();
          var candidate_jobchange = $('#candidate_jobchange').val();
          var candidate_experience = $('#candidate_experience').val();
          var candidate_referredby = $('#candidate_referredby').val();
          var salary_monthlyannually = $('#salary_monthlyannually').val();
          var salary_amount = $('#salary_amount').val();
          var salary_measure = $('#salary_measure').val();

          

var submitbuton = $('.addbuton');


var remark = $.trim($('#remark').val());
var candidate_id = $('#candidate_id').val();


if (candidate_ad.length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Name field can't be empty.");

             } else if (candidate_telno.length<10) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Phone number field can't be shorter than 10 characters.");

             } else if (checkedradio==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Please check an interested to option.");

             } else if ($('.selected').length==0) {

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Please select a status.");

             } else {


  submitbuton.prop('disabled',true);
  submitbuton.html('Adding...');
  $('.uyari').hide();


 $.ajax({

   type : 'POST',
            url : '../islem.php',
            data : {'addcandidate':'ok','candidate_remark':remark,'candidate_ad':candidate_ad,'candidate_soyad':candidate_soyad,'candidate_telno':candidate_telno,'candidate_linkedin':candidate_linkedin,'candidate_response':response,'candidate_company':candidate_company,'candidate_designation':candidate_designation,'candidate_mail':candidate_mail,'candidate_product':candidate_product,'candidate_department':candidate_department,'candidate_pincode':candidate_pincode,'candidate_location':candidate_location,'candidate_interestedto':candidate_interestedto,'candidate_jobchange':candidate_jobchange,'candidate_experience':candidate_experience,'salary_monthlyannually':salary_monthlyannually,'salary_measure':salary_measure,'salary_amount':salary_amount,'kullanici_id':kullanici_id,'candidate_referredby':candidate_referredby},
            success : function(sonuc){

              sonuc=$.trim(sonuc);


             
        

             if (sonuc=="ok") {


             
              submitbuton.html('Candidate has added.');
              $('.uyari2').show();
              

             } else if (sonuc=="refernotexistphone"){


$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> Referred By : There is no such a candidate number.");
submitbuton.prop('disabled',false);
  submitbuton.html('Add');


             } else if (sonuc=='exist'){

$('.uyari').show();
$('.uyari2').hide();
$('.uyari').html("<i class='fa fa-info-circle'></i> This phone number is already exist");
submitbuton.prop('disabled',false);
  submitbuton.html('Add');

             }

               }

             }); 


  }




});


       



        </script>