-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 31 Ağu 2022, 08:36:26
-- Sunucu sürümü: 8.0.17
-- PHP Sürümü: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `candidatesystem`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `allowedips`
--

CREATE TABLE `allowedips` (
  `ip_id` int(11) NOT NULL,
  `ip_address` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `calllogs`
--

CREATE TABLE `calllogs` (
  `call_id` int(11) NOT NULL,
  `candidate_id` int(11) DEFAULT NULL,
  `call_time` timestamp NULL DEFAULT NULL,
  `call_response` varchar(300) DEFAULT NULL,
  `call_remark` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `caller` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `calllogs`
--

INSERT INTO `calllogs` (`call_id`, `candidate_id`, `call_time`, `call_response`, `call_remark`, `caller`) VALUES
(373, 1678, '2022-05-31 21:14:14', 'Send me details I will see', '', 'Master Admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `candidatedocuments`
--

CREATE TABLE `candidatedocuments` (
  `document_id` int(11) NOT NULL,
  `candidate_id` int(11) DEFAULT NULL,
  `document_title` varchar(300) DEFAULT NULL,
  `document_path` varchar(300) DEFAULT NULL,
  `document_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `candidates`
--

CREATE TABLE `candidates` (
  `candidate_id` int(11) NOT NULL,
  `candidate_ad` varchar(200) DEFAULT NULL,
  `candidate_soyad` varchar(200) DEFAULT NULL,
  `candidate_adsoyad` varchar(400) DEFAULT NULL,
  `candidate_telno` varchar(200) DEFAULT NULL,
  `candidate_idx` varchar(200) DEFAULT NULL,
  `candidate_location` varchar(200) DEFAULT NULL,
  `candidate_linkedin` varchar(500) DEFAULT NULL,
  `candidate_company` varchar(200) DEFAULT NULL,
  `candidate_called` enum('0','1') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `kullanici_id` int(11) DEFAULT NULL,
  `candidate_tarihi` timestamp NULL DEFAULT NULL,
  `candidate_respond` varchar(300) DEFAULT NULL,
  `candidate_remark` text,
  `candidate_markdate` timestamp NULL DEFAULT NULL,
  `candidate_interestedto` enum('becomeassociate','becomefulltimeemployee','none','company') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_designation` varchar(300) DEFAULT NULL,
  `candidate_mail` varchar(200) DEFAULT NULL,
  `candidate_product` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_department` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_pincode` varchar(20) DEFAULT NULL,
  `salary_monthlyannually` enum('monthly','annually') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `salary_amount` decimal(9,0) DEFAULT NULL,
  `salary_measure` varchar(100) DEFAULT NULL,
  `candidate_jobchange` enum('yes','no') DEFAULT NULL,
  `candidate_experience` decimal(3,0) DEFAULT NULL,
  `candidate_birthdate` varchar(40) DEFAULT NULL,
  `candidate_industry` varchar(150) DEFAULT NULL,
  `candidate_currentjobexperience` varchar(30) DEFAULT NULL,
  `candidate_currentfunctionalarea` varchar(100) DEFAULT NULL,
  `candidate_bankingdepartment` varchar(100) DEFAULT NULL,
  `candidate_bankingsubdepartment` varchar(100) DEFAULT NULL,
  `candidate_multiplelocation` varchar(10) DEFAULT NULL,
  `candidate_multiplelocationnames` varchar(400) DEFAULT NULL,
  `candidate_prefferedlocation` varchar(100) DEFAULT NULL,
  `candidate_gender` varchar(50) DEFAULT NULL,
  `candidate_totalworkexperience` varchar(100) DEFAULT NULL,
  `candidate_annualsalary` varchar(60) DEFAULT NULL,
  `candidate_deeshamail` varchar(120) DEFAULT NULL,
  `candidate_websitesource` varchar(500) DEFAULT NULL,
  `candidate_telno2` varchar(50) DEFAULT NULL,
  `candidate_wpno` varchar(100) DEFAULT NULL,
  `candidate_wpno2` varchar(100) DEFAULT NULL,
  `candidate_noticeperiod` varchar(70) DEFAULT NULL,
  `candidate_highesteducationlevel` varchar(70) DEFAULT NULL,
  `candidate_highesteducationstream` varchar(70) DEFAULT NULL,
  `candidate_highesteducationinsitute` varchar(70) DEFAULT NULL,
  `candidate_yearofpassing` varchar(40) DEFAULT NULL,
  `candidate_highesteducationcoursetype` varchar(70) DEFAULT NULL,
  `candidate_createdate` varchar(100) DEFAULT NULL,
  `candidate_lastmodifieddate` varchar(100) DEFAULT NULL,
  `candidate_lastactivedate` varchar(100) DEFAULT NULL,
  `candidate_note` varchar(70) DEFAULT NULL,
  `candidate_summarydescription` text,
  `candidate_listed` enum('0','1') NOT NULL DEFAULT '1',
  `candidate_experiencepershine` text,
  `candidate_lastjob` varchar(120) DEFAULT NULL,
  `candidate_lasttolastjob` varchar(120) DEFAULT NULL,
  `candidate_graducationcourse` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_graduationcollege` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_skills` varchar(300) DEFAULT NULL,
  `candidate_mayalsoknow` varchar(300) DEFAULT NULL,
  `candidate_tiercity` varchar(100) DEFAULT NULL,
  `candidate_loanproduct` varchar(120) DEFAULT NULL,
  `candidate_loansubproduct` varchar(120) DEFAULT NULL,
  `candidate_internalsource` varchar(120) DEFAULT NULL,
  `candidate_sourcetype` varchar(70) DEFAULT NULL,
  `candidate_externalsource` varchar(120) DEFAULT NULL,
  `candidate_refferredname` varchar(120) DEFAULT NULL,
  `candidate_refferredbankname` varchar(100) DEFAULT NULL,
  `candidate_referredid` varchar(20) DEFAULT NULL,
  `candidate_dateofentry` varchar(40) DEFAULT NULL,
  `candidate_deeshaemployeenamerefer` varchar(120) DEFAULT NULL,
  `candidate_deeshaemployeenameenter` varchar(120) DEFAULT NULL,
  `candidate_marriageanniv` varchar(100) DEFAULT NULL,
  `candidate_lastaccessdate` varchar(40) DEFAULT NULL,
  `candidate_lastaccessperson` varchar(120) DEFAULT NULL,
  `candidate_deeshaemployeefeedback` varchar(100) DEFAULT NULL,
  `candidate_deeshaemployeecomment` text,
  `candidate_currentbossname` varchar(120) DEFAULT NULL,
  `candidate_exbossname` varchar(120) DEFAULT NULL,
  `candidate_interestingfact` varchar(200) DEFAULT NULL,
  `candidate_languagesspeak` varchar(170) DEFAULT NULL,
  `candidate_languageprefer` varchar(70) DEFAULT NULL,
  `candidate_mothertongue` varchar(70) DEFAULT NULL,
  `candidate_banker` varchar(120) DEFAULT NULL,
  `candidate_residenceaddress` text,
  `candidate_companyaddress` text,
  `candidate_country` varchar(50) DEFAULT NULL,
  `candidate_reportingmanagerno` varchar(100) DEFAULT NULL,
  `candidate_saturdayworking` varchar(50) DEFAULT NULL,
  `candidate_associatedeeesha` varchar(200) DEFAULT NULL,
  `candidate_bankerdeeesha` varchar(200) DEFAULT NULL,
  `candidate_customerdeeesha` varchar(200) DEFAULT NULL,
  `candidate_candidatefinploy` varchar(200) DEFAULT NULL,
  `candidate_companyfinploy` varchar(200) DEFAULT NULL,
  `candidate_associatefinploy` varchar(200) DEFAULT NULL,
  `candidate_companyfinterno` varchar(200) DEFAULT NULL,
  `candidate_internfinterno` varchar(200) DEFAULT NULL,
  `candidate_associatefinterno` varchar(200) DEFAULT NULL,
  `candidate_companyfintubhai` varchar(200) DEFAULT NULL,
  `candidate_customerfintubhai` varchar(200) DEFAULT NULL,
  `candidate_associatefintubhai` varchar(200) DEFAULT NULL,
  `candidate_idassociatedeeesha` varchar(200) DEFAULT NULL,
  `candidate_idbankerdeeesha` varchar(200) DEFAULT NULL,
  `candidate_idcustomerdeeesha` varchar(200) DEFAULT NULL,
  `candidate_idcandidatefinploy` varchar(200) DEFAULT NULL,
  `candidate_idassociatefinploy` varchar(200) DEFAULT NULL,
  `candidate_idcompanyfinterno` varchar(200) DEFAULT NULL,
  `candidate_idintern` varchar(200) DEFAULT NULL,
  `candidate_idassociatefinterno` varchar(200) DEFAULT NULL,
  `candidate_idcompanyfintubhai` varchar(200) DEFAULT NULL,
  `candidate_idcustomerfintubhai` varchar(200) DEFAULT NULL,
  `candidate_idassociatefintubhai` varchar(200) DEFAULT NULL,
  `candidate_othercity` varchar(200) DEFAULT NULL,
  `candidate_nameoncertificate` varchar(200) DEFAULT NULL,
  `candidate_mothername` varchar(200) DEFAULT NULL,
  `candidate_fathername` varchar(200) DEFAULT NULL,
  `candidate_fathertelno` varchar(200) DEFAULT NULL,
  `candidate_mothertelno` varchar(200) DEFAULT NULL,
  `candidate_registrationsite` varchar(200) DEFAULT NULL,
  `candidate_interestedinbankingetc` varchar(200) DEFAULT NULL,
  `candidate_interests` text,
  `candidate_noofpastinternships` varchar(200) DEFAULT NULL,
  `candidate_pastinternships` varchar(400) DEFAULT NULL,
  `candidate_durationofinternship` varchar(200) DEFAULT NULL,
  `candidate_haveyoudonewithdeeesha` varchar(200) DEFAULT NULL,
  `candidate_areyoulookeducationloan` varchar(200) DEFAULT NULL,
  `candidate_rolesinpreviousinternship` varchar(200) DEFAULT NULL,
  `candidate_typeofinternship` varchar(200) DEFAULT NULL,
  `candidate_joinasafulltimeemployee` varchar(200) DEFAULT NULL,
  `candidate_internshipprefer` varchar(200) DEFAULT NULL,
  `candidate_hoursdedicate` varchar(200) DEFAULT NULL,
  `candidate_personalizedlaptop` varchar(200) DEFAULT NULL,
  `candidate_stableconnection` varchar(200) DEFAULT NULL,
  `candidate_typeofinternship2` varchar(200) DEFAULT NULL,
  `candidate_howdaysworkaweek` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `candidate_desiredincome` varchar(200) DEFAULT NULL,
  `candidate_havetechnicalknowledge` varchar(200) DEFAULT NULL,
  `candidate_professortelno` varchar(200) DEFAULT NULL,
  `linkedin_name` text,
  `linkedin_namepos` text,
  `linkedin_companyname` text,
  `linkedin_cityname` text,
  `linkedin_statename` text,
  `linkedin_namecountry` text,
  `linkedin_currentjob` text,
  `linkedin_secondlastjob` text,
  `linkedin_thirdlastjob` text,
  `linkedin_highesteducation` text,
  `linkedin_secondeducation` text,
  `linkedin_skills` text,
  `linkedin_interests` text,
  `linkedin_accomplishment` text,
  `linkedin_urlfromscrapper` text,
  `candidate_firstname` text,
  `candidate_middlename` text,
  `candidate_lastname` text,
  `candidate_emailidofficial` text,
  `candidate_birthday` text,
  `candidate_lastcallbydeeeshaemp` text,
  `candidate_employeemail` text,
  `candidate_rawdata` enum('0','1') NOT NULL DEFAULT '0',
  `candidate_raw` enum('yes','no') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'yes',
  `candidate_clean` enum('yes','no') DEFAULT NULL,
  `candidate_alreadyexist` enum('0','1') DEFAULT NULL,
  `candidate_uploadedby` text,
  `candidate_referredby` text,
  `candidate_referrer` enum('yes','no') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `candidates`
--

INSERT INTO `candidates` (`candidate_id`, `candidate_ad`, `candidate_soyad`, `candidate_adsoyad`, `candidate_telno`, `candidate_idx`, `candidate_location`, `candidate_linkedin`, `candidate_company`, `candidate_called`, `kullanici_id`, `candidate_tarihi`, `candidate_respond`, `candidate_remark`, `candidate_markdate`, `candidate_interestedto`, `candidate_designation`, `candidate_mail`, `candidate_product`, `candidate_department`, `candidate_pincode`, `salary_monthlyannually`, `salary_amount`, `salary_measure`, `candidate_jobchange`, `candidate_experience`, `candidate_birthdate`, `candidate_industry`, `candidate_currentjobexperience`, `candidate_currentfunctionalarea`, `candidate_bankingdepartment`, `candidate_bankingsubdepartment`, `candidate_multiplelocation`, `candidate_multiplelocationnames`, `candidate_prefferedlocation`, `candidate_gender`, `candidate_totalworkexperience`, `candidate_annualsalary`, `candidate_deeshamail`, `candidate_websitesource`, `candidate_telno2`, `candidate_wpno`, `candidate_wpno2`, `candidate_noticeperiod`, `candidate_highesteducationlevel`, `candidate_highesteducationstream`, `candidate_highesteducationinsitute`, `candidate_yearofpassing`, `candidate_highesteducationcoursetype`, `candidate_createdate`, `candidate_lastmodifieddate`, `candidate_lastactivedate`, `candidate_note`, `candidate_summarydescription`, `candidate_listed`, `candidate_experiencepershine`, `candidate_lastjob`, `candidate_lasttolastjob`, `candidate_graducationcourse`, `candidate_graduationcollege`, `candidate_skills`, `candidate_mayalsoknow`, `candidate_tiercity`, `candidate_loanproduct`, `candidate_loansubproduct`, `candidate_internalsource`, `candidate_sourcetype`, `candidate_externalsource`, `candidate_refferredname`, `candidate_refferredbankname`, `candidate_referredid`, `candidate_dateofentry`, `candidate_deeshaemployeenamerefer`, `candidate_deeshaemployeenameenter`, `candidate_marriageanniv`, `candidate_lastaccessdate`, `candidate_lastaccessperson`, `candidate_deeshaemployeefeedback`, `candidate_deeshaemployeecomment`, `candidate_currentbossname`, `candidate_exbossname`, `candidate_interestingfact`, `candidate_languagesspeak`, `candidate_languageprefer`, `candidate_mothertongue`, `candidate_banker`, `candidate_residenceaddress`, `candidate_companyaddress`, `candidate_country`, `candidate_reportingmanagerno`, `candidate_saturdayworking`, `candidate_associatedeeesha`, `candidate_bankerdeeesha`, `candidate_customerdeeesha`, `candidate_candidatefinploy`, `candidate_companyfinploy`, `candidate_associatefinploy`, `candidate_companyfinterno`, `candidate_internfinterno`, `candidate_associatefinterno`, `candidate_companyfintubhai`, `candidate_customerfintubhai`, `candidate_associatefintubhai`, `candidate_idassociatedeeesha`, `candidate_idbankerdeeesha`, `candidate_idcustomerdeeesha`, `candidate_idcandidatefinploy`, `candidate_idassociatefinploy`, `candidate_idcompanyfinterno`, `candidate_idintern`, `candidate_idassociatefinterno`, `candidate_idcompanyfintubhai`, `candidate_idcustomerfintubhai`, `candidate_idassociatefintubhai`, `candidate_othercity`, `candidate_nameoncertificate`, `candidate_mothername`, `candidate_fathername`, `candidate_fathertelno`, `candidate_mothertelno`, `candidate_registrationsite`, `candidate_interestedinbankingetc`, `candidate_interests`, `candidate_noofpastinternships`, `candidate_pastinternships`, `candidate_durationofinternship`, `candidate_haveyoudonewithdeeesha`, `candidate_areyoulookeducationloan`, `candidate_rolesinpreviousinternship`, `candidate_typeofinternship`, `candidate_joinasafulltimeemployee`, `candidate_internshipprefer`, `candidate_hoursdedicate`, `candidate_personalizedlaptop`, `candidate_stableconnection`, `candidate_typeofinternship2`, `candidate_howdaysworkaweek`, `candidate_desiredincome`, `candidate_havetechnicalknowledge`, `candidate_professortelno`, `linkedin_name`, `linkedin_namepos`, `linkedin_companyname`, `linkedin_cityname`, `linkedin_statename`, `linkedin_namecountry`, `linkedin_currentjob`, `linkedin_secondlastjob`, `linkedin_thirdlastjob`, `linkedin_highesteducation`, `linkedin_secondeducation`, `linkedin_skills`, `linkedin_interests`, `linkedin_accomplishment`, `linkedin_urlfromscrapper`, `candidate_firstname`, `candidate_middlename`, `candidate_lastname`, `candidate_emailidofficial`, `candidate_birthday`, `candidate_lastcallbydeeeshaemp`, `candidate_employeemail`, `candidate_rawdata`, `candidate_raw`, `candidate_clean`, `candidate_alreadyexist`, `candidate_uploadedby`, `candidate_referredby`, `candidate_referrer`) VALUES
(1676, 'Candidate', '1', 'Candidate 1', '1111111111', NULL, 'Delhi', 'link1', 'Company', '0', 74, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek1@gmail.com', 'Gold Loan', 'Sales', 'Loc1', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee1@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1677, 'Candidate', '2', 'Candidate 2', '2222222222', NULL, 'Mumbai', 'link2', 'Company', '0', 75, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek2@gmail.com', 'Gold Loan', 'Sales', 'Loc2', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee2@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1678, 'Candidate', '3', 'Candidate 3', '3333333333', NULL, 'Karnataka', 'link3', 'Company', '1', 76, '2022-05-31 21:11:41', 'Send me details I will see', '', '2022-05-31 21:14:14', 'becomefulltimeemployee', 'Designation', 'candidateornek3@gmail.com', 'Gold Loan', 'Sales', 'Loc3', 'annually', '10', 'thousands', 'yes', '9', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee3@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1679, 'Candidate', '4', 'Candidate 4', '4444444444', NULL, 'Karnataka', 'link4', 'Company', '0', 77, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek4@gmail.com', 'Gold Loan', 'Sales', 'Loc4', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee4@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1680, 'Candidate', '5', 'Candidate 5', '5555555555', NULL, 'Karnataka', 'link5', 'Company', '0', 78, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek5@gmail.com', 'Gold Loan', 'Sales', 'Loc5', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee5@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1681, 'Candidate', '6', 'Candidate 6', '6666666666', NULL, 'Karnataka', 'link6', 'Company', '0', 79, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek6@gmail.com', 'Gold Loan', 'Sales', 'Loc6', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee6@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1682, 'Candidate', '7', 'Candidate 7', '7777777777', NULL, 'Karnataka', 'link7', 'Company', '0', 80, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek7@gmail.com', 'Gold Loan', 'Sales', 'Loc7', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee7@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1683, 'Candidate', '8', 'Candidate 8', '8888888888', NULL, 'Karnataka', 'link8', 'Company', '0', 81, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek8@gmail.com', 'Gold Loan', 'Sales', 'Loc8', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee8@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1684, 'Candidate', '9', 'Candidate 9', '9999999999', NULL, 'Karnataka', 'link9', 'Company', '0', 82, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek9@gmail.com', 'Gold Loan', 'Sales', 'Loc9', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee9@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1685, 'Candidate', '10', 'Candidate 10', '1000000000', NULL, 'Karnataka', 'link10', 'Company', '0', 83, '2022-05-31 21:11:41', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek10@gmail.com', 'Gold Loan', 'Sales', 'Loc10', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee10@gmail.com', '0', 'yes', 'yes', '0', 'Master Admin', NULL, 'no'),
(1686, 'Candidate', '1', 'Candidate 1', '1111111111', NULL, 'Delhi', 'link1', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek1@gmail.com', 'Gold Loan', 'Sales', 'Loc1', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee1@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1687, 'Candidate', '2', 'Candidate 2', '2222222222', NULL, 'Mumbai', 'link2', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek2@gmail.com', 'Gold Loan', 'Sales', 'Loc2', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee2@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1688, 'Candidate', '3', 'Candidate 3', '3333333333', NULL, 'Karnataka', 'link3', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek3@gmail.com', 'Gold Loan', 'Sales', 'Loc3', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee3@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1689, 'Candidate', '4', 'Candidate 4', '4444444444', NULL, 'Karnataka', 'link4', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek4@gmail.com', 'Gold Loan', 'Sales', 'Loc4', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee4@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1690, 'Candidate', '5', 'Candidate 5', '5555555555', NULL, 'Karnataka', 'link5', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek5@gmail.com', 'Gold Loan', 'Sales', 'Loc5', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee5@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1691, 'Candidate', '6', 'Candidate 6', '6666666666', NULL, 'Karnataka', 'link6', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek6@gmail.com', 'Gold Loan', 'Sales', 'Loc6', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee6@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1692, 'Candidate', '7', 'Candidate 7', '7777777777', NULL, 'Karnataka', 'link7', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek7@gmail.com', 'Gold Loan', 'Sales', 'Loc7', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee7@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1693, 'Candidate', '8', 'Candidate 8', '8888888888', NULL, 'Karnataka', 'link8', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek8@gmail.com', 'Gold Loan', 'Sales', 'Loc8', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee8@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1694, 'Candidate', '9', 'Candidate 9', '9999999999', NULL, 'Karnataka', 'link9', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek9@gmail.com', 'Gold Loan', 'Sales', 'Loc9', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee9@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1695, 'Candidate', '10', 'Candidate 10', '1000000000', NULL, 'Karnataka', 'link10', 'Company', '0', NULL, '2022-05-31 21:11:54', NULL, NULL, NULL, NULL, 'Designation', 'candidateornek10@gmail.com', 'Gold Loan', 'Sales', 'Loc10', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'employee10@gmail.com', '1', 'yes', 'no', NULL, 'Master Admin', NULL, 'no'),
(1696, 'Ornek', 'Surname', 'Ornek Surname', '5304725225', NULL, 'Location', 'Linkedin', 'Company', '0', NULL, '2022-05-31 21:13:14', NULL, NULL, NULL, NULL, 'Designation', 'MAIL', 'Others', 'Others', '123456', NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'First Name', 'Middle Name', 'Last Name', '', '', '', 'Employee Mail', '0', 'yes', 'yes', NULL, 'Master Admin', NULL, 'no'),
(1697, 'Ornek', 'Surname 2', 'Ornek Surname 2', '5304725224', NULL, 'Location', 'Linkedin', 'Company', '0', NULL, '2022-05-31 21:13:14', NULL, NULL, NULL, NULL, 'Designation', 'MAIL', 'Others', 'Others', '123456', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'First Name', 'Middle Name', 'Last Name', '', '', '', 'Employee Mail', '0', 'yes', 'yes', NULL, 'Master Admin', NULL, 'no'),
(1698, 'Ornek', 'Surname 3', 'Ornek Surname 3', '5304725223', NULL, 'Location', 'Linkedin', 'Company', '0', NULL, '2022-05-31 21:13:14', NULL, NULL, NULL, NULL, 'Designation', 'MAIL', 'Others', 'Others', '123456', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'First Name', 'Middle Name', 'Last Name', '', '', '', 'Employee Mail', '0', 'yes', 'yes', NULL, 'Master Admin', NULL, 'no'),
(1699, 'Ornek', 'Surname 4', 'Ornek Surname 4', '5304725222', NULL, 'Location', 'Linkedin', 'Company', '0', NULL, '2022-05-31 21:13:14', NULL, NULL, NULL, NULL, 'Designation', 'MAIL', 'Others', 'Others', '123456', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'First Name', 'Middle Name', 'Last Name', '', '', '', 'Employee Mail', '0', 'yes', 'yes', NULL, 'Master Admin', NULL, 'no'),
(1700, 'Ornek', 'Surname 5', 'Ornek Surname 5', '5304725221', NULL, 'Location', 'Linkedin', 'Company', '0', NULL, '2022-05-31 21:13:14', NULL, NULL, NULL, NULL, 'Designation', 'MAIL', 'Others', 'Others', '123456', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'First Name', 'Middle Name', 'Last Name', '', '', '', 'Employee Mail', '0', 'yes', 'yes', NULL, 'Master Admin', NULL, 'no');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `excelfiles`
--

CREATE TABLE `excelfiles` (
  `file_id` int(11) NOT NULL,
  `file_path` varchar(200) DEFAULT NULL,
  `kullanici_id` int(11) DEFAULT NULL,
  `file_date` timestamp NULL DEFAULT NULL,
  `candidate_sayisi` varchar(200) DEFAULT NULL,
  `excel_to` enum('callingpanel','dumpdata') DEFAULT NULL,
  `excel_uploadedby` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Master Admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `excelfiles`
--

INSERT INTO `excelfiles` (`file_id`, `file_path`, `kullanici_id`, `file_date`, `candidate_sayisi`, `excel_to`, `excel_uploadedby`) VALUES
(153, 'excelfiles/62966165ebbd6.xlsx', NULL, '2022-05-31 21:11:41', '10', 'callingpanel', 'Master Admin'),
(154, 'excelfiles/6296617200ca5.xlsx', NULL, '2022-05-31 21:11:54', '10', 'dumpdata', 'Master Admin'),
(155, 'excelfiles/629661c24b2b4.xlsx', NULL, '2022-05-31 21:13:14', '5', 'dumpdata', 'Master Admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iplock`
--

CREATE TABLE `iplock` (
  `iplock` enum('yes','no') NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `iplock`
--

INSERT INTO `iplock` (`iplock`) VALUES
('no');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE `kullanici` (
  `kullanici_id` int(11) NOT NULL,
  `kullanici_idx` varchar(200) DEFAULT NULL,
  `kullanici_telno` varchar(100) DEFAULT NULL,
  `kullanici_mail` varchar(200) DEFAULT NULL,
  `kullanici_ad` varchar(200) DEFAULT NULL,
  `kullanici_soyad` varchar(200) DEFAULT NULL,
  `kullanici_adsoyad` varchar(400) DEFAULT NULL,
  `kullanici_sehir` varchar(300) DEFAULT NULL,
  `kullanici_password` varchar(200) DEFAULT NULL,
  `kullanici_kayitzaman` timestamp NULL DEFAULT NULL,
  `kullanici_datamodified` timestamp NULL DEFAULT NULL,
  `kullanici_yetki` enum('1','4','5') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `kullanici_songiris` timestamp NULL DEFAULT NULL,
  `kullanici_aktif` enum('active','inactive') DEFAULT 'active',
  `subadmin_type` enum('parent','child') DEFAULT NULL,
  `kullanici_profileviewlimit` decimal(10,0) DEFAULT NULL,
  `kullanici_lastprofileview` timestamp NULL DEFAULT NULL,
  `kullanici_todayprofileview` decimal(10,0) DEFAULT '0',
  `kullanici_dailydownloadlimit` decimal(10,0) DEFAULT NULL,
  `kullanici_monthlydownloadlimit` decimal(10,0) DEFAULT NULL,
  `kullanici_todaydownload` decimal(10,0) NOT NULL DEFAULT '0',
  `kullanici_thismonthdownload` decimal(10,0) NOT NULL DEFAULT '0',
  `kullanici_lastdownload` timestamp NULL DEFAULT NULL,
  `kullanici_editallowed` enum('yes','no') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kullanici_id`, `kullanici_idx`, `kullanici_telno`, `kullanici_mail`, `kullanici_ad`, `kullanici_soyad`, `kullanici_adsoyad`, `kullanici_sehir`, `kullanici_password`, `kullanici_kayitzaman`, `kullanici_datamodified`, `kullanici_yetki`, `kullanici_songiris`, `kullanici_aktif`, `subadmin_type`, `kullanici_profileviewlimit`, `kullanici_lastprofileview`, `kullanici_todayprofileview`, `kullanici_dailydownloadlimit`, `kullanici_monthlydownloadlimit`, `kullanici_todaydownload`, `kullanici_thismonthdownload`, `kullanici_lastdownload`, `kullanici_editallowed`) VALUES
(32, NULL, NULL, 'admin@gmail.com', 'Harsh', 'J.', 'Harsh J.', NULL, '12345678', NULL, NULL, '5', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(74, NULL, '5555555555', 'employee1@gmail.com', 'Employee', '1', 'Employee 1', 'Mumbai', '12345678', '2022-05-22 12:36:50', '2022-05-21 21:00:00', '1', '2022-06-02 07:57:12', 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(75, NULL, '4444444444', 'employee2@gmail.com', 'Employee', '2', 'Employee 2', 'Mumbai', '12345678', '2022-05-22 12:37:05', NULL, '1', '2022-05-27 15:04:02', 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(76, NULL, '3333333333', 'employee3@gmail.com', 'Employee', '3', 'Employee 3', 'Karnataka', '12345678', '2022-05-22 12:37:28', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(77, NULL, '2222222222', 'employee4@gmail.com', 'Employee', '4', 'Employee 4', '', '12345678', '2022-05-22 12:37:39', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(78, NULL, '1111111111', 'employee5@gmail.com', 'Employee', '5', 'Employee 5', 'Karnataka', '12345678', '2022-05-22 12:37:56', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(79, NULL, '6666666666', 'employee6@gmail.com', 'Employee', '6', 'Employee 6', '', '12345678', '2022-05-22 12:38:08', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(80, NULL, '7777777777', 'employee7@gmail.com', 'Employee', '7', 'Employee 7', '', '12345678', '2022-05-22 12:38:31', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(81, NULL, '8888888888', 'employee8@gmail.com', 'Employee', '8', 'Employee 8', 'Jaipur', '12345678', '2022-05-22 12:38:49', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(82, NULL, '9999999999', 'employee9@gmail.com', 'Employee', '9', 'Employee 9', '', '12345678', '2022-05-22 12:39:02', NULL, '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(83, NULL, '1313131313', 'employee10@gmail.com', 'Employee', '10', 'Employee 10', 'Uttar Pradesh', '12345678', '2022-05-22 12:39:16', '2022-05-21 21:00:00', '1', NULL, 'active', NULL, NULL, NULL, '0', NULL, NULL, '0', '0', NULL, NULL),
(84, NULL, '1111111111', 'subadmin1@gmail.com', 'Sub Admin', '1', 'Sub Admin 1', 'Mumbai', '12345678', '2022-05-22 14:30:14', NULL, '4', '2022-05-28 21:03:22', 'active', 'child', '10', '2022-05-28 20:56:32', '3', NULL, NULL, '0', '0', NULL, NULL),
(85, NULL, '2222222222', 'subadmin2@gmail.com', 'Sub Admin', '2', 'Sub Admin 2', 'Karnataka', '12345678', '2022-05-22 14:30:40', '2022-05-21 21:00:00', '4', '2022-05-22 14:50:39', 'inactive', 'child', '30', NULL, '3', NULL, NULL, '0', '0', NULL, NULL),
(86, NULL, '3333333333', 'subadmin3@gmail.com', 'Sub Admin', '3', 'Sub Admin 3', '', '12345678', '2022-05-22 14:32:17', NULL, '4', '2022-05-30 12:42:29', 'active', 'parent', '6', '2022-05-28 18:41:34', '3', '10000', '10000', '1', '63', '2022-05-28 21:03:41', 'yes'),
(87, NULL, '4444444444', 'subadmin4@gmail.com', 'Sub Admin', '4', 'Sub Admin 4', '', '12345678', '2022-05-22 14:32:51', '2022-05-21 21:00:00', '4', '2022-05-25 17:21:59', 'active', 'parent', '30', '2022-05-25 17:22:10', '2', '20', '70', '0', '0', NULL, 'no'),
(89, NULL, '0530472522', 'subadmin5@gmail.comx', 'Sub Admin', '5', 'Sub Admin 5', 'Mumbaii', '12345678', '2022-05-26 12:33:02', '2022-05-25 21:00:00', '4', NULL, 'active', 'child', '22', NULL, '0', NULL, NULL, '0', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `logbook`
--

CREATE TABLE `logbook` (
  `id` int(11) NOT NULL,
  `login_datetime` timestamp NULL DEFAULT NULL,
  `kullanici_id` int(11) DEFAULT NULL,
  `kullanici_yetki` enum('1','4') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `logbook`
--

INSERT INTO `logbook` (`id`, `login_datetime`, `kullanici_id`, `kullanici_yetki`) VALUES
(117, '2022-06-02 07:57:12', 74, '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `profileviews`
--

CREATE TABLE `profileviews` (
  `profileview_id` int(11) NOT NULL,
  `kullanici_id` int(11) DEFAULT NULL,
  `candidate_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referchain`
--

CREATE TABLE `referchain` (
  `chain_id` int(11) NOT NULL,
  `referrer_id` int(11) DEFAULT NULL,
  `referred_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `referchain`
--

INSERT INTO `referchain` (`chain_id`, `referrer_id`, `referred_id`) VALUES
(67, 1696, 1696);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `allowedips`
--
ALTER TABLE `allowedips`
  ADD PRIMARY KEY (`ip_id`);

--
-- Tablo için indeksler `calllogs`
--
ALTER TABLE `calllogs`
  ADD PRIMARY KEY (`call_id`);

--
-- Tablo için indeksler `candidatedocuments`
--
ALTER TABLE `candidatedocuments`
  ADD PRIMARY KEY (`document_id`);

--
-- Tablo için indeksler `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Tablo için indeksler `excelfiles`
--
ALTER TABLE `excelfiles`
  ADD PRIMARY KEY (`file_id`);

--
-- Tablo için indeksler `iplock`
--
ALTER TABLE `iplock`
  ADD PRIMARY KEY (`iplock`);

--
-- Tablo için indeksler `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`kullanici_id`);

--
-- Tablo için indeksler `logbook`
--
ALTER TABLE `logbook`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `profileviews`
--
ALTER TABLE `profileviews`
  ADD PRIMARY KEY (`profileview_id`);

--
-- Tablo için indeksler `referchain`
--
ALTER TABLE `referchain`
  ADD PRIMARY KEY (`chain_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `allowedips`
--
ALTER TABLE `allowedips`
  MODIFY `ip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `calllogs`
--
ALTER TABLE `calllogs`
  MODIFY `call_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=374;

--
-- Tablo için AUTO_INCREMENT değeri `candidatedocuments`
--
ALTER TABLE `candidatedocuments`
  MODIFY `document_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tablo için AUTO_INCREMENT değeri `candidates`
--
ALTER TABLE `candidates`
  MODIFY `candidate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1701;

--
-- Tablo için AUTO_INCREMENT değeri `excelfiles`
--
ALTER TABLE `excelfiles`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- Tablo için AUTO_INCREMENT değeri `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `kullanici_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- Tablo için AUTO_INCREMENT değeri `logbook`
--
ALTER TABLE `logbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- Tablo için AUTO_INCREMENT değeri `profileviews`
--
ALTER TABLE `profileviews`
  MODIFY `profileview_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- Tablo için AUTO_INCREMENT değeri `referchain`
--
ALTER TABLE `referchain`
  MODIFY `chain_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
